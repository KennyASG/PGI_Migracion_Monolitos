using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using RestAPI.Models;

namespace RestAPI.Services;

public class MongoDBService
{
    private readonly IMongoDatabase _database;
    
    public MongoDBService(IOptions<MongoDbSettings> mongoDbSettings)
    {
        MongoClient client = new MongoClient(mongoDbSettings.Value.ConnectionURI);
        _database = client.GetDatabase(mongoDbSettings.Value.DatabaseName);
    }

    public IMongoCollection<T> GetCollection<T>(string collectionName)
    {
        return _database.GetCollection<T>(collectionName);
    }
    

    public async Task<List<T>> GetAsync<T>(string collectionName)
    {
        var collection = GetCollection<T>(collectionName);
        return await collection.Find(Builders<T>.Filter.Empty).ToListAsync();
    }
    
    
    public async Task CreateAsync<T>(T document, string collectionName)
    {
        var collection = GetCollection<T>(collectionName);
        await collection.InsertOneAsync(document);
        return;
    }

    public async Task UpdateComputadoras(string id, Computadoras computadoras, string collectionName)
    {
        var collection = GetCollection<Computadoras>(collectionName);
        FilterDefinition<Computadoras> filter = Builders<Computadoras>.Filter.Eq(c => c.id, id);
        UpdateDefinition<Computadoras> update = Builders<Computadoras>.Update
            .Set(c => c.nombreComputadora, computadoras.nombreComputadora)
            .Set(c => c.computadorasIds, computadoras.computadorasIds);

        await collection.UpdateOneAsync(filter, update);
        return;
    }
    
    public async Task UpdateTablets(string id, Tablets tablets, string collectionName)
    {
        var collection = GetCollection<Tablets>(collectionName);
        FilterDefinition<Tablets> filter = Builders<Tablets>.Filter.Eq(t => t.Id, id);
        UpdateDefinition<Tablets> update = Builders<Tablets>.Update
            .Set(t => t.NombreTablet, tablets.NombreTablet)
            .Set(t => t.TabletsIds, tablets.TabletsIds);

        await collection.UpdateOneAsync(filter, update);
        return;
    }

    public async Task DeleteAsync<T>(string id, string collectionName)
    {
        var collection = GetCollection<T>(collectionName);
        FilterDefinition<T> filter = Builders<T>.Filter.Eq("id", id);
        await collection.DeleteOneAsync(filter);
        return;
    }
    
}