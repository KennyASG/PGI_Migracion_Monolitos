using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace RestAPI.Models;

public class Tablets
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }
    public string NombreTablet { get; set; } = null!;

    [BsonElement("tablets")]
    [JsonPropertyName("tablets")]
    public List<string> TabletsIds { get; set; } = null!;

}