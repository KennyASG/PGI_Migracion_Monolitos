using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace RestAPI.Models;

public class Computadoras
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? id { get; set; }
    public string nombreComputadora { get; set; } = null!;

    [BsonElement("computadoras")]
    [JsonPropertyName("computadoras")]
    public List<string> computadorasIds { get; set; } = null!;

}