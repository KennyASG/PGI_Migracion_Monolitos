using Microsoft.AspNetCore.Mvc;
using RestAPI.Models;
using RestAPI.Services;

namespace RestAPI.Controllers;

[Controller]
[Route("Api/[controller]")]
public class ComputadoraController : Controller
{
    private readonly MongoDBService _mongoDBService;

    public ComputadoraController(MongoDBService mongoDBService)
    {
        _mongoDBService = mongoDBService;
    }

    [HttpGet]
    public async Task<List<Computadoras>> Get()
    {
        return await _mongoDBService.GetAsync<Computadoras>("Computadoras");
    }
    

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Computadoras computadoras)
    {
        await _mongoDBService.CreateAsync(computadoras, "Computadoras"); 
        return CreatedAtAction(nameof(Get), new { computadoras.id }, computadoras);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateComputadoras(string id, [FromBody] Computadoras computadoras)
    {
        await _mongoDBService.UpdateComputadoras(id, computadoras, "Computadoras");
        return Ok(new { message = "Computadora actualizada correctamente." });
    }


    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        await _mongoDBService.DeleteAsync<Computadoras>(id, "Computadoras"); 
        return Ok(new { message = "Computadora Eliminada correctamente." });
    }
}
