using Microsoft.AspNetCore.Mvc;
using RestAPI.Models;
using RestAPI.Services;

namespace RestAPI.Controllers;

[Controller]
[Route("Api/[controller]")]
public class TabletsController : Controller
{
    private readonly MongoDBService _mongoDBService;

    public TabletsController(MongoDBService mongoDBService)
    {
        _mongoDBService = mongoDBService;
    }

    [HttpGet]
    public async Task<List<Tablets>> Get()
    {
        return await _mongoDBService.GetAsync<Tablets>("Tabletas"); 
    }

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Tablets tablets)
    {
        await _mongoDBService.CreateAsync(tablets, "Tabletas"); 
        return CreatedAtAction(nameof(Get), new { tablets.Id }, tablets);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateTablets(string id, [FromBody] Tablets tablets)
    {
        await _mongoDBService.UpdateTablets(id, tablets, "Tabletas");
        return Ok(new { message = "Tablet actualizada correctamente." });
    }
    
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        await _mongoDBService.DeleteAsync<Tablets>(id, "Tabletas"); 
        return NoContent();
    }
    
    
}