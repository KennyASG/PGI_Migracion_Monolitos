﻿#pragma warning disable IDE0290
using API_PortalDocumentacion.Repository.IRepository;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authorization;
using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [EnableCors()]
    [ApiController]
    public class MenuController : ControllerBase
    {
        //Declaration of variables
        private readonly IMenuRepository _menuRepo;
        public ResponseAPI _responseAPI = new();
        public DbPortalDocumentacionContext _dbContext;

        //Class Constructor
        public MenuController(IMenuRepository menuRepo)
        {   
            _menuRepo = menuRepo;
        }

        //API Login, receives a model (corporate and password) and returns (corporate, full name and TOKEN)
        [HttpPost]
        [Route("GetMenuItems/{corporate}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult> GetMenuItems(string corporate)
        {
            var menuItems = _menuRepo.GetListItems(corporate);

            if (menuItems.Count == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡El usuario no tiene módulos asignados o no existe!");
                return BadRequest(_responseAPI);
            }

            var model = _menuRepo.BuildMenuTree(menuItems);
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = model;
            return Ok(_responseAPI);
        }

        //API to Get documenter menu items
        [HttpPost]
        [Route("GetDocumenterMenuItems/{corporate}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDocumenterMenuItems(string corporate)
        {
            var response = _menuRepo.GetDocumenterMenuItems(corporate);

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener los proyectos asignados al usuario!");
                return BadRequest(_responseAPI);
            }
            if (response.Count == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡El usuario no tiene proyectos asignados!");
                _responseAPI.Detail = response;
                return BadRequest(_responseAPI);
            }
            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Proyectos obtenidos correctamente!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to get notifications and requests count
        [HttpPost]
        [Route("GetNotificationAndRequestCount")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetNotificationAndRequestCount(GetNotifAndRequestCountModel details)
        {
            var response = await _menuRepo.GetNotificationAndRequestCount(details);
            //Incorrect request, flags or permissions ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener el conteo!");
                return BadRequest(_responseAPI);
            }

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Conteo obtenido!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }
    }
}
