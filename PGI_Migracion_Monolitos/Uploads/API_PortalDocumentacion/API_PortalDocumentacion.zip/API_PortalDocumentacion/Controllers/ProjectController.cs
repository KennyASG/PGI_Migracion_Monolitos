using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using API_PortalDocumentacion.Models.Portal;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ProjectController : ControllerBase
    {
        //Declaration of variables
        private readonly IProjectRepository _projectRepo;
        private readonly IAdminRepository _adminRepo;
        private readonly ResponseAPI _responseAPI = new();

        //Class constructor
        public ProjectController(IProjectRepository projectRepository, IAdminRepository adminRepository)
        {
            _projectRepo = projectRepository;
            _adminRepo = adminRepository;
        }

        //API to Create Project, modules and diagrams.
        [HttpPost]
        [Route("CreateProjects")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateProjects(CreateProjectModel createProjectModel)
        {
            var response = _projectRepo.CreateProject(createProjectModel);

            //Something went wrong
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ah ocurrido un error al realizar la creación!");
                return BadRequest(_responseAPI);
            }

            if (response != "EXITO")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Creación no completada!");
                _responseAPI.Detail = $"Motivo: {response}";
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(createProjectModel.ActionUser, 13, 0, $"Proyecto creado: {createProjectModel.ProjectName}"); //Action: 13 (Create project, module and diagram)

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Creación existosa");
            return Ok(_responseAPI);
        }

        //API to Update Project, modules and diagrams.
        [HttpPost]
        [Route("UpdateProjects")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateProjects(UpdateCreateProjectModel updateCreateProjModel)
        {
            var response = _projectRepo.UpdateProject(updateCreateProjModel);

            //Something went wrong
            if (response == "ERROR")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ah ocurrido un error al realizar la actualización!");
                return BadRequest(_responseAPI);
            }

            if (response != "ÉXITO")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Actualización no completada!");
                _responseAPI.Detail = $"Motivo: {response}";
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(updateCreateProjModel.ActionUser, 13, 0, $"Uno de los items de proyecto {updateCreateProjModel.ProjectName} fue actualizado,eliminado ó agregado."); //Action: 13 (Create project, module and diagram)

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Actualización completada con éxito.");
            return Ok(_responseAPI);
        }

        //API to Get Project Module Option Diagram & Assigned Documenters
        [HttpPost]
        [Route("GetProjectsAndDocumenters")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetProjectsAndDocumenters()
        {
            var response = _projectRepo.GetProjectsAndDocumenters();

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener los proyectos y documentadores!");
                return BadRequest(_responseAPI);
            }

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to Get list documenters
        [HttpPost]
        [Route("GetListDocumenters")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetListDocumenters()
        {
            var responseLogin = await _projectRepo.GetListDocumenters();

            //Corporate or password is incorrect ERROR 401
            if (responseLogin == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener la lista de analistas documentadores!");
                return BadRequest(_responseAPI);
            }

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responseLogin;
            return Ok(_responseAPI);
        }

        //API to Get classifications
        [HttpPost]
        [Route("GetClassifications")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetClassifications()
        {
            var response = await _projectRepo.GetClassifications();

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener las clasificaciones!");
                return BadRequest(_responseAPI);
            }

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to Get layers
        [HttpPost]
        [Route("GetLayers")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetLayers()
        {
            var responseLogin = await _projectRepo.GetLayers();

            //Corporate or password is incorrect ERROR 401
            if (responseLogin == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener las capas!");
                return BadRequest(_responseAPI);
            }

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responseLogin;
            return Ok(_responseAPI);
        }

        //API to Delete Project, modules and diagrams.
        [HttpPost]
        [Route("DeleteProject")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteProjects(DeleteProjectModel delProjModel)
        {
            var response = _projectRepo.DeleteProjects(delProjModel);

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ocurrió un error al realizar la eliminación!");
                return BadRequest(_responseAPI);
            }

            //Already Deleted, incorrect data received ERROR 400
            if (response.StartsWith("ERROR"))
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡El elemento ya ha sido dado de baja!");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(delProjModel.ActionUser, 14, 0, delProjModel.Comment); //Action: 14 (Delete project, module and diagram)

            //Success in deleting diagrams CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Eliminación exitosa");
            return Ok(_responseAPI);
        }

        //API to Create Matrix
        [HttpPost]
        [Route("CreateMatrix")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateMatrix(CreateMatrixModel createMatrixModel)
        {
            var response = _projectRepo.CreateMatrix(createMatrixModel);
            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al crear la matriz!");
                return BadRequest(_responseAPI);
            }

            //Error proccessing request ERROR 400
            if (response.StartsWith("ERROR:"))
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add(response);
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(createMatrixModel.ActionUser, 16, createMatrixModel.DiagramId, ""); //Action: 16 (Create matrix)
            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Matriz de impacto creada exitosamente");
            return Ok(_responseAPI);
        }

        //API to Update matrix and details
        [HttpPost]
        [Route("UpdateMatrix")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateMatrix(UpdateMatrixModel updateMatrixModel)
        {
            var response = _projectRepo.UpdateMatrix(updateMatrixModel);

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al actualizar la matriz");
                return BadRequest(_responseAPI);
            }

            //Error proccessing request ERROR 400
            if (response.StartsWith("ERROR:"))
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add(response);
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(updateMatrixModel.ActionUser, 15, updateMatrixModel.DiagramId, response); //Action: 15 (Update matrix percentage)
            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Matriz de impacto actualizada exitosamente");
            return Ok(_responseAPI);
        }

        // API to Get Matrix And Details
        [HttpPost]
        [Route("GetMatrixAndDetails/{DiagramId}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetMatrixAndDetails(int DiagramId)
        {
            GetMatrixAndDetailModel matrix = _projectRepo.GetMatrixByDiagramId(DiagramId);

            if (matrix == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay matriz para el diagrama indicado!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Matriz encontrada!");
            _responseAPI.Detail = matrix;
            return Ok(_responseAPI);
        }

        //API to Create diagram installations
        [HttpPost]
        [Route("CreateDiagramInstallation")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateDiagramInstallation(InstallationModel installationDetails) 
        {
            var response = _projectRepo.DiagramInstallation(installationDetails);
            if(response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al guardar la instalación del diagrama!");
                return BadRequest(_responseAPI);
            }
            //Log
            _adminRepo.SaveLog(installationDetails.ActionUser, 20, installationDetails.DiagramId, response); //Action: 20 (Update diagram)
            _responseAPI.StatusCode = HttpStatusCode.Created;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Instalación guardada exitosamente!");
            return Created("", _responseAPI);
        }

        //API to Get Install Types
        [HttpPost]
        [Route("GetInstallationTypes")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetInstallationTypes()
        {
            var response = await _projectRepo.GetInstallationTypes();
            if(response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener los tipos de instalación!");
                return BadRequest(_responseAPI);
            }
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Tipos de instalación encontrados!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }
    }
}
