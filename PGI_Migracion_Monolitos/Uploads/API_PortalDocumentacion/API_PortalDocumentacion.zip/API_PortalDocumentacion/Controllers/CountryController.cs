﻿using Microsoft.AspNetCore.Mvc;
using API_PortalDocumentacion.Repository.IRepository;
using System.Net;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authorization;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("api/[controller]")]
    public class CountryController : ControllerBase
    {
        //Declaration of variables
        private readonly ICountryRepository _countryRepo;
        public ResponseAPI _responseAPI = new();

        //Class Constructor
        public CountryController(ICountryRepository countryRepo)
        {
            _countryRepo = countryRepo;
        }

        [HttpPost]
        [Route("GetCountries")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult> GetCountries()
        {
            var countryList = await _countryRepo.GetCountries();
            if (countryList == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No se encontraron países!");
                return BadRequest(_responseAPI);
            }
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = countryList;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Authorize]
        [Route("GetUserCountries/{Corporate}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult> GetUserCountries(string Corporate)
        {
            var countryList = await _countryRepo.GetUserCountries(Corporate);
            if (countryList == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No se encontraron países!");
                return BadRequest(_responseAPI);
            }
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = countryList;
            return Ok(_responseAPI);
        }
    }
}
