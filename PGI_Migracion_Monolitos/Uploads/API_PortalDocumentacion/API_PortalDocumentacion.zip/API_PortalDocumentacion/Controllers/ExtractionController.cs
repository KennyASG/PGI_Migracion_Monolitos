﻿using System.Net;
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using API_PortalDocumentacion.Models.Portal.Dtos;
using Microsoft.AspNetCore.Authorization;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class ExtractionController : ControllerBase
    {
        private readonly DbPortalDocumentacionContext _dbContext;
        public IExtractionRepository _extracRepo;
        public ResponseAPI _responseAPI = new();

        public ExtractionController(DbPortalDocumentacionContext dbContext, IExtractionRepository extractionRepository)
        {
            _dbContext = dbContext;
            _extracRepo = extractionRepository;
        }

        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("visioExtraction")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> VisioExtraction(FileVisioModel model)
        {

            if (model.FileVisio == null || model.FileVisio.Length == 0 || model.Diagram == 0)
            {
                return BadRequest("El archivo y diagrama son necesarios y no pueden estar vacíos.");
            }           
            try
            {
                // Obtener el archivo y guardarlo temporalmente
                var tempFilePath = Path.Combine(Path.GetTempPath(), model.FileVisio.FileName);
                using (var stream = new FileStream(tempFilePath, FileMode.Create))
                {
                    await model.FileVisio.CopyToAsync(stream);
                }
                // Procesar el archivo .vsdx
                VisioExtractionResult result = _extracRepo.extractionData(tempFilePath, model.Diagram, model.flag);


                // Eliminar el archivo temporal después de procesarlo
                System.IO.File.Delete(tempFilePath);

                // Devolver los datos extraídos
                //user has projects assigned CODE 200 
                _responseAPI.StatusCode = HttpStatusCode.OK;
                _responseAPI.IsSuccess = true;
                _responseAPI.Message.Add("Extracción realizada.");
                _responseAPI.Detail = result;
                return Ok(_responseAPI);
            }
            catch
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("Error en la extracción.");
                return BadRequest(_responseAPI);
            }
        }
    }
}
