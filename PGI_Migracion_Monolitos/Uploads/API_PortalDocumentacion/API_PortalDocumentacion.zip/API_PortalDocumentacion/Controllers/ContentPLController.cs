﻿#pragma warning disable IDE0290
using API_PortalDocumentacion.Repository.IRepository;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Models.Portal;
using Microsoft.AspNetCore.Authorization;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]

    public class ContentPLController : ControllerBase
    {
        //Declaration of variables
        private readonly IContentPLRepository _contentPLRepo;
        public readonly IAdminRepository _adminRepo;
        private readonly ResponseAPI _responseAPI = new();

        public ContentPLController(IContentPLRepository contentPLRepo, IAdminRepository adminRepository)
        {
            _contentPLRepo = contentPLRepo;
            _adminRepo = adminRepository;
        }

        //API GetDataDiagram, receives a integer and returns (FilePath and systems used)
        [HttpPost]
        [Route("GetDataDiagram")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetDataDiagram([FromBody] GetDataDiagramDTO getDataDiagramDTO)
        {
            var responsePaths = await _contentPLRepo.GetDataDiagramPL(getDataDiagramDTO.DiagramId);

            if (responsePaths == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No existen rutas!");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(getDataDiagramDTO.Corporate, 8, getDataDiagramDTO.DiagramId, ""); //Action: 8 (Diagram visited)

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responsePaths;
            return Ok(_responseAPI);
        }

        //API GetDataDiagram, receives a integer and returns (FilePath and systems used)
        [HttpPost]
        [Route("SearchMatch")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> SearchMatch([FromBody] BodySearchDTO bSearchDTO)
        {
            var responseSearch = await _contentPLRepo.SearchMatch(bSearchDTO.searchedWord, bSearchDTO.corporate);

            if (responseSearch.Count == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay coincidencias!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responseSearch;
            return Ok(_responseAPI);
        }

        //API Layer by corporate
        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("LayerByCorporate/{corporate}")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult LayerByCorporate(string corporate)
        {
            var response = _contentPLRepo.LayersByCorporate(corporate);

            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡El corporativo/usuario es incorrecto o no existe!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Busqueda realizada con éxito!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("GetNodesAndGraphs")]
        [ResponseCache(CacheProfileName = "Default24Hours")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetNodesAndGraphs()
        {
            var request = _contentPLRepo.GetNodesAndGraphs();
            //return Ok();
            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"No se encontraron solicitudes.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        //API GetDataDiagram, receives a integer and returns (FilePath and systems used)
        [HttpPost]
        [Route("GetMacro/{projectId}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetMacro(int projectId)
        {
            MacroResponseModel responsePaths = await _contentPLRepo.GetMacro(projectId);

            if (responsePaths == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No existe el proyecto!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda completa!");
            _responseAPI.Detail = responsePaths;
            return Ok(_responseAPI);
        }
    }
}
