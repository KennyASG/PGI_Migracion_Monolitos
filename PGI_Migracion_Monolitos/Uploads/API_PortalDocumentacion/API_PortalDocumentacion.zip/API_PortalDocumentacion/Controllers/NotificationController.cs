﻿using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using API_PortalDocumentacion.Models.Portal;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class NotificationController : ControllerBase
    {
        //Declaration of variables
        private readonly INotificationRepository _notificationRepo;
        private readonly IAdminRepository _adminRepo;
        private readonly ResponseAPI _responseAPI = new();

        //Class constructor
        public NotificationController(INotificationRepository notificationRepository, IAdminRepository adminRepository)
        {
            _notificationRepo = notificationRepository;
            _adminRepo = adminRepository;
        }

        //API to Get All Documenter Notifications
        [HttpPost]
        [Route("GetAllDocumenterNotifications/{corporate}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllDocuNotifications(string corporate)
        {
            var response = await _notificationRepo.GetAllDocuNotifications(corporate);

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener las notificaciones!");
                return BadRequest(_responseAPI);
            }

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to Get All Administrator Notifications
        [HttpPost]
        [Route("GetAllAdminNotifications/{corporate}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAdminNotifications(string corporate)
        {
            var response = await _notificationRepo.GetAllAdminNotifications(corporate);

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener las notificaciones!");
                return BadRequest(_responseAPI);
            }

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to Get Detailed Admin Notifications by type
        [HttpPost]
        [Route("GetDetailedAdminNotifByType")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDetailedAdminNotifByType(GetAdminNotificationModel adminNotificationModel)
        {
            var response = await _notificationRepo.GetDetailedAdminNotifByType(adminNotificationModel);

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener las notificaciones!");
                return BadRequest(_responseAPI);
            }

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to Get Detailed Documenter Notifications by type
        [HttpPost]
        [Route("GetDetailedDocumenterNotifByType")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDetailedDocuNotifByType(GetDocumenterNotificationModel docuNotificationModel)
        {
            var response = await _notificationRepo.GetDetailedDocuNotifByType(docuNotificationModel);

            //Corporate or password is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al obtener las notificaciones!");
                return BadRequest(_responseAPI);
            }

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to mark notification as read / unread
        [HttpPost]
        [Route("MarkNotification")]
        [ResponseCache(Location=ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> MarkNotification(MarkNotificationModel MarkedNotifModel)
        {
            var response = _notificationRepo.MarkNotification(MarkedNotifModel);
            //Notification data is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al actualizar la notificación!");
                return BadRequest(_responseAPI);
            }

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Cambio correcto!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to approve notification
        [HttpPost]
        [Route("ApproveNotification")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ApproveNotification(ChangeNotificationStatusModel approveDiagramModel)
        {
            var response = await _notificationRepo.ApproveDiagram(approveDiagramModel);
            //Notification data is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al aprobar la solicitud!");
                return BadRequest(_responseAPI);
            }

            //Guardar en bitácora
            _adminRepo.SaveLog(approveDiagramModel.ActionUser, 18, approveDiagramModel.DiagramId, ""); //Action: 18 (Approve diagram request)

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡La solicitud se ha aprobado correctamente!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to approve notification
        [HttpPost]
        [Route("RejectNotification")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> RejectNotification(ChangeNotificationStatusModel rejectDiagramModel)
        {
            var response = await _notificationRepo.RejectDiagram(rejectDiagramModel);
            //Notification data is incorrect ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al rechazar la solicitud!");
                return BadRequest(_responseAPI);
            }

            //Guardar en bitácora
            _adminRepo.SaveLog(rejectDiagramModel.ActionUser, 19, rejectDiagramModel.DiagramId, $"{rejectDiagramModel.Comment}"); //Action: 19 (Reject diagram request)

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡La solicitud se ha rechazado correctamente!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }

        //API to mark notification assent
        [HttpPost]
        [Route("MarkAsSent/{NotificationId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> MarkAsSent(int NotificationId)
        {
            var response = _notificationRepo.MarkAsSent(NotificationId);
            //Notification doesn't exists ERROR 401
            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al marcar la notificación!");
                return BadRequest(_responseAPI);
            }

            //Success CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Éxito marcando la notificación!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);
        }
    }
}
