﻿using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using API_PortalDocumentacion.Models.Portal;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class AnalystController : ControllerBase
    {
        //Declaration of variables
        private readonly IAnalystRepository _analystRepo;
        private readonly IAdminRepository _adminRepo;
        private readonly ResponseAPI _responseAPI = new();

        //Class constructor
        public AnalystController(IAnalystRepository authRepository, IAdminRepository adminRepository)
        {
            _analystRepo = authRepository;
            _adminRepo = adminRepository;
        }

        //API Upload visio file
        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("UploadDiagramFile")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> UploadDiagramFile(FileVisioModel fvisioModel)
        {
            if (fvisioModel.FileVisio == null || fvisioModel.FileVisio.Length == 0 || fvisioModel.Diagram == 0)
            {
                return BadRequest("El archivo y diagrama son necesarios y no pueden estar vacíos.");
            }

            try
            {
                var response = _analystRepo.UploadDiagramaFileAsync(fvisioModel);

                _responseAPI.StatusCode = HttpStatusCode.OK;
                _responseAPI.IsSuccess = true;
                _responseAPI.Message.Add("Archivo subido y procesado correctamente.");
                _responseAPI.Detail = response;
                return Ok(_responseAPI);
            }
            catch
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("Error al procesar el archivo");
                return BadRequest(_responseAPI);
            }
        }
    }
}
