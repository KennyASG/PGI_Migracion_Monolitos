#pragma warning disable IDE0290
using API_PortalDocumentacion.Repository.IRepository;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authorization;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("api/[controller]")]
    public class ContentLLController : ControllerBase
    {
        //Declaration of variables
        private readonly IContentRepository _contentRepo;
        public readonly IAdminRepository _adminRepo;
        private readonly ResponseAPI _responseAPI = new();

        //Class constructor
        public ContentLLController(IContentRepository contRepository, IAdminRepository adminRepository)
        {
            _contentRepo = contRepository;
            _adminRepo = adminRepository;
        }

        //API GetDataDiagram, receives a integer and returns (FilePath and systems used)
        [HttpPost]
        [Authorize]
        [Route("GetDataDiagram")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetDataDiagrams([FromBody] GetDataDiagramDTO getDataDiagramDTO)
        {
            var responsePaths = await _contentRepo.GetDataDiagrams(getDataDiagramDTO.DiagramId, getDataDiagramDTO.Corporate, getDataDiagramDTO.ElementId);

            if (responsePaths == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No existen rutas!");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(getDataDiagramDTO.Corporate, 8, getDataDiagramDTO.DiagramId, ""); //Action: 8 (Diagram visited)

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responsePaths;
            return Ok(_responseAPI);
        }

        //API SearchMatch, receives a integer and returns (FilePath and systems used)
        [HttpPost]
        [Authorize]
        [Route("SearchMatch")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> SearchMatch([FromBody] BodySearchDTO bSearchDTO)
        {
            var responseSearch = await _contentRepo.SearchMatch(bSearchDTO.searchedWord,bSearchDTO.corporate);

            if (responseSearch.Count == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay coincidencias!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responseSearch;
            return Ok(_responseAPI);
        }

        //API SearchMatch, receives a integer and returns (FilePath and systems used)
        [HttpPost]
        [Authorize]
        [Route("DetailedSearchMatch")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> DetailedSearchMatch([FromBody] BodyDetailedSearchDTO bSearchDTO)
        {
            var responseSearch = await _contentRepo.DetailedSearchMatch(bSearchDTO);

            if (responseSearch.Count == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.NoContent;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay coincidencias!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responseSearch;
            return Ok(_responseAPI);
        }

        //API Get project by corp
        [HttpPost]
        [Authorize]
        [Route("GetProjectsByCorp/{corporate}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetProjectsByCorp(string corporate)
        {
            List<Project> listProjects = await _contentRepo.GetProjectsByCorp(corporate);
            if (listProjects == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay proyectos disponibles!");
                return BadRequest(_responseAPI);
            }
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = listProjects;
            return Ok(_responseAPI);
        }

        //API Get ElementType by corp
        [HttpPost]
        [Authorize]
        [Route("GetElementTypeByCorp/{corporate}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetElementTypeByCorp(string corporate)
        {
            List<ElementType> listElementTypes = await _contentRepo.GetElementTypeByCorp(corporate);
            if (listElementTypes == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay tipos de elementos disponibles!");
                return BadRequest(_responseAPI);
            }
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = listElementTypes;
            return Ok(_responseAPI);
        }

        //API Get project by corp
        [HttpPost]
        [Authorize]
        [Route("GetModuleByProject/{projectId}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetModuleByProject(int projectId)
        {
            List<Module> listModules = await _contentRepo.GetModuleByProject(projectId);
            if (listModules == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay proyectos disponibles!");
                return BadRequest(_responseAPI);
            }
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = listModules;
            return Ok(_responseAPI);
        }

        //API Get systems by module
        [HttpPost]
        [Authorize]
        [Route("GetSystemByModule/{moduleId}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetSystemByModule(int moduleId)
        {
            List<Models.Portal.System> listSystem = await _contentRepo.GetSystemByModule(moduleId);
            if (listSystem == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay proyectos disponibles!");
                return BadRequest(_responseAPI);
            }
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = listSystem;
            return Ok(_responseAPI);
        }

        //API ReturnSearchMatch, receives a integer and returns systems used
        [HttpPost]
        [Authorize]
        [Route("ReturnHistory/{corporate}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> ReturnHistory(string corporate)
        {
            var responseSearch = await _contentRepo.ReturnHistory(corporate);

            if (responseSearch.Count == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.NoContent;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No existe historial!");
                return Ok(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = responseSearch;
            return Ok(_responseAPI);
        }

        //API Get project
        [HttpPost]
        [Route("GetProjects")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetProjects()
        {
            List<Project> listProjects = await _contentRepo.GetProjects();

            if (listProjects == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay proyectos disponibles!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = listProjects;
            return Ok(_responseAPI);
        }


        //API UserRequest
        [HttpPost]
        [Route("SubmitRequest")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> SubmitRequest([FromBody] SubmitRequest submitRequest)
        {

            var request = _contentRepo.SubmitRequest(submitRequest);

            if (request == "No Contenido")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No se recibio ninguna solicitud!");
                return BadRequest(_responseAPI);
            }

            if (request == "Ha ocurrido un error")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ocurrió un error al insertar las solicitudes!");
                return BadRequest(_responseAPI);
            }

            if (request == "En Proceso")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ya tienes una solicitud en proceso!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Solicitud enviada con éxito. Recibirás un correo cuando sea aprobada!");
            return Ok(_responseAPI);
        }

        //API Get project
        [HttpPost]
        [Route("GetProjects/{countryId}")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> GetProjects(int countryId)
        {
            List<Project> listProjects = await _contentRepo.GetProjects(countryId);

            if (listProjects.Count == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No hay proyectos disponibles para el país seleccionado!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = listProjects;
            return Ok(_responseAPI);
        }
    }
}
