﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("api/[controller]")]
    public class LocalUserController : ControllerBase
    {
        //Declaration of variables
        private readonly IUserRepository _userRepo;
        public readonly IAdminRepository _adminRepo;
        public IConfiguration _Configuration { get; set; }
        public ResponseAPI _responseAPI = new();


        //Class constructor
        public LocalUserController(IUserRepository userRepository, IConfiguration configuration, IAdminRepository adminRepository)
        {
            _userRepo = userRepository;
            _adminRepo = adminRepository;
            _Configuration = configuration;
        }

        //API restore password, receives a string (corporate) and return user information.
        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("RestartPassword/{username}")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult RestartPassword(string username)
        {
            string response = _userRepo.RestorePassword(username);

            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"¡Usuario local no existente!");
                return BadRequest(_responseAPI);
            }
            
            if (response == "No exist user")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"¡Usuario local no existente!");
                return BadRequest(_responseAPI);
            }

            if (response == "Successfully restored")
            {
                _adminRepo.SaveLog(username, 11, 0, ""); //Action: 11 (reset password)
                _responseAPI.StatusCode = HttpStatusCode.OK;
                _responseAPI.IsSuccess = true;
                _responseAPI.Message.Add("Contraseña restablecida con éxito.");
                return Ok(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.BadRequest;
            _responseAPI.IsSuccess = false;
            _responseAPI.Message.Add($"¡ERROR!");
            _responseAPI.Detail = response;
            return BadRequest(_responseAPI);
        }

        //API update password, receives a model (username & password)
        [HttpPost]
        [Authorize]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("UpdatePassword")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult UpdatePassword(UpdatePasswordLUDTO updatePasswordLUDTO)
        {
            string response = _userRepo.UpdatePassword(updatePasswordLUDTO);

            if (response == "No exist user")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"¡El usuario [{updatePasswordLUDTO.Username}] no existe!");
                return BadRequest(_responseAPI);
            }

            if (response == "Successfully created")
            {
                _adminRepo.SaveLog(updatePasswordLUDTO.Username, 12, 0, ""); //Action: 12 (update password)
                _responseAPI.StatusCode = HttpStatusCode.OK;
                _responseAPI.IsSuccess = true;
                _responseAPI.Message.Add("Contraseña actualizada con éxito.");
                return Ok(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.BadRequest;
            _responseAPI.IsSuccess = false;
            _responseAPI.Message.Add($"¡ERROR!");
            _responseAPI.Detail = response;
            return BadRequest(_responseAPI);
        }
    }
}
