﻿#pragma warning disable IDE0290
using API_PortalDocumentacion.Repository.IRepository;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authorization;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class DashboardController : ControllerBase
    {
        //Declaration of variables
        private readonly IDashboardRepository _dashboardRepo;
        private readonly ResponseAPI _responseAPI = new();

        //Class constructor
        public DashboardController(IDashboardRepository dashboardRepository)
        {
            _dashboardRepo = dashboardRepository;
        }

        [HttpPost]
        [Route("MostUsedElembyProj/{projectId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> MostUsedElembyProj(int projectId)
        {
            var request = _dashboardRepo.MostUsedElembyProj(projectId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("ElemTbyProj/{projectId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ElemTbyProj(int projectId)
        {
            var request = _dashboardRepo.ElemTbyProj(projectId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("ElembyElemTAndProj/{projectId}/{elementTypeId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ElembyElemTAndProj(int projectId, int elementTypeId)
        {
            var request = _dashboardRepo.ElembyElemTAndProj(projectId, elementTypeId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("MostUsedElembyProjAndMod/{projectId}/{moduleId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> MostUsedElembyProjAndMod(int projectId, int moduleId)
        {
            var request = _dashboardRepo.MostUsedElembyProjAndMod(projectId, moduleId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("ElemTbyProjAndMod/{projectId}/{moduleId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ElemTbyProjAndMod(int projectId, int moduleId)
        {
            var request = _dashboardRepo.ElemTbyProjAndMod(projectId, moduleId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("ElembyElemTProjAndMod")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ElembyElemTProjAndMod([FromBody] ElementbyET_Project_ModuleDTO elembyET_Proj_ModDTO)
        {
            var request = _dashboardRepo.ElembyElemTProjAndMod(elembyET_Proj_ModDTO.ProjectId, elembyET_Proj_ModDTO.ElementTypeId, elembyET_Proj_ModDTO.ModuleId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("GetElementsOrionByProj")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetElementsOrionByProj(int ProjectId)
        {
            var request = _dashboardRepo.GetElementOrionByProject(ProjectId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("GetElementsOrionByProAndMod")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetElementsOrionByProAndMod(ElementsOrionProAndModDTO ElemOProAndMod)
        {
            var request = _dashboardRepo.GetElementOrionByProAndMod(ElemOProAndMod.ProjectId, ElemOProAndMod.ModuleId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se a encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("GetProjectProgressWithModules/{ProjectId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetProjectProgressWithModules(int ProjectId)
        {
            var request = _dashboardRepo.GetProjectProgressWithModules(ProjectId);

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se ha encontrado información.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Estadísticas obtenidas!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        [HttpPost]
        [Route("GetModuleProgress/{ModuleId}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetModuleProgress(int ModuleId)
        {
            var request = _dashboardRepo.GetModuleProgress(ModuleId);
            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: No se ha encontrado información.");
                return BadRequest(_responseAPI);
            }
            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Estadísticas obtenidas!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }
    }
}
