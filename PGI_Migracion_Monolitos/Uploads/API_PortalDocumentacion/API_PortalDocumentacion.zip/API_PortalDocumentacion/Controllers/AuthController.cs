﻿using API_PortalDocumentacion.Repository.IRepository;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authorization;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        //Declaration of variables
        private readonly IAuthRepository _authRepo;
        private readonly IAdminRepository _adminRepo;
        private readonly ResponseAPI _responseAPI = new();

        //Class constructor
        public AuthController(IAuthRepository authRepository, IAdminRepository adminRepository)
        {
            _authRepo = authRepository;
            _adminRepo = adminRepository;
        }

        //API Login with local user, receives a model (corporate and password) and returns (corporate, full name and TOKEN)
        [HttpPost]
        [Route("LoginLocal")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> LoginLocal([FromBody] LoginRequestLocalDTO loginRequestLocalDTO)
        {
            var responseLogin = _authRepo.LoginLocal(loginRequestLocalDTO);

            //Corporate or password is incorrect ERROR 401
            if (responseLogin == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡El usuario o la contraseña son incorrectos, inténta de nuevo!");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(loginRequestLocalDTO.username, 1, 0, ""); //Action: 1 (Log In)

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Bienvenido al Portal de Documentación TI");
            _responseAPI.Detail = responseLogin;
            return Ok(_responseAPI);
        }

        //API Login with LDAP, receives a model (corporate and password) and returns (corporate, full name and TOKEN)
        [HttpPost]
        [Route("LoginLDAP")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> LoginLDAP([FromBody] LoginRequestLDAP_DTO loginRequestDTO)
        {
            var responseLogin = _authRepo.LoginLDAP(loginRequestDTO);

            //Unhandled error LDAP CODE 400
            if (responseLogin.Corporate == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: {responseLogin.Corporate}");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(loginRequestDTO.Corporate, 1, 0, ""); //Action: 1 (Log in)

            //user does not have projects assigned or not exist CODE 403
            if (responseLogin.Token == "")
            {
                _responseAPI.StatusCode = HttpStatusCode.Forbidden;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Usuario no autorizado, realiza la solicitud!");
                _responseAPI.Detail = responseLogin;
                return BadRequest(_responseAPI);
            }

            //Corporate or password is incorrect ERROR 401
            if (responseLogin.Corporate == "Invalid Credentials")
            {
                _responseAPI.StatusCode = HttpStatusCode.Unauthorized;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Corporativo o contraseña incorrectos!");
                return BadRequest(_responseAPI);
            }

            //User locked CODE 503
            if (responseLogin.Corporate == "Connect Error")
            {
                _responseAPI.StatusCode = HttpStatusCode.ServiceUnavailable;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No se pudo establecer una conexión con la red!");
                return BadRequest(_responseAPI);
            }

            //User locked CODE 423
            if (responseLogin.Corporate == "Locked")
            {
                _responseAPI.StatusCode = HttpStatusCode.Locked;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Usuario bloqueado!");
                return BadRequest(_responseAPI);
            }

            if (responseLogin.Corporate != loginRequestDTO.Corporate)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ocurrio un error al intentar hacer el inicio de sesión!");
                return BadRequest(_responseAPI);
            }

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Bienvenido al Portal de Documentación TI");
            _responseAPI.Detail = responseLogin;
            return Ok(_responseAPI);
        }

        //Renew expired token 
        [HttpPost]
        [Authorize]
        [Route("RenewToken/{corporate}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> RenewToken(string corporate, int countryId)
        {
            var responseLogin = _authRepo.CreateJWT(corporate, countryId);

            //Unhandled error LDAP CODE 400
            if (responseLogin == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: Ocurrio un error al generar el token.");
                return BadRequest(_responseAPI);
            }

            //user has projects assigned CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Token renovado");
            _responseAPI.Detail = responseLogin;
            return Ok(_responseAPI);
        }

        //Register logout
        [HttpPost]
        [Authorize]
        [Route("Logout/{corporate}")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> Logout(string corporate)
        {
            var responseLogout = _authRepo.Logout(corporate);
            //Corporate not found ERROR 400
            if (responseLogout == "No exist user")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡El corporativo es incorrecto!");
                return BadRequest(_responseAPI);
            }

            if (responseLogout == "Error")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al realizar la acción!");
                return BadRequest(_responseAPI);
            }

            //user has logged out successfully CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("Sesión cerrada con éxito");
            return Ok(_responseAPI);
        }
    }
}
