﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Repository.IRepository;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.IO.Compression;
using System.Text;
using System.Xml.Linq;
using textsVisios;
using VisioWebTools;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("api/[controller]")]
    public class ToolsController : ControllerBase
    {
        //Declaration of variables
        public readonly IAdminRepository _adminRepo;
        public readonly ResponseAPI _responseAPI = new();


        //API splitVisioMainframe
        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("SplitVisioMainFrame")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> SplitVisioMainFrame(IFormFile compressedFile)
        {
            if (compressedFile == null || compressedFile.Length == 0)
            {
                return BadRequest("Archivo no encontrado");
            }
            // Verificar la extensión del archivo (.zip o .rar)
            var fileExtension = Path.GetExtension(compressedFile.FileName);
            if (!fileExtension.Equals(".zip", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest("El tipo de archivo no es válido. Por favor sube un archivo .zip.");
            }
            // Crear una carpeta temporal para descomprimir el archivo
            var tempFolder = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempFolder);
            try
            {
                // Guardar el archivo en el sistema
                var filePath = Path.Combine(tempFolder, compressedFile.FileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await compressedFile.CopyToAsync(fileStream);
                }
                // Descomprimir archivo ZIP o RAR
                if (fileExtension.Equals(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    ZipFile.ExtractToDirectory(filePath, tempFolder);
                }
                // Buscar los archivos .vsdx
                string[] visioFiles = Directory.GetFiles(tempFolder, "*.vsdx", SearchOption.AllDirectories);
                if (visioFiles.Length == 0)
                {
                    return BadRequest("No se encontraron archivos Visio (.vsdx) en el archivo comprimido.");
                }
                else
                {
                    // Registrar el proveedor de codificación si es necesario
                    Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                    var output = SplitPagesService.SplitPagesMainframe(visioFiles);
                    return File(output, "application/zip", "pages.zip");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error procesando el archivo: {ex.Message}");
            }
            finally
            {
                // Limpiar la carpeta temporal
                if (Directory.Exists(tempFolder))
                {
                    Directory.Delete(tempFolder, true);
                }
            }
        }

        //API SplitVisio 
        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("SplitVisioZip")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> SplitVisioBroker(IFormFile compressedFile)
        {
            if (compressedFile == null || compressedFile.Length == 0)
            {
                return BadRequest("Archivo no encontrado");
            }
            // Verificar la extensión del archivo (.zip o .rar)
            var fileExtension = Path.GetExtension(compressedFile.FileName);
            if (!fileExtension.Equals(".zip", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest("El tipo de archivo no es válido. Por favor sube un archivo .zip.");
            }
            // Crear una carpeta temporal para descomprimir el archivo
            var tempFolder = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempFolder);
            try
            {
                // Guardar el archivo en el sistema
                var filePath = Path.Combine(tempFolder, compressedFile.FileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await compressedFile.CopyToAsync(fileStream);
                }
                // Descomprimir archivo ZIP o RAR
                if (fileExtension.Equals(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    ZipFile.ExtractToDirectory(filePath, tempFolder);
                }
                // Buscar los archivos .vsdx
                string[] visioFiles = Directory.GetFiles(tempFolder, "*.vsdx", SearchOption.AllDirectories);
                if (visioFiles.Length == 0)
                {
                    return BadRequest("No se encontraron archivos Visio (.vsdx) en el archivo comprimido.");
                }
                else
                {
                    // Registrar el proveedor de codificación si es necesario
                    Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                    var output = SplitPagesService.SplitPagesBroker(visioFiles);
                    return File(output, "application/zip", "pages.zip");

                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error procesando el archivo: {ex.Message}");
            }
            finally
            {
                // Limpiar la carpeta temporal
                if (Directory.Exists(tempFolder))
                {
                    Directory.Delete(tempFolder, true);
                }
            }
        }

        //API SplitVisio.
        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("SplitVisio")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> SplitVisio(IFormFile vsdx)
        {
            if (vsdx == null || vsdx.Length == 0)
            {
                return BadRequest("Archivo no encontrado");
            }

            // Verificar la extensión del archivo
            var fileExtension = Path.GetExtension(vsdx.FileName);
            if (!fileExtension.Equals(".vsdx", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest("El tipo de archivo no es valido. Por favor sube un archivo .vsdx.");
            }

            // Registrar el proveedor de codificación si es necesario
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            // Leer los datos del archivo en un array de bytes
            using (var stream = vsdx.OpenReadStream())
            {
                var output = SplitPagesService.SplitPages(stream);

                // Devolver el archivo zip como respuesta
                return File(output, "application/zip", "pages.zip");
            }
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("DiagramaElementCounter")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> DiagramElementCounter(IFormFile compressedFile)
        {
            CountFigure elem = new CountFigure();

            if (compressedFile == null || compressedFile.Length == 0)
            {
                return BadRequest("Archivo no encontrado");
            }

            // Verificar la extensión del archivo (.zip o .rar)
            var fileExtension = Path.GetExtension(compressedFile.FileName);
            if (!fileExtension.Equals(".zip", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest("El tipo de archivo no es válido. Por favor sube un archivo .zip.");
            }

            // Crear una carpeta temporal para descomprimir el archivo
            var tempFolder = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempFolder);

            try
            {
                // Guardar el archivo en el sistema
                var filePath = Path.Combine(tempFolder, compressedFile.FileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await compressedFile.CopyToAsync(fileStream);
                }

                // Descomprimir archivo ZIP o RAR
                if (fileExtension.Equals(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    ZipFile.ExtractToDirectory(filePath, tempFolder);
                }

                // Buscar los archivos .vsdx
                string[] visioFiles = Directory.GetFiles(tempFolder, "*.vsdx", SearchOption.AllDirectories);

                if (visioFiles.Length == 0)
                {
                    return BadRequest("No se encontraron archivos Visio (.vsdx) en el archivo comprimido.");
                }

                // Crear un archivo Excel y procesar los archivos .vsdx
                string excelFilePath = Path.Combine(tempFolder, "Data.xlsx");
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("Data");

                    // Inicializar encabezados (debes implementar este método)
                    elem.InitializeWorksheetHeaders(worksheet);

                    int currentRow = 2; // Comienza en la fila 2, ya que la 1 es para los encabezados

                    foreach (var visioFilePath in visioFiles)
                    {
                        // Procesar cada archivo Visio (debes implementar este método)
                        elem.OpenVisio(visioFilePath, worksheet, ref currentRow);
                    }

                    // Guardar el archivo Excel
                    workbook.SaveAs(excelFilePath);
                }

                // Devolver el archivo Excel generado al cliente
                var fileBytes = await System.IO.File.ReadAllBytesAsync(excelFilePath);
                return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Data.xlsx");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error procesando el archivo: {ex.Message}");
            }
            finally
            {
                // Limpiar la carpeta temporal
                if (Directory.Exists(tempFolder))
                {
                    Directory.Delete(tempFolder, true);
                }
            }
        }

    }
}
