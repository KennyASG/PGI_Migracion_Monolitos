#pragma warning disable IDE0290
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Repository.IRepository;
using DocumentFormat.OpenXml.Packaging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System.Net;
using System.Text.RegularExpressions;

namespace API_PortalDocumentacion.Controllers
{
    [EnableCors()]
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        //Declaration of variables
        public readonly IAdminRepository _adminRepo;
        public readonly ResponseAPI _responseAPI = new();

        //Class constructor
        public AdminController(IAdminRepository adminRepository)
        {
            _adminRepo = adminRepository;
        }

        [HttpPost]
        [Route("ShowSystemRequest")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ShowSystemRequest()
        {
            var request = _adminRepo.ShowSystemRequest();

            if (request == null)
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"No se encontraron solicitudes.");
                return BadRequest(_responseAPI);
            }

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = request;
            return Ok(_responseAPI);
        }

        //API Login, receives a model (corporate and password) and returns (corporate, full name and TOKEN)
        [HttpPost]
        [Route("ApproveRequest")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ApproveRequest([FromBody] ShowSystemRequest showSystemRequest)
        {
            // Validate that the parameter only contains numbers
            if (!Regex.IsMatch(showSystemRequest.Corporate, @"^\d+$", RegexOptions.Compiled))
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("El parámetro 'corporate' solo debe contener números.");
                return BadRequest(_responseAPI);
            }

            if(showSystemRequest.CountryId == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("El país es requerido");
                return BadRequest(_responseAPI);
            }

            var UserRequest = _adminRepo.ApproveRequest(showSystemRequest);

            //CODE 400
            if (UserRequest == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"¡No hay solicitudes para el corporativo {showSystemRequest.Corporate}!");
                return BadRequest(_responseAPI);
            }

            if (UserRequest == "Denegado")
            {
                _adminRepo.SaveLog(showSystemRequest.ActionUser, 7, 0, ""); //Action: 7 (Deneged Request)

                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.Forbidden;
                _responseAPI.IsSuccess = true;
                _responseAPI.Message.Add($"¡La solicitud del usuario {showSystemRequest.Corporate} fue rechazada exitosamente!");
                return Ok(_responseAPI);
            }

            if (UserRequest != "Aprobado") 
            {
                //CODE 400
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add($"ERROR: {UserRequest}");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(showSystemRequest.ActionUser, 6, 0, ""); //Action: 6 (Approve Request)

            //CODE 200 
            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Usuario creado y proyectos asignados!");
            return Ok(_responseAPI);

        }

        //API CreateNewContent, Insert data in the database.
        [HttpPost]
        [Route("CreateNewContentLogicalLayer")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateContentLL(BodyFormCreateCont bodyFormCC)
        {
            int count = 0;
            string response;

            if (bodyFormCC.file == null || bodyFormCC.file.Length == 0)
                return BadRequest("Archivo no seleccionado");

            using (var stream = new MemoryStream())
            {
                try
                {
                    await bodyFormCC.file.CopyToAsync(stream);
                    using (var package = new ExcelPackage(stream))
                    {
                        Parameters_LogicalLayer PLL = new();

                        var worksheet = package.Workbook.Worksheets[0];
                        string tempProj = "", tempMod = "", tempOpt = "", tempDiagN = "", tempSys = "", tempElemtt = "", tempElem = "";

                        for (int row = 2; row <= worksheet.Dimension.Rows; row++)
                        {
                            PLL.project = worksheet.Cells[row, 1].Value.ToString();
                            PLL.module = worksheet.Cells[row, 2].Value.ToString();
                            PLL.option = worksheet.Cells[row, 3].Value == null ? " " : worksheet.Cells[row, 3].Value.ToString();
                            PLL.diagramName = worksheet.Cells[row, 4].Value.ToString();
                            PLL.fileName = worksheet.Cells[row, 5].Value.ToString();
                            PLL.system = worksheet.Cells[row, 6].Value == null ? " " : worksheet.Cells[row, 6].Value.ToString();
                            PLL.elementt = worksheet.Cells[row, 7].Value == null ? " " : worksheet.Cells[row, 7].Value.ToString();
                            PLL.element = worksheet.Cells[row, 8].Value == null ? " " : worksheet.Cells[row, 8].Value.ToString();
                            PLL.classification = worksheet.Cells[row, 9].Value == null ? " " : worksheet.Cells[row, 9].Value.ToString();
                            PLL.fileExtension = worksheet.Cells[row, 10].Value == null ? " " : worksheet.Cells[row, 10].Value.ToString();

                            if (PLL.diagramName != tempDiagN || PLL.module != tempMod || PLL.option != tempOpt || PLL.diagramName != tempDiagN)
                            {
                                await _adminRepo.DisableContent(PLL);

                                tempDiagN = PLL.diagramName;
                                tempMod = PLL.module;
                                tempOpt = PLL.option;
                                tempProj = PLL.diagramName;
                            }

                            await _adminRepo.CreateNewContentLogicalLayer(PLL);
                           
                            count++;
                        }

                        tempDiagN = "";
                        tempMod = "";
                        tempOpt = "";
                        tempProj = "";
                    }

                    response = "Registros insertados: " + count;

                    _adminRepo.SaveLog(bodyFormCC.corporate, 9, 0, ""); //Action: 9 (uploading new content Logical Layer)

                    _responseAPI.StatusCode = HttpStatusCode.OK;
                    _responseAPI.IsSuccess = true;
                    _responseAPI.Message.Add("¡Información insertada satisfactoriamente!");
                    _responseAPI.Detail = response;
                    return Ok(_responseAPI);
                }
                catch (Exception ex)
                {
                    response = ex.Message;
                    _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                    _responseAPI.IsSuccess = false;
                    _responseAPI.Message.Add("¡Ocurrio un error mientras se insertaban los registros!");
                    _responseAPI.Detail = ex;
                    return BadRequest(_responseAPI);
                }
            }
            count = 0;
        }

        //API CreateNewContent, Insert data in the database.
        [HttpPost]
        [Route("CreateNewContentPhysicalLayer")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateContentPL(BodyFormCreateCont bodyFormCC)
        {
            int count = 0;
            string response;

            if (bodyFormCC.file == null || bodyFormCC.file.Length == 0)
                return BadRequest("Archivo no seleccionado");

            using (var stream = new MemoryStream())
            {
                try
                {
                    await bodyFormCC.file.CopyToAsync(stream);
                    using (var package = new ExcelPackage(stream))
                    {
                        Parameters_PhysicalLayer PPL = new();

                        var worksheet = package.Workbook.Worksheets[0];
                        //string tempProj = "", tempMod = "", tempOpt = "", tempDiagN = "", tempSys = "", tempElemtt = "", tempElem = "";

                        for (int row = 2; row <= worksheet.Dimension.Rows; row++)
                        {
                            PPL.project = worksheet.Cells[row, 1].Value.ToString();
                            PPL.module = worksheet.Cells[row, 2].Value == null ? " " : worksheet.Cells[row, 2].Value.ToString();
                            PPL.option = worksheet.Cells[row, 3].Value == null ? " " : worksheet.Cells[row, 3].Value.ToString();
                            PPL.diagramName = worksheet.Cells[row, 4].Value.ToString();
                            PPL.fileName = worksheet.Cells[row, 5].Value.ToString();
                            PPL.logicalConn = worksheet.Cells[row, 6].Value == null ? " " : worksheet.Cells[row, 6].Value.ToString();
                            PPL.service = worksheet.Cells[row, 7].Value == null ? " " : worksheet.Cells[row, 7].Value.ToString();
                            PPL.locationA = worksheet.Cells[row, 8].Value == null ? " " : worksheet.Cells[row, 8].Value.ToString();
                            PPL.areaA = worksheet.Cells[row, 9].Value == null ? " " : worksheet.Cells[row, 9].Value.ToString();
                            PPL.platformA = worksheet.Cells[row, 10].Value == null ? " " : worksheet.Cells[row, 10].Value.ToString();
                            PPL.elementtA = worksheet.Cells[row, 11].Value == null ? " " : worksheet.Cells[row, 11].Value.ToString();
                            PPL.elementA = worksheet.Cells[row, 12].Value == null ? " " : worksheet.Cells[row, 12].Value.ToString();
                            PPL.ipA = worksheet.Cells[row, 13].Value == null ? " " : worksheet.Cells[row, 13].Value.ToString();
                            PPL.interfaceA = worksheet.Cells[row, 14].Value == null ? " " : worksheet.Cells[row, 14].Value.ToString();
                            PPL.locationZ = worksheet.Cells[row, 15].Value == null ? " " : worksheet.Cells[row, 15].Value.ToString();
                            PPL.areaZ = worksheet.Cells[row, 16].Value == null ? " " : worksheet.Cells[row, 16].Value.ToString();
                            PPL.platformZ = worksheet.Cells[row, 17].Value == null ? " " : worksheet.Cells[row, 17].Value.ToString();
                            PPL.elementtZ = worksheet.Cells[row, 18].Value == null ? " " : worksheet.Cells[row, 18].Value.ToString();
                            PPL.elementZ = worksheet.Cells[row, 19].Value == null ? " " : worksheet.Cells[row, 19].Value.ToString();
                            PPL.ipZ = worksheet.Cells[row, 20].Value == null ? " " : worksheet.Cells[row, 20].Value.ToString();
                            PPL.interfaceZ = worksheet.Cells[row, 21].Value == null ? " " : worksheet.Cells[row, 21].Value.ToString();
                            PPL.classification = worksheet.Cells[row, 22].Value == null ? " " : worksheet.Cells[row, 22].Value.ToString();
                            PPL.fileExtension = worksheet.Cells[row, 23].Value == null ? " " : worksheet.Cells[row, 23].Value.ToString();

                            //if (PLL.diagramName != tempDiagN || PLL.module != tempMod || PLL.option != tempOpt || PLL.diagramName != tempDiagN)
                            //{
                            //    await _adminRepo.DisableContent(PLL);

                            //    tempDiagN = PLL.diagramName;
                            //    tempMod = PLL.module;
                            //    tempOpt = PLL.option;
                            //    tempProj = PLL.diagramName;
                            //}

                            await _adminRepo.CreateNewContentPhysicalLayer(PPL);

                            count++;
                        }
                    }

                    response = "Registros insertados: " + count;

                    _adminRepo.SaveLog(bodyFormCC.corporate, 10, 0, ""); //Action: 10 (uploading new content Physical Layer)

                    _responseAPI.StatusCode = HttpStatusCode.OK;
                    _responseAPI.IsSuccess = true;
                    _responseAPI.Message.Add("¡Información insertada satisfactoriamente!");
                    _responseAPI.Detail = response;
                    return Ok(_responseAPI);
                }
                catch (Exception ex)
                {
                    response = ex.Message;
                    _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                    _responseAPI.IsSuccess = false;
                    _responseAPI.Message.Add("¡Ocurrio un error mientras se insertaban los registros!");
                    _responseAPI.Detail = ex;
                    return BadRequest(_responseAPI);
                }
            }
            count = 0;
        }

        //API CreateLocalUser.
        [HttpPost]
        [Route("CreateLocalUser")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult CreateLocalUser([FromBody] CreateLocalUserDTO createLocalUserDTO)
        {
            if (createLocalUserDTO.CountryId == 0)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No se indico el país del usuario!");
                return BadRequest(_responseAPI);
            }

            string response = _adminRepo.CreateUser(createLocalUserDTO);

            if (response == "User exist")
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No se puede crear el usuario debido a que el usuario ya existe!");
                return BadRequest(_responseAPI);
            }

            if (response == "Successfully created")
            {
                _responseAPI.StatusCode = HttpStatusCode.OK;
                _responseAPI.IsSuccess = true;
                _responseAPI.Message.Add("Usuario y permisos creados con éxito. Se enviaron las credenciales al correo del usuario.");
                return Ok(_responseAPI);
            }

            _adminRepo.SaveLog(createLocalUserDTO.ActionUser, 9, 0, ""); //Action: 3 (Create local user)

            _responseAPI.StatusCode = HttpStatusCode.BadRequest;
            _responseAPI.IsSuccess = false;
            _responseAPI.Message.Add("¡ERROR!");
            _responseAPI.Detail = response;
            return BadRequest(_responseAPI);

        }

        //API Assigned Permission
        [HttpPost]
        [ResponseCache(CacheProfileName = "Default20Seconds")]
        [Route("AssignedPermissions")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult AssignedPermissions()
        {
            var response = _adminRepo.AssignedPermissions();

            if (response == null)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡No existen permisos!");
                return BadRequest(_responseAPI);
            }

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Búsqueda satisfactoria!");
            _responseAPI.Detail = response;
            return Ok(_responseAPI);

        }

        //API Update Permission
        [HttpPost]
        [Route("UpdateProjects")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult UpdateProjects(AssignProjectsDTO assignProjectsDTO)
        {
            var response = _adminRepo.UpdateProjects(assignProjectsDTO);

            if (!response)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al actualizar o asignar el proyecto al usuario!");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(assignProjectsDTO.ActionUser, 4, 0, ""); //Action: 4 (updating projects to user)

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Actualización o asignación realizada con éxito!");
            return Ok(_responseAPI);
        }

        //API Update Permission
        [HttpPost]
        [Route("UpdateRoles")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult UpdateRoles(AssignRolesDTO assignRolesDTO)
        {
            var response = _adminRepo.UpdateUserRoles(assignRolesDTO);

            if (!response)
            {
                _responseAPI.StatusCode = HttpStatusCode.BadRequest;
                _responseAPI.IsSuccess = false;
                _responseAPI.Message.Add("¡Ha ocurrido un error al actualizar o asignar nuevos roles al usuario!");
                return BadRequest(_responseAPI);
            }

            _adminRepo.SaveLog(assignRolesDTO.ActionUser, 5, 0, ""); //Action: 5 (Updating roles to user)

            _responseAPI.StatusCode = HttpStatusCode.OK;
            _responseAPI.IsSuccess = true;
            _responseAPI.Message.Add("¡Actualización o asignación realizada con éxito!");
            return Ok(_responseAPI);
        }
    }
}
