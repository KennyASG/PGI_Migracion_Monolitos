﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class UpdateMatrixModel
    {
        [Required(ErrorMessage = "El usuario que autoriza es requerido")]
        public string ActionUser { get; set; }
        [Required(ErrorMessage = "El id de la matriz es requerido")]
        public int MatrixId { get; set; } = 0;
        [Required(ErrorMessage = "El id del diagrama es requerido")]
        public int DiagramId { get; set; } = 0;
        public bool? HasDynatrace { get; set; }
        [Required(ErrorMessage = "La lista de detalles actualizados es requerida")]
        public List<UpdatedDetail> UpdatedDetails { get; set; }

        public class UpdatedDetail { 
            public int Id { get; set; }
            public int Status { get; set; }
        }
    }
}
