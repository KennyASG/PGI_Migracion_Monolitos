﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Connection
{
    public int ConnectionId { get; set; }

    public int DiagramId { get; set; }

    public int? FInterfaceId { get; set; }

    public int? SInterfaceId { get; set; }

    public string? Description { get; set; }

    public int? ServiceId { get; set; }

    public bool Active { get; set; }

    public DateTime? LastUpdate { get; set; }

    public DateTime CreationDate { get; set; }

    public string? LogicalConnection { get; set; }

    public virtual Diagram Diagram { get; set; } = null!;

    public virtual Interface? FInterface { get; set; }

    public virtual Interface? SInterface { get; set; }
}
