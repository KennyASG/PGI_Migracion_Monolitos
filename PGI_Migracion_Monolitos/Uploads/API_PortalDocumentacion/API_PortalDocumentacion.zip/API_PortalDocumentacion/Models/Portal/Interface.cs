﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Interface
{
    public int InterfaceId { get; set; }

    public int ElementId { get; set; }

    public string InterfaceName { get; set; } = null!;

    public string? Description { get; set; }

    public bool Active { get; set; }

    public DateTime CreationDate { get; set; }

    public virtual ICollection<Connection> ConnectionFInterfaces { get; set; } = new List<Connection>();

    public virtual ICollection<Connection> ConnectionSInterfaces { get; set; } = new List<Connection>();

    public virtual Element Element { get; set; } = null!;
}
