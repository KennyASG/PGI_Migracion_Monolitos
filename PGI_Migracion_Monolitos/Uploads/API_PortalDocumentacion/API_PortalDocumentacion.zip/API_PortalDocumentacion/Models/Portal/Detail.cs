﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Detail
{
    public int DetailId { get; set; }

    public int DiagramId { get; set; }

    public int SystemId { get; set; }

    public int ElementId { get; set; }

    public string? Name { get; set; }

    public int Repetition { get; set; }

    public string? Description { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public int Version { get; set; }

    public virtual Diagram Diagram { get; set; } = null!;

    public virtual Element Element { get; set; } = null!;

    public virtual System System { get; set; } = null!;
}
