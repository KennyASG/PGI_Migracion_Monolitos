﻿using System.ComponentModel.DataAnnotations;
using DocumentFormat.OpenXml.Office.CoverPageProps;

namespace API_PortalDocumentacion.Models.Portal
{
    public class DeleteProjectModel
    {
        [Required(ErrorMessage = "El usuario es requerido")]
        public string ActionUser { get; set; }
        [Required(ErrorMessage = "El proyecto es requerido")]
        public int ProjectId { get; set; } = 0;
        [Required(ErrorMessage = "El comentario es requerido")]
        public string Comment { get; set; }
    }
}
