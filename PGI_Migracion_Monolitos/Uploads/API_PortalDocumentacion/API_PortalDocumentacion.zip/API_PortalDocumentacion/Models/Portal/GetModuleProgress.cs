﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class GetModuleProgress
    {
        public decimal CurrentPercentage { get; set; }
        public int CurrentPoints { get; set; }
        public int PointsByMatrix { get; set; }
        public int CompletedDiagrams { get; set; }
        public int PointsByCompletedDiagrams { get; set; }
        public int TotalPossiblePoints { get; set; }
        public int TotalDiagramsInModule { get; set; }
        public List<OptionProgress> Options { get; set; }
    }
    public class OptionProgress
    {
        public int? OptionId { get; set; }
        public string? OptionName { get; set; }
        public decimal CurrentPercentage { get; set; }
        public int CurrentPoints { get; set; }
        public int PointsByMatrix { get; set; }
        public int CompletedDiagrams { get; set; }
        public int PointsByCompletedDiagrams { get; set; }
        public int TotalPossiblePoints { get; set; }
        public int TotalDiagramsInOption { get; set; }
    }
}
