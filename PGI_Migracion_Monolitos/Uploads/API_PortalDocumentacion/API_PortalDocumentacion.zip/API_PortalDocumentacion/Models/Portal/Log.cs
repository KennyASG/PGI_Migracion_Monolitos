﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Log
{
    public int LogId { get; set; }

    public string Corporate { get; set; } = null!;

    public DateTime? Date { get; set; }

    public int LaId { get; set; }

    public int? DiagramId { get; set; }

    public string? Comment { get; set; }

    public virtual LogAction La { get; set; } = null!;
}
