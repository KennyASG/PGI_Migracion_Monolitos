﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class MenuItem
{
    public int Id { get; set; }
    public int? ParentId { get; set; }
    public string DisplayText { get; set; } = null!;
    public int? DiagramId { get; set; }
    public int Level { get; set; }
    public int? ProjectId { get; set; }
    public int? ModuleId { get; set; }
    public int? LayerId { get; set; }
    public bool? isModule { get; set; }
    public string? Classification { get; set; }
    public int? OptionId { get; set; }
    public int? CountryId { get; set; }
    public string? CountryCode { get; set; }
    public string? CountryName { get; set; }
    public virtual ICollection<MenuItem> Children { get; set; } = new List<MenuItem>();
}
