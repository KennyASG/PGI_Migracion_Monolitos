﻿using API_PortalDocumentacion.Models.Portal.Dtos;

namespace API_PortalDocumentacion.Models.Portal
{
    public class GetProModOptDiag
    {
        public int Id { get; set; }
        public int? ParentId { get; set; }
        public string DisplayText { get; set; } = null!;
        public int? DiagramId { get; set; }
        public int Level { get; set; }
        public int? ProjectId { get; set; }
        public virtual ICollection<ProjectCollaboratorsModel> Collaborators { get; set; } = new List<ProjectCollaboratorsModel>();
        public int? ModuleId { get; set; }
        public int? LayerId { get; set; }
        public string? LayerName { get; set; }
        public int? Classification { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
        public DateTime? CreationDate { get; set; }
        public int? OptionId { get; set; } 
        public int? CountryId { get; set; }
        public string? CountryCode { get; set; }
        public string? CountryName { get; set; }
        public virtual ICollection<GetProModOptDiag> Children { get; set; } = new List<GetProModOptDiag>();
    }
}
