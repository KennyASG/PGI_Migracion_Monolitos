﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class GetAdminNotificationModel
    {
        [Required(ErrorMessage = "El usuario es requerido")]
        public string Corporate { get; set; }
        public int NotificationStatus { get; set; } = 0;
    }
}
