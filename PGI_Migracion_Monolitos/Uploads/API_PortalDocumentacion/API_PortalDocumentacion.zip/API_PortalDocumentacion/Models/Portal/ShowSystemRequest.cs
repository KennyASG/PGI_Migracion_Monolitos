﻿using API_PortalDocumentacion.Models.Portal.Dtos;
using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public class ShowSystemRequest
{
    public string ActionUser { get; set; }
    public int SrId { get; set; }
    public string Corporate { get; set; }
    public string Name { get; set; }
    public string Department { get; set; }
    public string Job { get; set; }
    public bool? AuthorizedRequest { get; set; }
    public int CountryId { get; set; } = 0;
    public string? CountryName { get; set; }
    public string? CountryCode { get; set; }
    public List<ShowSystemRequestDetail> ProjectsRequest { get; set; } = new List<ShowSystemRequestDetail>();
}

public class ShowSystemRequestDetail
{
    public int SrdId { get; set; }
    //public int SrId { get; set; }
    public int ProjectId { get; set; }
    public int? layerId { get; set; }
    public string ProjectName { get; set; }
    public bool? AuthorizedDetail { get; set; }
    public bool Active { get; set; }
    public DateTime? CreationDate { get; set; }
}
