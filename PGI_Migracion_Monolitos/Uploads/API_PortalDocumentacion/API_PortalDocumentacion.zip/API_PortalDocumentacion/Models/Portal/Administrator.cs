﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Administrator
{
    public int AdminId { get; set; }

    public string? Area { get; set; }

    public string? AdminName { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual ICollection<Element> Elements { get; set; } = new List<Element>();
}
