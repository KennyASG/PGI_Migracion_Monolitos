﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Platform
{
    public int PlatformId { get; set; }

    public string PlatformName { get; set; } = null!;

    public string? Observations { get; set; }

    public bool Active { get; set; }

    public DateTime CreationDate { get; set; }

    public virtual ICollection<Monitoring> Monitorings { get; set; } = new List<Monitoring>();
}
