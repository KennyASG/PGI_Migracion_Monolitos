﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class GetUserCountriesModel
    {
        public string CountryCode { get; set; }
        public int Id { get; set; } = 0;
        public string CountryName { get; set; }
        public bool HasLogicalProjects { get; set; } = false;
        public bool HasPhysicalProjects { get; set; } = false;
    }
}
