﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class GetMatrixAndDetailModel
    {
        public int MatrixId { get; set; }
        public bool HasDynatrace { get; set; }
        public bool HasFile { get; set; } = false;
        public int Percentage { get; set; }
        public bool? Active { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? FinishDate { get; set; }
        public List<Detail>? Details { get; set; }
        public class Detail
        {
            public int DetailId { get; set; }
            public string DetailName { get; set; }
            public int ScoreDynatrace { get; set; }
            public int ScoreNoDynatrace { get; set; }
            public DateTime? UpdateDate { get; set; }
            public int DetailStatus { get; set; }
            public string StatusDescription { get; set; }
        }
    }
}
