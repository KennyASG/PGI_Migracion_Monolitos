﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class MatrixOption
{
    public int MoptionId { get; set; }

    public string Name { get; set; } = null!;

    public bool Active { get; set; }

    public int ScoreDynatrace { get; set; }

    public int ScoreNoDynatrace { get; set; }

    public DateTime CreationDate { get; set; }

    public virtual ICollection<MatrixDetail> MatrixDetails { get; set; } = new List<MatrixDetail>();

    public virtual ICollection<MatrixTemplateDetail> MatrixTemplateDetails { get; set; } = new List<MatrixTemplateDetail>();
}
