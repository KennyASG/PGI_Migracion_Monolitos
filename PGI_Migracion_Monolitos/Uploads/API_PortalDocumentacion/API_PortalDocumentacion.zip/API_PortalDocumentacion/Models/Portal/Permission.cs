﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Permission
{
    public int Id { get; set; }

    public string Corporate { get; set; } = null!;

    public int ProjectId { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual User CorporateNavigation { get; set; } = null!;
}
