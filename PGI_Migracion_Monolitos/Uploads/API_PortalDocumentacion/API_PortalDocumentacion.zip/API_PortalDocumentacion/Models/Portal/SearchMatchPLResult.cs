﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class SearchMatchPLResult
    {
        public int DiagramId { get; set; }
        public string Diagram { get; set; }
        public string Module { get; set; }
        public string? Option { get; set; }
        public int ElementId { get; set; }
        public string Element { get; set; }
        public string ServiceName { get; set; }
        public string Project { get; set; }
        public string IpAdministration { get; set; }
        public int CountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
    }
}
