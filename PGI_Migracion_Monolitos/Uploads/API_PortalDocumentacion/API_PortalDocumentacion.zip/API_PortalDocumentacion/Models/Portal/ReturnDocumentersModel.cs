﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class ReturnDocumentersModel
    {
        public string corporate {  get; set; }
        public string name { get; set; }
    }
}
