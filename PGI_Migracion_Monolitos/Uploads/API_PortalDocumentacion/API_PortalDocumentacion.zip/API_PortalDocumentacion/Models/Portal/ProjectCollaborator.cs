﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class ProjectCollaborator
{
    public int PcId { get; set; }

    public int ProjectId { get; set; }

    public string Corporate { get; set; } = null!;

    public bool? Active { get; set; }

    public DateTime? CreateDate { get; set; }

    public virtual User CorporateNavigation { get; set; } = null!;

    public virtual Project Project { get; set; } = null!;
}
