﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class ElementsOrion
    {
        public int ElementId { get; set; }
        public string Element {  get; set; }
        public string IpAdministration { get; set; }
        public string Location { get; set; }
        public string ElementType { get; set; }
        public string Interface { get; set; }
    }
}
