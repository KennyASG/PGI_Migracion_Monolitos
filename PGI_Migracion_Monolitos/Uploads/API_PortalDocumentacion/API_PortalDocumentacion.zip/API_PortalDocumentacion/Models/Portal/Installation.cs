﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Installation
{
    public int InstallationId { get; set; }

    public int InstallTypeId { get; set; }

    public string? InstallationNumber { get; set; }

    public string? UpdateReason { get; set; }

    public DateTime? InstallationDate { get; set; }

    public int DiagramId { get; set; }

    public int Version { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual Diagram Diagram { get; set; } = null!;

    public virtual InstallType InstallType { get; set; } = null!;
}
