﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class MachineType
{
    public int MtId { get; set; }

    public string MtName { get; set; } = null!;

    public string? Color { get; set; }

    public string? Icon { get; set; }

    public int? Size { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreateDate { get; set; }

    public virtual ICollection<Machine> Machines { get; set; } = new List<Machine>();
}
