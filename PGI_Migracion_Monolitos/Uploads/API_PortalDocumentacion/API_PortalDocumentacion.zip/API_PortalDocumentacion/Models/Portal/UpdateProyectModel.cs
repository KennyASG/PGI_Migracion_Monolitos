﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class UpdateProjectsModel
    {
        [Required]
        public string actionUser { get; set; }
        public string? assgnedCorporate { get; set; }
        public int? ProjectId { get; set; } = 0;
        public string ProjectName { get; set; }

        public List<UpdateModule>? updateModule { get; set; }
        public List<UpdateDiagram>? updateDiagram { get; set; }
    }

    public class UpdateModule
    {
        public int? moduleId { get; set; } = 0;
        public string moduleName { get; set; }
        public string assignedCorporate { get; set; }
    }

    public class UpdateOption
    {
        public int? optionId { get; set; } = 0;
        public string optionName { get; set; }
    }

    public class UpdateDiagram
    {
        public int? diagramId { get; set; } = 0;
        public string diagramName { get; set; }
        public string assignedCorporate { get; set; }
    }
}
