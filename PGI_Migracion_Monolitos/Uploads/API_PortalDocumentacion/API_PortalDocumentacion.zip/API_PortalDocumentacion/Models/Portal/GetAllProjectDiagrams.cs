﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class GetAllProjectDiagrams
    {
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
        public int? OptionId { get; set; }
        public int DiagramId { get; set; }
        public int SpId { get; set; }
        public int? Percentage { get; set; }
    }
}
