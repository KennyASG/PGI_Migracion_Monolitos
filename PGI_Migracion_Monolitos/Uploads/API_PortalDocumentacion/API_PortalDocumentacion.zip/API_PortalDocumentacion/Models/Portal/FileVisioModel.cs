﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal;

public partial class FileVisioModel
{
    [Required]
    public IFormFile FileVisio { get; set; }

    [Required]
    public int Diagram { get; set; } = 0;

    [Required]
    public int flag { get; set; } = 0;

    public string? Corporate { get; set; }
}
