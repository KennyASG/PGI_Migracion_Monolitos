﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class MatrixTemplate
{
    public int MtemplateId { get; set; }

    public int ProjectId { get; set; }

    public bool Active { get; set; }

    public DateTime CreationDate { get; set; }

    public virtual ICollection<MatrixTemplateDetail> MatrixTemplateDetails { get; set; } = new List<MatrixTemplateDetail>();

    public virtual Project Project { get; set; } = null!;
}
