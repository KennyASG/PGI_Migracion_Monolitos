﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class ChangeNotificationStatusModel
    {
        public int NotificationId { get; set; } = 0;
        public int DiagramId { get; set; } = 0;
        public string? Comment { get; set; }
        [Required(ErrorMessage = "El usuario quien autoriza es requerido")]
        public string ActionUser { get; set; }
    }
}
