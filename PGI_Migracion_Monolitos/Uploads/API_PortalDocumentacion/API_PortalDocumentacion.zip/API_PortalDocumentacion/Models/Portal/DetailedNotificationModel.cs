﻿using System;
using System.Collections.Generic;
using API_PortalDocumentacion.Models.Portal;
namespace API_PortalDocumentacion.Models.Portal
{
    public class DetailedNotificationModel
    {

        public int NotificationId { get; set; }
        public string? SenderCorporate { get; set; }
        public String? SenderName { get; set; }
        public DateTime CreationDate { get; set; }
        public bool IsUnread { get; set; }
        public string? Title { get; set; }
        public string? Body { get; set; }
        public string? Comment { get; set; }
        public int? DiagramId { get; set; }
        public String ProjectName { get; set; }
        public String ModuleName { get; set; }
        public String? OptionName { get; set; }
        public String DiagramName { get; set; }
        public String? FilePath { get; set; }
        public int NotificationStatus { get; set; }
        public DateTime? RelatedNotificationDate { get; set; }
        public bool? WasSent { get; set; }
        public int? CountryId { get; set; }
        public string? CountryCode { get; set; }
        public string? CountryName { get; set; }
    }
}
