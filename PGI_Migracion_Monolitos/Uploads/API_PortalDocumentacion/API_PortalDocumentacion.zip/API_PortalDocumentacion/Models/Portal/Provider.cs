﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Provider
{
    public int ProviderId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool? External { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual ICollection<Element> ElementDevByNavigations { get; set; } = new List<Element>();

    public virtual ICollection<Element> ElementMaintByNavigations { get; set; } = new List<Element>();
}
