﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class CreateProjectModel
    {
        [Required(ErrorMessage = "El corporativo quien autoriza es requerido")]
        public string ActionUser { get; set; }

        [Required(ErrorMessage = "El nombre de proyecto es requerido")]
        public string ProjectName { get; set; }

        [Required(ErrorMessage = "La capa es requerida")]
        public int LayerId { get; set; } = 1;

        [Required(ErrorMessage = "La classificación del proyecto es requerido")]
        public int ClassificationId { get; set; } = 1;

        [Required(ErrorMessage = "El país es requerido")]
        public int CountryId { get; set; } = 1;
        public List<string>? AssignDocumenters { get; set; }
        public List<ModulesModel> modules { get; set; }
    }

    public class ModulesModel
    {
        public string ModuleName { get; set; }
        public List<DiagramModel> Diagram { get; set; }
    }

    public class DiagramModel 
    {
        [Required(ErrorMessage = "El nombre del diagrama es requerido")]
        public string DiagramName { get; set; }
        public string? OptionName { get; set; } = "";
    }
}
