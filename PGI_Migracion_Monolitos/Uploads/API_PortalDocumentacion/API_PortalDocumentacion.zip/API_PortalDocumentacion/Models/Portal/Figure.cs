namespace API_PortalDocumentacion.Models.Portal
{
    public class Figure
    {
        public string Name { get; set; }
        public string Function { get; set; }
        public string Service { get; set; }
        public string Element { get; set; }
        public string Method { get; set; }
        public string Project { get; set; }
        public string Module { get; set; }
        public string Option { get; set; }
        public string Diagram { get; set; }
        public string Archive { get; set; }
        public string Type { get; set; }

        public Figure() { }

        public Figure(string name, string function, string service, string element, string project, string module, string option, string diagram, string type, string method)
        {
            Name = name;
            Function = function;
            Service = service;
            Element = element;
            Method = method;
            Project = project;
            Module = module;
            Option = option;
            Diagram = diagram;
            Archive = option?.ToUpper();
            Type = type;
        }
    }
}
