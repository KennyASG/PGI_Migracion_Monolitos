﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class AssignDocumentersModel
    {
        [Required]
        public int State { get; set; } = 0;
        [Required]
        public string Corporate { get; set; }
    }
}
