﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class MatrixDetail
{
    public int MdId { get; set; }

    public int MatrixId { get; set; }

    public int MoptionId { get; set; }

    public DateTime? LastUpdate { get; set; }

    public int Status { get; set; }

    public virtual Matrix Matrix { get; set; } = null!;

    public virtual MatrixOption Moption { get; set; } = null!;
}
