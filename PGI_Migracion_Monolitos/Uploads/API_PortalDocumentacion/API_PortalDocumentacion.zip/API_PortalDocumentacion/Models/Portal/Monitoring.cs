﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Monitoring
{
    public int MonitoringId { get; set; }

    public int ElementId { get; set; }

    public string? Description { get; set; }

    public int PlatformId { get; set; }

    public bool Active { get; set; }

    public DateTime CreactionDate { get; set; }

    public virtual Element Element { get; set; } = null!;

    public virtual Platform Platform { get; set; } = null!;
}
