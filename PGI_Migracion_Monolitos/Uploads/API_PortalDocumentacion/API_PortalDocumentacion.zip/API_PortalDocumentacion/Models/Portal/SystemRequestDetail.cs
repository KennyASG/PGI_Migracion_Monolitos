﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class SystemRequestDetail
{
    public int SrdId { get; set; }

    public int SrId { get; set; }

    public int ProjectId { get; set; }

    public bool? Authorized { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual SystemRequest Sr { get; set; } = null!;
}
