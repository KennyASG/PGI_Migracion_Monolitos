﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class User
{
    public string Corporate { get; set; } = null!;

    public int UserId { get; set; }

    public string? Passwordhash { get; set; }

    public string? Names { get; set; }

    public string? Surnames { get; set; }

    public string? Email { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public bool? FirstSession { get; set; }

    public string? Department { get; set; }

    public string? Job { get; set; }

    public string? Salt { get; set; }

    public int CountryId { get; set; }

    public virtual Country Country { get; set; } = null!;

    public virtual ICollection<Permission> Permissions { get; set; } = new List<Permission>();

    public virtual ICollection<ProjectCollaborator> ProjectCollaborators { get; set; } = new List<ProjectCollaborator>();

    public virtual ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();
}
