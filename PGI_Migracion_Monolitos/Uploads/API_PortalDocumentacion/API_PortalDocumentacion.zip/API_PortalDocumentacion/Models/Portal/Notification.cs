﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Notification
{
    public int NotificationId { get; set; }

    public string? SenderCorporate { get; set; }

    public string? ReceiverCorporate { get; set; }

    public int DestinationType { get; set; }

    public DateTime CreationDate { get; set; }

    public bool IsUnread { get; set; }

    public string? Title { get; set; }

    public string? Body { get; set; }

    public string? Comment { get; set; }

    public int? DiagramId { get; set; }

    public int NotificationStatus { get; set; }

    public bool Active { get; set; }

    public DateTime? RelatedNotificationDate { get; set; }

    public bool? WasSent { get; set; }
}
