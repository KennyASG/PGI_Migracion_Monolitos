﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class ShapeData
    {
        public string ElementType { get; set; }
        public string Element { get; set; }
        public string System { get; set; }
        public string Description { get; set; }
        public string Communication { get; set; }
        public string Method { get; set; }
    }
}
