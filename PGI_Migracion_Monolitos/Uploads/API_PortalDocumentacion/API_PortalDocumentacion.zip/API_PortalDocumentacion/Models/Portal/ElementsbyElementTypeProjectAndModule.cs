using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class ElementsbyElementTypeProjectAndModule
    {
        [Required] public string Element { get; set; }
        [Required] public string ElementType { get; set; }
        [Required] public string System { get; set; }

        [Required]
        public int Repetition { get; set; }
    }
}
