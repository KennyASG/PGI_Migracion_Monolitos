﻿using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    [Serializable]
    public class VisioExtractionResult
    {
        public int DiagramId { get; set; }
        public List<ShapeData> ShapesList { get; set; } = new List<ShapeData>();
        public List<ShapeData> UnrecognizedShapes { get; set; } = new List<ShapeData>(); 
    }
}
