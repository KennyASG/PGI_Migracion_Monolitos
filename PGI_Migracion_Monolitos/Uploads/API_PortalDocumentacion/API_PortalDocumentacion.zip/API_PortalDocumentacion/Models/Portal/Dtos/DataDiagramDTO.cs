﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class DataDiagramLLDTO
    {
        public string FilePath { get; set; }
        public string SVGPath { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public int LastVersion { get; set; }
        public List<SystemUsedDTO>? SystemsUsed { get; set; }
        public List<DiagramVersion> Versions { get; set; }
    }

    public class DataDiagramPLDTO
    {
        public string FilePath { get; set; }
        public string SVGPath { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public List<ConnectionsDiagramDTO> ConnectionsDiagram { get; set; }
    }
}
