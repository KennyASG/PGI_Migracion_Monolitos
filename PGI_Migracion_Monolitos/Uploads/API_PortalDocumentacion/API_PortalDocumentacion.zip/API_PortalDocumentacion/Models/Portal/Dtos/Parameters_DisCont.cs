﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class Parameters_DisCont
    {
        public string project { get; set; }
        public string module { get; set; }
        public string option { get; set; }
        public string diagramName { get; set; }
        public string system { get; set; }
    }
}
