﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class Parameters_LogicalLayer
    {
        public string project { get; set; }
        public string module { get; set; }
        public string option { get; set; }
        public string diagramName { get; set; }
        public string? fileName { get; set; }
        public string system { get; set; }
        public string? elementt { get; set; }
        public string? element { get; set; }
        public string classification { get; set; }
        public string fileExtension { get; set; }
    }
}
