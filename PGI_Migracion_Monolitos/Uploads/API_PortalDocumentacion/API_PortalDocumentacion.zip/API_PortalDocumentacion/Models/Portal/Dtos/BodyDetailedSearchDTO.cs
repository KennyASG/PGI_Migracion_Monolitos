﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class BodyDetailedSearchDTO
    {

        public string searchedWord { get; set; }
        public int project { get; set; }
        public int module { get; set; }
        public int system { get; set; }
        public int diagram { get; set; }
        public int elementType { get; set; }

        [Required]
        public string corporate { get; set; }
    }
}
