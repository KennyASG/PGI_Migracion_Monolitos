﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class GetDataDiagramDTO
    {
        public string? Corporate { get; set; }
        public int DiagramId { get; set; }
        public int? ElementId { get; set; }

    }
}
