﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class ProjectCollaboratorsModel
    {
        public int ProjectId { get; set; }
        public string Corporate { get; set; }
        public string FullName { get; set;}

    }
}
