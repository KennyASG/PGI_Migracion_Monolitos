﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class UserDTO
    {
        [Required(ErrorMessage = "The corporate is required")]
        [MaxLength(12, ErrorMessage = "The corporate cannot be longer than 12 characters.")]
        public string Corporate { get; set; } = null!;

        [Required(ErrorMessage = "The First name is required")]
        [MaxLength(50, ErrorMessage = "The first name cannot be longer than 50 characters.")]
        public string Names { get; set; } = null!;

        [Required(ErrorMessage = "The first surname is required")]
        [MaxLength(50, ErrorMessage = "The first surname cannot be longer than 50 characters.")]
        public string Surnames { get; set; } = null!;

        [Required(ErrorMessage = "The email is required")]
        [MaxLength(50, ErrorMessage = "The email cannot be longer than 50 characters.")]
        [RegularExpression("[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,5}", ErrorMessage = "The email does not meet the characteristics of an email. Example: user@bi.com.gt")]
        public string Email { get; set; } = null!;

        [Required(ErrorMessage = "The country code is required")]
        public string CountryCode { get; set; }

        public string Department { get; set; }
    }
}
