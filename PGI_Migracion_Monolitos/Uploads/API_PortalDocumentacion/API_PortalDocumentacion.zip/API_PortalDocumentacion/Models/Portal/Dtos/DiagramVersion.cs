﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class DiagramVersion
    {
        public int Version { get; set; }
        public string? InstallationNumber { get; set; }
        public DateTime? InstallationDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string? InstallationType { get; set; }
        public string? FilePath { get; set; }
        public string? SvgPath { get; set; }
        public List<SystemUsedDTO>? SystemsUsed { get; set; }
    }
}
