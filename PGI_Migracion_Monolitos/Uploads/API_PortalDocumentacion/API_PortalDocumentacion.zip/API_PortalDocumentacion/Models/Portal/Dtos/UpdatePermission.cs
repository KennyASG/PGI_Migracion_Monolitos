﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class Update_Permission
    {
        [Required(ErrorMessage = "El Id es requerido")]
        public int Id { get; set; } = 0;

        [Required(ErrorMessage = "El campo es requerido")]
        public string Corporate { get; set; }

        [Required(ErrorMessage = "La contraseña es requerida")]
        public int ProjectID { get; set; } = 0;
    }
}