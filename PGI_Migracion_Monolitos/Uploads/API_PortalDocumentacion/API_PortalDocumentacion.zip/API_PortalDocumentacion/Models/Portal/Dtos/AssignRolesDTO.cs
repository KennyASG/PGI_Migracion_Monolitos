﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class AssignRolesDTO
    {
        [Required(ErrorMessage = "El corporativo quien autoriza es requerido")]
        public string ActionUser { get; set; }

        [Required]
        public string Corporate { get; set; }

        public List<AssignedRoles> AssignedRoles { get; set; }

    }
}
