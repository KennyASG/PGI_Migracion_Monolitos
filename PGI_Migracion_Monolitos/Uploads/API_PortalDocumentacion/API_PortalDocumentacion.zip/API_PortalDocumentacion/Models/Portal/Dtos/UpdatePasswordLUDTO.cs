﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class UpdatePasswordLUDTO
    {
        [Required(ErrorMessage = "El usuario es requerido")]
        [RegularExpression("^[a-zA-Z0-9]{4,10}$")]
        [DataType(DataType.Text)]
        public string Username { get; set; } = null!;

        [Required(ErrorMessage = "La contraseña es requerida")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = null!;
    }
}
