﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class SystemUsedDTO
    {
        public string System { get; set; }
        public List<ElementTypeDto> ElementType { get; set; } = new List<ElementTypeDto>();
    }

    public class ElementTypeDto
    {
        public string ElementType { get; set; }
        public List<string> Elements { get; set; } = new List<string>();
    }

}
