﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class ConnectionsDiagramDTO
    {
        public int Id { get; set; }
        public string? ServiceName { get; set; }
        public string SourceElement { get; set; }
        public string SourceIp { get; set; }
        public string SourceInterface { get; set; }
        public string TargetElement { get; set; }
        public string TargetIp { get; set; }
        public string TargetInterface { get; set; }
        public string LogicalConnection {  get; set; }
    }
}
