﻿using System.Runtime.CompilerServices;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class Parameters_PhysicalLayer
    {
        public string project { get; set; }
        public string module { get; set; }
        public string option { get; set; }
        public string diagramName { get; set; }
        public string fileName { get; set; }
        public string logicalConn {  get; set; }
        public string service { get; set; }
        public string locationA { get; set; }
        public string areaA { get; set; }
        public string platformA { get; set; }
        public string elementtA { get; set; }
        public string elementA { get; set; }
        public string ipA { get; set; }
        public string interfaceA { get; set; }
        public string locationZ { get; set; }
        public string areaZ { get; set; }
        public string platformZ { get; set; }
        public string elementtZ { get; set; }
        public string elementZ { get; set; }
        public string ipZ { get; set; }
        public string interfaceZ { get; set; }
        public string classification { get; set; }
        public string fileExtension { get; set; }
    }
}
