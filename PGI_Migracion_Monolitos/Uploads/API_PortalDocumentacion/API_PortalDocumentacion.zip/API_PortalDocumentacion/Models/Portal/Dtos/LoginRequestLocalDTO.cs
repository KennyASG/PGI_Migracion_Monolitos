﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class LoginRequestLocalDTO
    {

        [Required(ErrorMessage = "El usuario es requerido")]
        [RegularExpression("^[a-zA-Z0-9]{4,10}$")]

        [DataType(DataType.Text)]
        public string username { get; set; }

        [Required(ErrorMessage = "La contraseña es requerida")]
        //[RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>])[A-Za-z\\d!@#$%^&*(),.?\":{}|<>]{8,20}$")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
