﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class LoginResponseDTO
    {

        [Required(ErrorMessage = "The corporate is required")]
        [MaxLength(12, ErrorMessage = "The corporate cannot be longer than 12 characters.")]
        public string Corporate { get; set; } = null!;

        [Required(ErrorMessage = "The First name is required")]
        [MaxLength(50, ErrorMessage = "The first name cannot be longer than 50 characters.")]
        public string Names { get; set; }

        [Required(ErrorMessage = "The first surname is required")]
        [MaxLength(50, ErrorMessage = "The first surname cannot be longer than 50 characters.")]
        public string Surnames { get; set; }

        public string Token { get; set; }

        public string Email { get; set; }

        public bool? FirstSession { get; set; }

        public string Department { get; set; }

        public string Job { get; set; }
        public int? CountryId { get; set; } = 0;
    }
}
