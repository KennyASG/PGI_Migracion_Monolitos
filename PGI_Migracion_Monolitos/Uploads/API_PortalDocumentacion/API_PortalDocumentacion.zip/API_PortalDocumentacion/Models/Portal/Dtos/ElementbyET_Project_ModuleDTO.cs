﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class ElementbyET_Project_ModuleDTO
    {
        [Required]
        public int ProjectId { get; set; } = 0;
        [Required]
        public int ElementTypeId { get; set; } = 0;
        [Required]
        public int ModuleId { get; set; } = 0;
    }
}
