﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class LayerDTO
    {
        public int LayerId { get; set; }

        public string LayerName { get; set; } = null!;
    }
}
