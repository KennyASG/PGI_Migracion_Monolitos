﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class BodyFormCreateCont
    {
        public string corporate {  get; set; }
        public IFormFile file { get; set; }
    }
}
