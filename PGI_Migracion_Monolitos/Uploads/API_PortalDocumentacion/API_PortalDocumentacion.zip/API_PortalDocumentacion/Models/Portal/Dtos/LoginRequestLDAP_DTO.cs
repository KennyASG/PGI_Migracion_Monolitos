﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class LoginRequestLDAP_DTO
    {

        [Required(ErrorMessage = "El corporativo es requerido")]
        [RegularExpression("^[0-9]{4,10}$")]
        public string Corporate { get; set; }

        [Required(ErrorMessage = "La contraseña es requerida")]
        //[RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>])[A-Za-z\\d!@#$%^&*(),.?\":{}|<>]{8,20}$")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public int CountryId { get; set; }
    }
}