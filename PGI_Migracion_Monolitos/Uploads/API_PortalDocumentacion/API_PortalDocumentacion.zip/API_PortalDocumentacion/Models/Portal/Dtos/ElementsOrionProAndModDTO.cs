﻿namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class ElementsOrionProAndModDTO
    {
        public int ProjectId { get; set; }
        public int ModuleId { get; set; }
    }
}
