﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class BodySearchDTO
    {
        public string searchedWord { get; set; }

        [Required]
        public string corporate { get; set; }
    }
}
