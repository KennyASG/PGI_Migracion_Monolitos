﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class CreateUserDTO
    {

        [Required(ErrorMessage = "El corporativo es requerido")]
        [MaxLength(12, ErrorMessage = "El corporativo no puede ser mayor de 12 caracteres.")]
        public string Corporate { get; set; } = null!;

        [Required(ErrorMessage = "El primer nombre es requerido")]
        [MaxLength(50, ErrorMessage = "El primer nombre no puede ser mayor de 50 caracteres.")]
        public string Names { get; set; } = null!;

        [Required(ErrorMessage = "El primer apellido es requerido")]
        [MaxLength(50, ErrorMessage = "El primer apellido no puede ser mayor de 50 caracteres.")]
        public string Surnames { get; set; } = null!;

        [Required(ErrorMessage = "El correo es requerido")]
        [MaxLength(50, ErrorMessage = "The email cannot be longer than 50 characters.")]
        [RegularExpression("[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,10}", ErrorMessage = "The email does not meet the characteristics of an email. Example: user@bi.com.gt")]
        public string Email { get; set; } = null!;

        public string CountryCode { get; set; }

        public string Department { get; set; }
    }
}
