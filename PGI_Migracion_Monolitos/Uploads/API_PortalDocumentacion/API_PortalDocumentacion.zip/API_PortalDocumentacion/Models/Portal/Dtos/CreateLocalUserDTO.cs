﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal.Dtos
{
    public class CreateLocalUserDTO
    {
        [Required(ErrorMessage = "El corporativo quien autoriza es requerido")]
        public string ActionUser { get; set; }

        [Required(ErrorMessage = "El username es requerido")]
        [MaxLength(25, ErrorMessage = "El username no puede ser mayor de 25 caracteres.")]
        public string Username { get; set; } = null!;

        [Required(ErrorMessage = "El primer nombre es requerido")]
        [MaxLength(80, ErrorMessage = "El primer nombre no puede ser mayor de 50 caracteres.")]
        public string Names { get; set; } = null!;

        [Required(ErrorMessage = "El primer apellido es requerido")]
        [MaxLength(80, ErrorMessage = "El primer apellido no puede ser mayor de 50 caracteres.")]
        public string Surnames { get; set; } = null!;

        [Required(ErrorMessage = "El correo es requerido")]
        [MaxLength(50, ErrorMessage = "The email cannot be longer than 50 characters.")]
        [RegularExpression("[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,10}", ErrorMessage = "The email does not meet the characteristics of an email. Example: user@bi.com.gt")]
        public string Email { get; set; } = null!;

        public string Department { get; set; }

        public string Job { get; set; }

        [Required(ErrorMessage = "El país del usuario es requerido")]
        public int CountryId { get; set; } = 0;

        public List<RequestSystemItem> RequestSystem { get; set; }
    }
}
