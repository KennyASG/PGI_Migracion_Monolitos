﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class InstallType
{
    public int InstallTypeId { get; set; }

    public string InstallType1 { get; set; } = null!;

    public bool Active { get; set; }

    public DateTime CreationDate { get; set; }

    public virtual ICollection<Installation> Installations { get; set; } = new List<Installation>();
}
