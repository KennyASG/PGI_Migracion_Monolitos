﻿using System.ComponentModel.DataAnnotations.Schema;

namespace API_PortalDocumentacion.Models.Portal
{
    public class NotificationAndRequestCountModel
    {
        public NotificationCount NotificationCount { get; set; }
        public RequestCount RequestCount { get; set; }
        public ProjectCount ProjectCount { get; set; }
        public UserCount UserCount { get; set; }
    }
    [NotMapped]
    public class NotificationCount
    {
        public int Total { get; set; } = 0;
        public int Pending { get; set; } = 0;
        public int Accepted { get; set; } = 0;
        public int Rejected { get; set; } = 0;
        public int AllPending { get; set; } = 0;
    }
    [NotMapped]
    public class RequestCount
    {
        public int Total { get; set; } = 0;
        public int Pending { get; set; } = 0;
        public int Accepted { get; set; } = 0;
        public int Rejected { get; set; } = 0;
    }
    [NotMapped]
    public class UserCount
    {
        public int Total { get; set; } = 0;
    }
    [NotMapped]
    public class ProjectCount
    {
        public int Total { get; set; } = 0;
    }
}