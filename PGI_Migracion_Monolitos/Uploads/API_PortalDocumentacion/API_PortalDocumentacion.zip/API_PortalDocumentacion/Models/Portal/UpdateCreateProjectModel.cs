﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class UpdateCreateProjectModel
    {
        [Required(ErrorMessage = "El corporativo quien autoriza es requerido")]
        public string ActionUser { get; set; }
        public int State { get; set; } = 0;

        [Required(ErrorMessage = "El ID del proyecto es requerido")]
        public int ProjectId { get; set; }

        [Required(ErrorMessage = "El nombre de proyecto es requerido")]
        public string ProjectName { get; set; }

        [Required(ErrorMessage = "La capa es requerida")]
        public int LayerId { get; set; } = 1;

        [Required(ErrorMessage = "La classificación del proyecto es requerido")]
        public int ClassificationId { get; set; } = 1;
        public List<AssignDocumentersModel>? AssignDocumenters { get; set; }

        [Required(ErrorMessage = "Debe tener mínimo un módulo.")]
        public List<UpdateModulesModel> Modules { get; set; }
    }

    public class UpdateModulesModel
    {
        public int State { get; set; } = 0;

        [Required(ErrorMessage = "El ID del módulo es requerido")]
        public int ModuleId { get; set; }

        [Required(ErrorMessage = "El nombre del módulo es requerido")]
        public string ModuleName { get; set; }

        [Required(ErrorMessage = "Debe tener mínimo un diagrama.")]
        public List<UpdateOptDiagModel> OptAndDiag { get; set; }
    }

    public class UpdateOptDiagModel 
    {
        public int StateOpt { get; set; } = 0;

        public int? OptionId { get; set; } = 0;

        public string? OptionName { get; set; } = null;

        public int StateDiag { get; set; } = 0;

        public int? DiagramId { get; set; } = 0;

        public string? DiagramName { get; set; } = null;
    }
}
