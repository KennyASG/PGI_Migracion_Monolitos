﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class InstallationModel
    {
        [Required(ErrorMessage = "El tipo de instalación es requerido")]
        public int InstallationType { get; set; } = 0;
        public string? InstallationNumber { get; set; }
        public DateTime? InstallationDate { get; set; }
        [Required(ErrorMessage = "El diagrama a actualizar es requerido")]
        public int DiagramId { get; set; } = 0;
        [Required(ErrorMessage = "El usuario que realiza la acción es requerido")]
        public string ActionUser { get; set; } = "";
        public string? UpdateReason { get; set; } = null;
    }
}
