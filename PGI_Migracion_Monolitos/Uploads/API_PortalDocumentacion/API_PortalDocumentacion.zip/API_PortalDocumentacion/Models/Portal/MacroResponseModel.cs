﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class MacroResponseModel
    {
        public string UrlSVG { get; set; }
        public string UrlVisio { get; set; }
    }
}
