﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class System
{
    public int SystemId { get; set; }

    public string System1 { get; set; } = null!;

    public int? ProjectId { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual ICollection<Detail> Details { get; set; } = new List<Detail>();

    public virtual Project? Project { get; set; }
}
