﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class ElementType
{
    public int ElementTypeId { get; set; }

    public string ElementType1 { get; set; } = null!;

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual ICollection<Element> Elements { get; set; } = new List<Element>();
}
