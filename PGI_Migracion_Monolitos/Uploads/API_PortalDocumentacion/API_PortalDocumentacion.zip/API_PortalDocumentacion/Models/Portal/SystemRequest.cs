﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class SystemRequest
{
    public int SrId { get; set; }

    public string Corporate { get; set; } = null!;

    public string Email { get; set; } = null!;

    public bool? Authorized { get; set; }

    public DateTime? VerificationDate { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public string? UserInformation { get; set; }

    public virtual ICollection<SystemRequestDetail> SystemRequestDetails { get; set; } = new List<SystemRequestDetail>();
}
