﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class SearchHistory
{
    public int Id { get; set; }

    public string Corporate { get; set; } = null!;

    public int DiagramId { get; set; }

    public int? ElementId { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }
}
