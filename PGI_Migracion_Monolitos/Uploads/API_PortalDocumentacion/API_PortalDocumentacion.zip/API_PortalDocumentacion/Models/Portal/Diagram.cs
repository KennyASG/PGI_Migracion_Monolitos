﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Diagram
{
    public int DiagramId { get; set; }

    public string Diagram1 { get; set; } = null!;

    public string? FilePath { get; set; }

    public int? ModuleId { get; set; }

    public int? OptionId { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public int? FeId { get; set; }

    public int SpId { get; set; }

    public DateTime? UpdateDate { get; set; }

    public int Version { get; set; }

    public virtual ICollection<Connection> Connections { get; set; } = new List<Connection>();

    public virtual ICollection<Detail> Details { get; set; } = new List<Detail>();

    public virtual ICollection<Installation> Installations { get; set; } = new List<Installation>();

    public virtual ICollection<Matrix> Matrices { get; set; } = new List<Matrix>();

    public virtual Module? Module { get; set; }

    public virtual Option? Option { get; set; }

    public virtual StatusProject Sp { get; set; } = null!;
}
