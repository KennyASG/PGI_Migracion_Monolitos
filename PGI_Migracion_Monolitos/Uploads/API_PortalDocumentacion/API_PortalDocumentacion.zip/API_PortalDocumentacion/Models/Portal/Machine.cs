﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Machine
{
    public int MachineId { get; set; }

    public string MachineName { get; set; } = null!;

    public int MtId { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreateDate { get; set; }

    public virtual MachineType Mt { get; set; } = null!;
}
