﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class LogAction
{
    public int LaId { get; set; }

    public string? ActionName { get; set; }

    public bool Active { get; set; }

    public DateTime CreationDate { get; set; }

    public virtual ICollection<Log> Logs { get; set; } = new List<Log>();
}
