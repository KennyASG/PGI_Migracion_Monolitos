﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Matrix
{
    public int MatrixId { get; set; }

    public int DiagramId { get; set; }

    public bool HasDynatrace { get; set; }

    public int Percentage { get; set; }

    public bool? Active { get; set; }

    public DateTime CreationDate { get; set; }

    public DateTime? FinishDate { get; set; }

    public virtual Diagram Diagram { get; set; } = null!;

    public virtual ICollection<MatrixDetail> MatrixDetails { get; set; } = new List<MatrixDetail>();
}
