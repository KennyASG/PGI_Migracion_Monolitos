﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Module
{
    public int ModuleId { get; set; }

    public string ModuleName { get; set; } = null!;

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public int? ProjectId { get; set; }

    public bool? Ismodule { get; set; }

    public int SpId { get; set; }

    public virtual ICollection<Diagram> Diagrams { get; set; } = new List<Diagram>();

    public virtual ICollection<Option> Options { get; set; } = new List<Option>();

    public virtual StatusProject Sp { get; set; } = null!;
}
