﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class NodesAndGraphs
    {
        public List<Nodess> Nodes {  get; set; }
        public List<Edgess> Edges { get; set; }
        public List<Various> Locations { get; set; }
        public List<MachineTypes> Types { get; set; }
        public List<Various> Areas { get; set; }
        public List<Various> Vendors { get; set; }
    }

    public class Edgess
    {
        public int Source { get; set; }
        public string InterfaceOrigin { get; set; }
        public int Target { get; set; }
        public string InterfaceDestino { get; set; }
    }

    public class Nodess
    {
        public string NodeId { get; set; }
        public string Label { get; set; }
        public string IpAddress { get; set; }
        public string Location { get; set; }
        public string Vendor { get; set; }
        public string Contact{ get; set; }
        public string MachineType { get; set; }
    }

    public class Various
    {
        public string Key { get; set; }
        public string Label { get; set; }
    }

    public class MachineTypes
    {
        public string Key { get; set; }
        public string Color { get; set; }
        public string Icon { get; set; }
        public int? Size { get; set; }
    }
}
