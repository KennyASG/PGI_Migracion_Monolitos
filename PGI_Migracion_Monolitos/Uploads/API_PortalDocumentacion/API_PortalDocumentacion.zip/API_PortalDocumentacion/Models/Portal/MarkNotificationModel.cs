﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class MarkNotificationModel
    {
        [Required(ErrorMessage = "La notificación es requerida")]
        public int NotificationId { get; set; } = 0;
        public bool IsUnread { get; set; } = false;
    }
}
