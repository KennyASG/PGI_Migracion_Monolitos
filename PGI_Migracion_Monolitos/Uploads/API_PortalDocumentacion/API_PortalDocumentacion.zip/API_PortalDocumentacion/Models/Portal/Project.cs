﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Project
{
    public int ProjectId { get; set; }

    public string Project1 { get; set; } = null!;

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public int? LayerId { get; set; }

    public int? CId { get; set; }

    public int SpId { get; set; }

    public int? CountryId { get; set; }

    public virtual Country? Country { get; set; }

    public virtual Layer? Layer { get; set; }

    public virtual ICollection<MatrixTemplate> MatrixTemplates { get; set; } = new List<MatrixTemplate>();

    public virtual ICollection<ProjectCollaborator> ProjectCollaborators { get; set; } = new List<ProjectCollaborator>();

    public virtual StatusProject Sp { get; set; } = null!;

    public virtual ICollection<System> Systems { get; set; } = new List<System>();
}
