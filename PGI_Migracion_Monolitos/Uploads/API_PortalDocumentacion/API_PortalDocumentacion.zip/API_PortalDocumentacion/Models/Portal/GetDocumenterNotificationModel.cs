﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class GetDocumenterNotificationModel
    {
        [Required(ErrorMessage = "El usuario es requerido")]
        public string Corporate { get; set; }
        [Required(ErrorMessage = "El estado de notificación es requerido")]
        public int NotificationStatus { get; set; } = 0;
    }
}
