﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class SubmitRequest
    {
        [Required(ErrorMessage = "El corporativo es requerido")]
        [RegularExpression("^[0-9]{4,10}$", ErrorMessage = "¡Solo son permitidos números!")]
        public string Corporate { get; set; }
        public string Names { get; set; }
        public string Surnames { get; set; }
        [Required(ErrorMessage = "El país es requerido")]
        public int CountryId { get; set; } = 0;

        [RegularExpression("[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,5}", ErrorMessage = "El correo electrónico no cumple con las características de un correo electrónico. Ejemplo: user@bi.com.gt")]
        public string Email { get; set; }
        public string Department { get; set; }
        public string Job { get; set; }
        public List<RequestSystemItem> RequestSystem { get; set; }

    }

    public class RequestSystemItem
    {
        [Required(ErrorMessage = "ID es requerido")]
        public int Id { get; set; }
        [Required(ErrorMessage = "displayText es requerido")]
        public string displayText { get; set; }
    }

}
