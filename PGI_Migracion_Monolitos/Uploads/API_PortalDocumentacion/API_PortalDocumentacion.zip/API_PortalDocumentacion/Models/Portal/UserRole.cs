﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class UserRole
{
    public int UrId { get; set; }

    public string Corporate { get; set; } = null!;

    public int RoleId { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual User CorporateNavigation { get; set; } = null!;

    public virtual Role Role { get; set; } = null!;
}
