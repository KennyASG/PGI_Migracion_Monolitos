﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal;

public class AssignedPermission
{
    [Required(ErrorMessage = "El corporativo/Usuario es necesario.")]
    public string Corporate { get; set; }

    [Required(ErrorMessage = "El nombre es necesario.")]
    public string User { get; set; }

    [Required(ErrorMessage = "El correo es necesario.")]
    public string Email { get; set; }

    [Required(ErrorMessage = "El puesto es necesario.")]
    public string Job { get; set; }

    [Required(ErrorMessage = "El área es necesario.")]
    public string Department { get; set; }

    public List<AssignedProject> AssignedProjects { get; set; } = new();

    public List<AssignedRoles> AssignedRoles { get; set; } = new();
}

public class AssignedProject
{
    public int? PermissionId { get; set; }

    [Required(ErrorMessage = "El id del proyecto es necesario.")]
    public int ProjectId { get; set; } = 0;

    [Required(ErrorMessage = "El id de la capa es necesario.")]
    public int? LayerId { get; set; }

    [Required(ErrorMessage = "El nombre del proyecto es necesario.")]
    public string ProjectName { get; set; }

    [Required(ErrorMessage = "El campo debe de ser True o False")]
    [RegularExpression("^(?i:true|false|1|0)$", ErrorMessage = "El valor debe ser true, false, 1 o 0 ")]
    public bool Active { get; set; }
    public int? CountryId { get; set; }
    public string? CountryCode { get; set; }
    public string? CountryName { get; set; }
}

public class AssignedRoles
{
    public int? UserRoleId { get; set; }

    [Required(ErrorMessage = "El rol es necesario.")]
    public int RoleId { get; set; } = 0;

    [Required(ErrorMessage = "El nombre de role es necesario.")]
    public string RoleName { get; set; }

    [RegularExpression("^(?i:true|false|1|0)$", ErrorMessage = "El valor debe ser true, false, 1 o 0 ")]
    public bool Active { get; set; }
}
