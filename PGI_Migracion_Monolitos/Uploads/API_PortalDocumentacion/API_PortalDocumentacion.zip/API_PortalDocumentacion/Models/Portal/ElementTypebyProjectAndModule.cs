using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class ElementTypebyProjectAndModule
    {
        [Required]
        public int ElementTypeId { get; set; }

        [Required] public string ElementType { get; set; }

        [Required]
        public int Repetition { get; set; }
    }
}
