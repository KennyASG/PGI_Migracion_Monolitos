﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class GetAllModuleDiagrams
    {
        public int? OptionId { get; set; }
        public string? OptionName { get; set; }
        public int DiagramId { get; set; }
        public int SpId { get; set; }
        public int? Percentage { get; set; }
    }
}
