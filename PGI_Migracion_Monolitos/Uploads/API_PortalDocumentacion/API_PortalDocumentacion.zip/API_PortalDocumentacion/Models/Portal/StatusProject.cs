﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class StatusProject
{
    public int SpId { get; set; }

    public string StatusName { get; set; } = null!;

    public string? Description { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreateDate { get; set; }

    public virtual ICollection<Diagram> Diagrams { get; set; } = new List<Diagram>();

    public virtual ICollection<Module> Modules { get; set; } = new List<Module>();

    public virtual ICollection<Option> Options { get; set; } = new List<Option>();

    public virtual ICollection<Project> Projects { get; set; } = new List<Project>();
}
