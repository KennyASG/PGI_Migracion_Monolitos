﻿using DocumentFormat.OpenXml.Office.CoverPageProps;

namespace API_PortalDocumentacion.Models.Portal
{
    public class GetProjectProgressWithModulesModel
    {
        //Porcentaje actual
        public decimal CurrentPercentage { get; set; }
        //PunteoActual
        public int CurrentPoints { get; set; }
        //PunteoPorMatriz
        public int PointsByMatrix { get;set; }
        //TotalDeDiagramasCompletados
        public int CompletedDiagrams { get; set; }
        //PunteoPorDiagramasCompletados
        public int PointsByCompletedDiagrams { get; set; }
        //PunteoTotalPosible
        public int TotalPossiblePoints { get; set; }
        //Total de diagramas en el proyecto
        public int TotalDiagramsInProject { get; set; }
        //Listado de los módulos existentes dentro del proyecto, cada uno con sus estadísticas
        public List<ModuleProgress> Modules { get; set; }
    }

    public class ModuleProgress
    {
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
        public decimal CurrentPercentage { get; set; }
        public int CurrentPoints { get; set; }
        public int PointsByMatrix { get; set; }
        public int CompletedDiagrams { get; set; }
        public int PointsByCompletedDiagrams { get; set; }
        public int TotalPossiblePoints { get; set; }
        public int TotalDiagramsInModule { get; set; }
    }
}
