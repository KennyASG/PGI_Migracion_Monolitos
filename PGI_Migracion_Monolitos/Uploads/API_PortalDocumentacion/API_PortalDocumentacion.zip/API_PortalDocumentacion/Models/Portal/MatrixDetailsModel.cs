﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class MatrixDetailsModel
    {
        public int Id { get; set; }
        public int? ParentId { get; set; }
        public int? Matrix_Id { get; set; }
        public bool? HasDYNA { get; set; }
        public int? Percentage { get; set; }
        public int? MD_ID { get; set; }
        public int Level { get; set; }
        public string? DetailName { get; set; }
        public DateTime? UpdateDate { get; set; }
        public int? ScoreDyn { get; set; }
        public int? ScoreNoDyn { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? FinishDate { get; set; }
        public int MStatus { get; set; }
    }
}
