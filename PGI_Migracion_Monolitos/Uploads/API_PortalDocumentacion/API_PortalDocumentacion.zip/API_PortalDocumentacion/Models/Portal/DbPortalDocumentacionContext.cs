﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace API_PortalDocumentacion.Models.Portal;

public partial class DbPortalDocumentacionContext : DbContext
{
    public DbPortalDocumentacionContext()
    {
    }

    public DbPortalDocumentacionContext(DbContextOptions<DbPortalDocumentacionContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Administrator> Administrators { get; set; }

    public virtual DbSet<Classification> Classifications { get; set; }

    public virtual DbSet<Connection> Connections { get; set; }

    public virtual DbSet<Country> Countries { get; set; }

    public virtual DbSet<Detail> Details { get; set; }

    public virtual DbSet<Diagram> Diagrams { get; set; }

    public virtual DbSet<Element> Elements { get; set; }

    public virtual DbSet<ElementType> ElementTypes { get; set; }

    public virtual DbSet<FileExtension> FileExtensions { get; set; }

    public virtual DbSet<InstallType> InstallTypes { get; set; }

    public virtual DbSet<Installation> Installations { get; set; }

    public virtual DbSet<Interface> Interfaces { get; set; }

    public virtual DbSet<Layer> Layers { get; set; }

    public virtual DbSet<Location> Locations { get; set; }

    public virtual DbSet<Log> Logs { get; set; }

    public virtual DbSet<LogAction> LogActions { get; set; }

    public virtual DbSet<Matrix> Matrices { get; set; }

    public virtual DbSet<MatrixDetail> MatrixDetails { get; set; }

    public virtual DbSet<MatrixOption> MatrixOptions { get; set; }

    public virtual DbSet<MatrixTemplate> MatrixTemplates { get; set; }

    public virtual DbSet<MatrixTemplateDetail> MatrixTemplateDetails { get; set; }

    public virtual DbSet<Module> Modules { get; set; }

    public virtual DbSet<Monitoring> Monitorings { get; set; }

    public virtual DbSet<Notification> Notifications { get; set; }

    public virtual DbSet<Option> Options { get; set; }

    public virtual DbSet<Permission> Permissions { get; set; }

    public virtual DbSet<Platform> Platforms { get; set; }

    public virtual DbSet<Project> Projects { get; set; }

    public virtual DbSet<ProjectCollaborator> ProjectCollaborators { get; set; }

    public virtual DbSet<Provider> Providers { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<SearchHistory> SearchHistories { get; set; }

    public virtual DbSet<Service> Services { get; set; }

    public virtual DbSet<StatusProject> StatusProjects { get; set; }

    public virtual DbSet<System> Systems { get; set; }

    public virtual DbSet<SystemRequest> SystemRequests { get; set; }

    public virtual DbSet<SystemRequestDetail> SystemRequestDetails { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SearchMatchResult>().HasNoKey().ToView(null);

        modelBuilder.Entity<SearchMatchPLResult>().HasNoKey().ToView(null);

        modelBuilder.Entity<DetailedSearchMatchResult>().HasNoKey().ToView(null);

        modelBuilder.Entity<MenuItem>().HasNoKey().ToView(null);

        modelBuilder.Entity<ElementsOrion>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetProModOptDiag>().HasNoKey().ToView(null);

        modelBuilder.Entity<DocumenterMenuItem>().HasNoKey().ToView(null);

        modelBuilder.Entity<MatrixDetailsModel>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetMatrixAndDetailModel>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetAllProjectDiagrams>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetProjectProgressWithModulesModel>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetAllModuleDiagrams>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetModuleProgress>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetNotifAndRequestCountModel>().HasNoKey().ToView(null);

        modelBuilder.Entity<NotificationAndRequestCountModel>().HasNoKey().ToView(null);

        modelBuilder.Entity<GetUserCountriesModel>().HasNoKey().ToView(null);

        modelBuilder.Entity<Administrator>(entity =>
        {
            entity.HasKey(e => e.AdminId).HasName("PK__ADMINIST__59AF14B552CA94CE");

            entity.ToTable("ADMINISTRATOR");

            entity.Property(e => e.AdminId).HasColumnName("ADMIN_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.AdminName)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("ADMIN_NAME");
            entity.Property(e => e.Area)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("AREA");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
        });

        modelBuilder.Entity<Classification>(entity =>
        {
            entity.HasKey(e => e.CId).HasName("PK__CLASSIFI__A9FDEC12AC386CA7");

            entity.ToTable("CLASSIFICATION");

            entity.Property(e => e.CId).HasColumnName("C_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATE_DATE");
            entity.Property(e => e.Description)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NAME");
        });

        modelBuilder.Entity<Connection>(entity =>
        {
            entity.HasKey(e => e.ConnectionId).HasName("PK_Connections");

            entity.ToTable("CONNECTION");

            entity.Property(e => e.ConnectionId).HasColumnName("CONNECTION_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.FInterfaceId).HasColumnName("F_INTERFACE_ID");
            entity.Property(e => e.LastUpdate)
                .HasColumnType("datetime")
                .HasColumnName("LAST_UPDATE");
            entity.Property(e => e.LogicalConnection)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("LOGICAL_CONNECTION");
            entity.Property(e => e.SInterfaceId).HasColumnName("S_INTERFACE_ID");
            entity.Property(e => e.ServiceId).HasColumnName("SERVICE_ID");

            entity.HasOne(d => d.Diagram).WithMany(p => p.Connections)
                .HasForeignKey(d => d.DiagramId)
                .HasConstraintName("FK_CONNETION_TO_DIAGRAM");

            entity.HasOne(d => d.FInterface).WithMany(p => p.ConnectionFInterfaces)
                .HasForeignKey(d => d.FInterfaceId)
                .HasConstraintName("FK_CONNECTION_TO_F_INTERFACE");

            entity.HasOne(d => d.SInterface).WithMany(p => p.ConnectionSInterfaces)
                .HasForeignKey(d => d.SInterfaceId)
                .HasConstraintName("FK_CONNECTION_TO_S_INTERFACE");
        });

        modelBuilder.Entity<Country>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__COUNTRY__FC7F5907223325B2");

            entity.ToTable("COUNTRY");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Client)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasDefaultValueSql("(NULL)")
                .HasColumnName("CLIENT");
            entity.Property(e => e.CountryCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("COUNTRY_CODE");
            entity.Property(e => e.CountryName)
                .HasMaxLength(25)
                .IsUnicode(false)
                .HasColumnName("COUNTRY_NAME");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Domain)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasDefaultValueSql("(NULL)")
                .HasColumnName("DOMAIN");
        });

        modelBuilder.Entity<Detail>(entity =>
        {
            entity.ToTable("DETAIL");

            entity.HasIndex(e => e.DiagramId, "IX_DETAIL_DIAGRAM_ID");

            entity.HasIndex(e => e.ElementId, "IX_DETAIL_ELEMENT_ID");

            entity.HasIndex(e => e.SystemId, "IX_DETAIL_SYSTEM_ID");

            entity.Property(e => e.DetailId).HasColumnName("DETAIL_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.ElementId).HasColumnName("ELEMENT_ID");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("NAME");
            entity.Property(e => e.Repetition)
                .HasDefaultValue(1)
                .HasColumnName("REPETITION");
            entity.Property(e => e.SystemId).HasColumnName("SYSTEM_ID");
            entity.Property(e => e.Version)
                .HasDefaultValue(1)
                .HasColumnName("VERSION");

            entity.HasOne(d => d.Diagram).WithMany(p => p.Details)
                .HasForeignKey(d => d.DiagramId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DETAIL_DIAGRAM");

            entity.HasOne(d => d.Element).WithMany(p => p.Details)
                .HasForeignKey(d => d.ElementId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DETAIL_ELEMENT");

            entity.HasOne(d => d.System).WithMany(p => p.Details)
                .HasForeignKey(d => d.SystemId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DETAIL_SYSTEM");
        });

        modelBuilder.Entity<Diagram>(entity =>
        {
            entity.ToTable("DIAGRAM");

            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Diagram1)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("DIAGRAM");
            entity.Property(e => e.FeId).HasColumnName("FE_ID");
            entity.Property(e => e.FilePath)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("FILE_PATH");
            entity.Property(e => e.ModuleId).HasColumnName("MODULE_ID");
            entity.Property(e => e.OptionId).HasColumnName("OPTION_ID");
            entity.Property(e => e.SpId)
                .HasDefaultValue(1)
                .HasColumnName("SP_ID");
            entity.Property(e => e.UpdateDate)
                .HasColumnType("datetime")
                .HasColumnName("UPDATE_DATE");
            entity.Property(e => e.Version)
                .HasDefaultValue(1)
                .HasColumnName("VERSION");

            entity.HasOne(d => d.Module).WithMany(p => p.Diagrams)
                .HasForeignKey(d => d.ModuleId)
                .HasConstraintName("FK_DIAGRAM_TO_MODULE");

            entity.HasOne(d => d.Option).WithMany(p => p.Diagrams)
                .HasForeignKey(d => d.OptionId)
                .HasConstraintName("FK_DIAGRAM_TO_OPTION");

            entity.HasOne(d => d.Sp).WithMany(p => p.Diagrams)
                .HasForeignKey(d => d.SpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DIAGRAM_TO_STATUS_PROJECT");
        });

        modelBuilder.Entity<Element>(entity =>
        {
            entity.ToTable("ELEMENT");

            entity.HasIndex(e => e.DevBy, "IX_ELEMENT_DEV_BY");

            entity.HasIndex(e => e.ElementTypeId, "IX_ELEMENT_ELEMENT_TYPE_ID");

            entity.HasIndex(e => e.MaintBy, "IX_ELEMENT_MAINT_BY");

            entity.HasIndex(e => e.PElementId, "IX_ELEMENT_P_ELEMENT_ID");

            entity.Property(e => e.ElementId).HasColumnName("ELEMENT_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.AdminId).HasColumnName("ADMIN_ID");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.DevBy).HasColumnName("DEV_BY");
            entity.Property(e => e.Element1)
                .IsUnicode(false)
                .HasColumnName("ELEMENT");
            entity.Property(e => e.ElementTypeId).HasColumnName("ELEMENT_TYPE_ID");
            entity.Property(e => e.IpAdministration)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("IP_ADMINISTRATION");
            entity.Property(e => e.LocationId).HasColumnName("LOCATION_ID");
            entity.Property(e => e.MaintBy).HasColumnName("MAINT_BY");
            entity.Property(e => e.PElementId).HasColumnName("P_ELEMENT_ID");
            entity.Property(e => e.ProgLeng)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("PROG_LENG");
            entity.Property(e => e.Version)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("VERSION");

            entity.HasOne(d => d.Admin).WithMany(p => p.Elements)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK_ELEMENT_TO ADMIN");

            entity.HasOne(d => d.DevByNavigation).WithMany(p => p.ElementDevByNavigations)
                .HasForeignKey(d => d.DevBy)
                .HasConstraintName("FK_ELEMENT_TO_PROVIDER_DEV");

            entity.HasOne(d => d.ElementType).WithMany(p => p.Elements)
                .HasForeignKey(d => d.ElementTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ELEMENT_ELEMENT_TYPE");

            entity.HasOne(d => d.Location).WithMany(p => p.Elements)
                .HasForeignKey(d => d.LocationId)
                .HasConstraintName("FK_ELEMENT_TO_LOCATION");

            entity.HasOne(d => d.MaintByNavigation).WithMany(p => p.ElementMaintByNavigations)
                .HasForeignKey(d => d.MaintBy)
                .HasConstraintName("FK_ELEMENT_TO_PROVIDER_MAINT");

            entity.HasOne(d => d.PElement).WithMany(p => p.InversePElement)
                .HasForeignKey(d => d.PElementId)
                .HasConstraintName("FK_ELEMENT_ELEMENT");
        });

        modelBuilder.Entity<ElementType>(entity =>
        {
            entity.ToTable("ELEMENT_TYPE");

            entity.Property(e => e.ElementTypeId).HasColumnName("ELEMENT_TYPE_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.ElementType1)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("ELEMENT_TYPE");
        });

        modelBuilder.Entity<FileExtension>(entity =>
        {
            entity.HasKey(e => e.FeId).HasName("PK__FILE_EXT__93E2516C12E278BE");

            entity.ToTable("FILE_EXTENSION");

            entity.Property(e => e.FeId).HasColumnName("FE_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATE_DATE");
            entity.Property(e => e.Description)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.Extension)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("EXTENSION");
        });

        modelBuilder.Entity<InstallType>(entity =>
        {
            entity.ToTable("INSTALL_TYPE");

            entity.Property(e => e.InstallTypeId).HasColumnName("INSTALL_TYPE_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.InstallType1)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("INSTALL_TYPE");
        });

        modelBuilder.Entity<Installation>(entity =>
        {
            entity.ToTable("INSTALLATION");

            entity.Property(e => e.InstallationId).HasColumnName("INSTALLATION_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.InstallTypeId)
                .HasDefaultValue(1)
                .HasColumnName("INSTALL_TYPE_ID");
            entity.Property(e => e.InstallationDate)
                .HasColumnType("datetime")
                .HasColumnName("INSTALLATION_DATE");
            entity.Property(e => e.InstallationNumber)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("INSTALLATION_NUMBER");
            entity.Property(e => e.UpdateReason)
                .IsUnicode(false)
                .HasColumnName("UPDATE_REASON");
            entity.Property(e => e.Version).HasColumnName("VERSION");

            entity.HasOne(d => d.Diagram).WithMany(p => p.Installations)
                .HasForeignKey(d => d.DiagramId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_INSTALLATION_TO_DIAGRAM");

            entity.HasOne(d => d.InstallType).WithMany(p => p.Installations)
                .HasForeignKey(d => d.InstallTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_INSTALLATION_TO_INSTALL_TYPE");
        });

        modelBuilder.Entity<Interface>(entity =>
        {
            entity.HasKey(e => e.InterfaceId).HasName("PK_INTERFACES");

            entity.ToTable("INTERFACE");

            entity.Property(e => e.InterfaceId).HasColumnName("INTERFACE_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.ElementId).HasColumnName("ELEMENT_ID");
            entity.Property(e => e.InterfaceName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("INTERFACE_NAME");

            entity.HasOne(d => d.Element).WithMany(p => p.Interfaces)
                .HasForeignKey(d => d.ElementId)
                .HasConstraintName("FK_INTERFACE_TO_ELEMENT");
        });

        modelBuilder.Entity<Layer>(entity =>
        {
            entity.HasKey(e => e.LayerId).HasName("PK__LAYER__038B6C0EB278003A");

            entity.ToTable("LAYER");

            entity.Property(e => e.LayerId).HasColumnName("LAYER_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.LayerName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("LAYER_NAME");
        });

        modelBuilder.Entity<Location>(entity =>
        {
            entity.HasKey(e => e.LocationId).HasName("PK_Locations");

            entity.ToTable("LOCATION");

            entity.Property(e => e.LocationId).HasColumnName("LOCATION_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.LocationName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("LOCATION_NAME");
        });

        modelBuilder.Entity<Log>(entity =>
        {
            entity.HasKey(e => e.LogId).HasName("PK__LOG__4364C882AFF4B3C6");

            entity.ToTable("LOG");

            entity.Property(e => e.LogId).HasColumnName("LOG_ID");
            entity.Property(e => e.Comment)
                .IsUnicode(false)
                .HasColumnName("COMMENT");
            entity.Property(e => e.Corporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("CORPORATE");
            entity.Property(e => e.Date)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("DATE");
            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.LaId).HasColumnName("LA_ID");

            entity.HasOne(d => d.La).WithMany(p => p.Logs)
                .HasForeignKey(d => d.LaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_LOG_TO_LOG_ACTION");
        });

        modelBuilder.Entity<LogAction>(entity =>
        {
            entity.HasKey(e => e.LaId).HasName("PK__LOG_ACTI__A57D4D584241AF16");

            entity.ToTable("LOG_ACTION");

            entity.Property(e => e.LaId).HasColumnName("LA_ID");
            entity.Property(e => e.ActionName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("ACTION_NAME");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
        });

        modelBuilder.Entity<Matrix>(entity =>
        {
            entity.ToTable("MATRIX");

            entity.Property(e => e.MatrixId).HasColumnName("MATRIX_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.FinishDate)
                .HasColumnType("datetime")
                .HasColumnName("FINISH_DATE");
            entity.Property(e => e.HasDynatrace).HasColumnName("HAS_DYNATRACE");
            entity.Property(e => e.Percentage).HasColumnName("PERCENTAGE");

            entity.HasOne(d => d.Diagram).WithMany(p => p.Matrices)
                .HasForeignKey(d => d.DiagramId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MATRIX_TO_DIAGRAM");
        });

        modelBuilder.Entity<MatrixDetail>(entity =>
        {
            entity.HasKey(e => e.MdId);

            entity.ToTable("MATRIX_DETAIL");

            entity.Property(e => e.MdId).HasColumnName("MD_ID");
            entity.Property(e => e.LastUpdate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("LAST_UPDATE");
            entity.Property(e => e.MatrixId).HasColumnName("MATRIX_ID");
            entity.Property(e => e.MoptionId).HasColumnName("MOPTION_ID");
            entity.Property(e => e.Status)
                .HasDefaultValue(1)
                .HasColumnName("STATUS");

            entity.HasOne(d => d.Matrix).WithMany(p => p.MatrixDetails)
                .HasForeignKey(d => d.MatrixId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MATRIX_DETAIL_MATRIX");

            entity.HasOne(d => d.Moption).WithMany(p => p.MatrixDetails)
                .HasForeignKey(d => d.MoptionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MATRIX_DETAIL_MATRIX_OPTION");
        });

        modelBuilder.Entity<MatrixOption>(entity =>
        {
            entity.HasKey(e => e.MoptionId);

            entity.ToTable("MATRIX_OPTION");

            entity.Property(e => e.MoptionId).HasColumnName("MOPTION_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Name)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("NAME");
            entity.Property(e => e.ScoreDynatrace).HasColumnName("SCORE_DYNATRACE");
            entity.Property(e => e.ScoreNoDynatrace).HasColumnName("SCORE_NO_DYNATRACE");
        });

        modelBuilder.Entity<MatrixTemplate>(entity =>
        {
            entity.HasKey(e => e.MtemplateId);

            entity.ToTable("MATRIX_TEMPLATE");

            entity.Property(e => e.MtemplateId).HasColumnName("MTEMPLATE_ID");
            entity.Property(e => e.Active).HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.ProjectId).HasColumnName("PROJECT_ID");

            entity.HasOne(d => d.Project).WithMany(p => p.MatrixTemplates)
                .HasForeignKey(d => d.ProjectId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MATRIX_TEMPLATE_TO_PROJECT");
        });

        modelBuilder.Entity<MatrixTemplateDetail>(entity =>
        {
            entity.HasKey(e => e.Mtd);

            entity.ToTable("MATRIX_TEMPLATE_DETAIL");

            entity.Property(e => e.Mtd).HasColumnName("MTD");
            entity.Property(e => e.MoptionId).HasColumnName("MOPTION_ID");
            entity.Property(e => e.MtemplateId).HasColumnName("MTEMPLATE_ID");

            entity.HasOne(d => d.Moption).WithMany(p => p.MatrixTemplateDetails)
                .HasForeignKey(d => d.MoptionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MATRIX_TEMPLATE_DETAIL_MATRIX_OPTION");

            entity.HasOne(d => d.Mtemplate).WithMany(p => p.MatrixTemplateDetails)
                .HasForeignKey(d => d.MtemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MATRIX_TEMPLATE_DETAIL_TO_MATRIX_TEMPLATE");
        });

        modelBuilder.Entity<Module>(entity =>
        {
            entity.HasKey(e => e.ModuleId).HasName("PK__MODULE__238A8246826BADC9");

            entity.ToTable("MODULE");

            entity.Property(e => e.ModuleId).HasColumnName("MODULE_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Ismodule).HasColumnName("ISMODULE");
            entity.Property(e => e.ModuleName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("MODULE_NAME");
            entity.Property(e => e.ProjectId).HasColumnName("PROJECT_ID");
            entity.Property(e => e.SpId)
                .HasDefaultValue(1)
                .HasColumnName("SP_ID");

            entity.HasOne(d => d.Sp).WithMany(p => p.Modules)
                .HasForeignKey(d => d.SpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MODULE_TO_STATUS_PROJECT");
        });

        modelBuilder.Entity<Monitoring>(entity =>
        {
            entity.HasKey(e => e.MonitoringId).HasName("PK_Monitorings");

            entity.ToTable("MONITORING");

            entity.Property(e => e.MonitoringId).HasColumnName("MONITORING_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreactionDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREACTION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.ElementId).HasColumnName("ELEMENT_ID");
            entity.Property(e => e.PlatformId).HasColumnName("PLATFORM_ID");

            entity.HasOne(d => d.Element).WithMany(p => p.Monitorings)
                .HasForeignKey(d => d.ElementId)
                .HasConstraintName("FK_MONITORING_TO_ELEMENT");

            entity.HasOne(d => d.Platform).WithMany(p => p.Monitorings)
                .HasForeignKey(d => d.PlatformId)
                .HasConstraintName("FK_MONITORING_TO_PLATFORM");
        });

        modelBuilder.Entity<Notification>(entity =>
        {
            entity.ToTable("NOTIFICATION");

            entity.Property(e => e.NotificationId).HasColumnName("NOTIFICATION_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Body)
                .IsUnicode(false)
                .HasColumnName("BODY");
            entity.Property(e => e.Comment)
                .IsUnicode(false)
                .HasColumnName("COMMENT");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.DestinationType).HasColumnName("DESTINATION_TYPE");
            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.IsUnread)
                .HasDefaultValue(true)
                .HasColumnName("IS_UNREAD");
            entity.Property(e => e.NotificationStatus)
                .HasDefaultValue(1)
                .HasColumnName("NOTIFICATION_STATUS");
            entity.Property(e => e.ReceiverCorporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("RECEIVER_CORPORATE");
            entity.Property(e => e.RelatedNotificationDate)
                .HasColumnType("datetime")
                .HasColumnName("RELATED_NOTIFICATION_DATE");
            entity.Property(e => e.SenderCorporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("SENDER_CORPORATE");
            entity.Property(e => e.Title)
                .IsUnicode(false)
                .HasColumnName("TITLE");
            entity.Property(e => e.WasSent)
                .HasDefaultValue(false)
                .HasColumnName("WAS_SENT");
        });

        modelBuilder.Entity<Option>(entity =>
        {
            entity.HasKey(e => e.OptionId).HasName("PK__OPTION__1E24B66940D196A1");

            entity.ToTable("OPTION");

            entity.Property(e => e.OptionId).HasColumnName("OPTION_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.ModuleId).HasColumnName("MODULE_ID");
            entity.Property(e => e.OptionName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("OPTION_NAME");
            entity.Property(e => e.SpId)
                .HasDefaultValue(1)
                .HasColumnName("SP_ID");

            entity.HasOne(d => d.Module).WithMany(p => p.Options)
                .HasForeignKey(d => d.ModuleId)
                .HasConstraintName("FK_OPTION_TO_MODULE");

            entity.HasOne(d => d.Sp).WithMany(p => p.Options)
                .HasForeignKey(d => d.SpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_OPTION_TO_STATUS_PROJECT");
        });

        modelBuilder.Entity<Permission>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__PERMISSI__3214EC272F1643DA");

            entity.ToTable("PERMISSION");

            entity.HasIndex(e => e.Corporate, "IX_PERMISSION_CORPORATE");

            entity.HasIndex(e => e.ProjectId, "IX_PERMISSION_MENU_ID");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Corporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("CORPORATE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.ProjectId).HasColumnName("PROJECT_ID");

            entity.HasOne(d => d.CorporateNavigation).WithMany(p => p.Permissions)
                .HasForeignKey(d => d.Corporate)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PERMISSION_TO_USER");
        });

        modelBuilder.Entity<Platform>(entity =>
        {
            entity.HasKey(e => e.PlatformId).HasName("PK_Platforms");

            entity.ToTable("PLATFORM");

            entity.Property(e => e.PlatformId).HasColumnName("PLATFORM_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Observations)
                .IsUnicode(false)
                .HasColumnName("OBSERVATIONS");
            entity.Property(e => e.PlatformName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("PLATFORM_NAME");
        });

        modelBuilder.Entity<Project>(entity =>
        {
            entity.ToTable("PROJECT");

            entity.Property(e => e.ProjectId).HasColumnName("PROJECT_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CId).HasColumnName("C_ID");
            entity.Property(e => e.CountryId).HasColumnName("COUNTRY_ID");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.LayerId).HasColumnName("LAYER_ID");
            entity.Property(e => e.Project1)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("PROJECT");
            entity.Property(e => e.SpId)
                .HasDefaultValue(1)
                .HasColumnName("SP_ID");

            entity.HasOne(d => d.Country).WithMany(p => p.Projects)
                .HasForeignKey(d => d.CountryId)
                .HasConstraintName("FK_PROJECT_COUNTRY");

            entity.HasOne(d => d.Layer).WithMany(p => p.Projects)
                .HasForeignKey(d => d.LayerId)
                .HasConstraintName("FK_PROJECT_TO_LAYER");

            entity.HasOne(d => d.Sp).WithMany(p => p.Projects)
                .HasForeignKey(d => d.SpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PROJECT_TO_STATUS_PROJECT");
        });

        modelBuilder.Entity<ProjectCollaborator>(entity =>
        {
            entity.HasKey(e => e.PcId).HasName("PK__PROJECT___B9EB73ADA6991DEF");

            entity.ToTable("PROJECT_COLLABORATOR");

            entity.Property(e => e.PcId).HasColumnName("PC_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Corporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("CORPORATE");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATE_DATE");
            entity.Property(e => e.ProjectId).HasColumnName("PROJECT_ID");

            entity.HasOne(d => d.CorporateNavigation).WithMany(p => p.ProjectCollaborators)
                .HasForeignKey(d => d.Corporate)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PROJECT_COLLABORATOR_TO_USER");

            entity.HasOne(d => d.Project).WithMany(p => p.ProjectCollaborators)
                .HasForeignKey(d => d.ProjectId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PROJECT_COLLABORATOR_TO_PROJECT");
        });

        modelBuilder.Entity<Provider>(entity =>
        {
            entity.HasKey(e => e.ProviderId).HasName("PK__PROVIDER__BF677C76E0187DA6");

            entity.ToTable("PROVIDER");

            entity.Property(e => e.ProviderId).HasColumnName("PROVIDER_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.External).HasColumnName("EXTERNAL");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NAME");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__ROL__2A76B76A84C1628D");

            entity.ToTable("ROLE");

            entity.Property(e => e.RoleId).HasColumnName("ROLE_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ROLE_NAME");
        });

        modelBuilder.Entity<SearchHistory>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__SEARCH_H__3214EC2791C4E1F2");

            entity.ToTable("SEARCH_HISTORY");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Corporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("CORPORATE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.DiagramId).HasColumnName("DIAGRAM_ID");
            entity.Property(e => e.ElementId).HasColumnName("ELEMENT_ID");
        });

        modelBuilder.Entity<Service>(entity =>
        {
            entity.HasKey(e => e.ServiceId).HasName("PK_Services");

            entity.ToTable("SERVICE");

            entity.Property(e => e.ServiceId).HasColumnName("SERVICE_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.ServiceName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("SERVICE_NAME");
        });

        modelBuilder.Entity<StatusProject>(entity =>
        {
            entity.HasKey(e => e.SpId).HasName("PK__STATUS_P__AA24DA2358C90738");

            entity.ToTable("STATUS_PROJECT");

            entity.Property(e => e.SpId).HasColumnName("SP_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATE_DATE");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.StatusName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("STATUS_NAME");
        });

        modelBuilder.Entity<System>(entity =>
        {
            entity.ToTable("SYSTEM");

            entity.HasIndex(e => e.ProjectId, "IX_SYSTEM_PROJECT_ID");

            entity.Property(e => e.SystemId).HasColumnName("SYSTEM_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.ProjectId).HasColumnName("PROJECT_ID");
            entity.Property(e => e.System1)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("SYSTEM");

            entity.HasOne(d => d.Project).WithMany(p => p.Systems)
                .HasForeignKey(d => d.ProjectId)
                .HasConstraintName("FK_SYSTEM_PROJECT");
        });

        modelBuilder.Entity<SystemRequest>(entity =>
        {
            entity.HasKey(e => e.SrId).HasName("PK__SYSTEM_R__1D8D1001A2F482AC");

            entity.ToTable("SYSTEM_REQUEST");

            entity.Property(e => e.SrId).HasColumnName("SR_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Authorized).HasColumnName("AUTHORIZED");
            entity.Property(e => e.Corporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("CORPORATE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("EMAIL");
            entity.Property(e => e.UserInformation)
                .IsUnicode(false)
                .HasColumnName("USER_INFORMATION");
            entity.Property(e => e.VerificationDate)
                .HasColumnType("datetime")
                .HasColumnName("VERIFICATION_DATE");
        });

        modelBuilder.Entity<SystemRequestDetail>(entity =>
        {
            entity.HasKey(e => e.SrdId).HasName("PK__SYSTEM_R__3F51A722FA2ACD02");

            entity.ToTable("SYSTEM_REQUEST_DETAIL");

            entity.Property(e => e.SrdId).HasColumnName("SRD_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Authorized).HasColumnName("AUTHORIZED");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.ProjectId).HasColumnName("PROJECT_ID");
            entity.Property(e => e.SrId).HasColumnName("SR_ID");

            entity.HasOne(d => d.Sr).WithMany(p => p.SystemRequestDetails)
                .HasForeignKey(d => d.SrId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SRD_TO_SYSTEM_REQUEST");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Corporate).HasName("PK__USER__EFF8E85CD63ED977");

            entity.ToTable("USER");

            entity.Property(e => e.Corporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("CORPORATE");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.CountryId)
                .HasDefaultValue(1)
                .HasColumnName("COUNTRY_ID");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.Department)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("DEPARTMENT");
            entity.Property(e => e.Email)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("EMAIL");
            entity.Property(e => e.FirstSession)
                .HasDefaultValue(true)
                .HasColumnName("FIRST_SESSION");
            entity.Property(e => e.Job)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("JOB");
            entity.Property(e => e.Names)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("NAMES");
            entity.Property(e => e.Passwordhash)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("PASSWORDHASH");
            entity.Property(e => e.Salt)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("SALT");
            entity.Property(e => e.Surnames)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("SURNAMES");
            entity.Property(e => e.UserId)
                .ValueGeneratedOnAdd()
                .HasColumnName("USER_ID");

            entity.HasOne(d => d.Country).WithMany(p => p.Users)
                .HasForeignKey(d => d.CountryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_USER_TO_COUNTRY");
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.HasKey(e => e.UrId).HasName("PK__USER_ROL__C6073B2AE5BCD4AF");

            entity.ToTable("USER_ROLE");

            entity.Property(e => e.UrId).HasColumnName("UR_ID");
            entity.Property(e => e.Active)
                .HasDefaultValue(true)
                .HasColumnName("ACTIVE");
            entity.Property(e => e.Corporate)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasColumnName("CORPORATE");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATION_DATE");
            entity.Property(e => e.RoleId).HasColumnName("ROLE_ID");

            entity.HasOne(d => d.CorporateNavigation).WithMany(p => p.UserRoles)
                .HasForeignKey(d => d.Corporate)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_USER_ROLE_TO_USER");

            entity.HasOne(d => d.Role).WithMany(p => p.UserRoles)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_USER_ROLE_TO_ROLE");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
