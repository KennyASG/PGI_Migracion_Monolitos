﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Country
{
    public string CountryCode { get; set; } = null!;

    public int Id { get; set; }

    public string CountryName { get; set; } = null!;

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public string? Domain { get; set; }

    public string? Client { get; set; }

    public virtual ICollection<Project> Projects { get; set; } = new List<Project>();

    public virtual ICollection<User> Users { get; set; } = new List<User>();
}
