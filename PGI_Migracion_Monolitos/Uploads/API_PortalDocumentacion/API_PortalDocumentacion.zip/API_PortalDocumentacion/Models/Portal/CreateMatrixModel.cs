﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class CreateMatrixModel
    {
        [Required(ErrorMessage = "El usuario que autoriza es requerido")]
        public string ActionUser { get; set; }
        public int? ProjectId { get; set; }
        [Required(ErrorMessage = "El diagrama al que pertenecerá la matriz es requerido")]
        public int DiagramId { get; set; } = 0;
        public bool? HasDynatrace { get; set; }
    }
}
