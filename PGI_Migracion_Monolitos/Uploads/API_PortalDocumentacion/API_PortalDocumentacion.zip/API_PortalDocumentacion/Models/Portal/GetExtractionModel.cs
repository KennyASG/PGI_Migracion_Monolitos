﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class GetExtractionModel
    {
        public IFormFile VisioFile { get; set; }
        public int DiagramId { get; set; } 
    }
}
