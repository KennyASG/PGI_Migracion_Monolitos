﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class DocumenterMenuItem
    {
        public int Id { get; set; }
        public int? ParentId { get; set; }
        public string DisplayText { get; set; } = null!;
        public int? DiagramId { get; set; }
        public int Level { get; set; }
        public int? ProjectId { get; set; }
        public int? ModuleId { get; set; }
        public int? LayerId { get; set; }
        public bool? IsModule { get; set; }
        public string? Classification { get; set; }
        public int? OptionId { get; set; }
        public string StatusName { get; set; }
        public DateTime? CreationDate { get; set; }
        public int? CountryId { get; set; }
        public string? CountryCode { get; set; }
        public string? CountryName { get; set; }
        public virtual ICollection<DocumenterMenuItem> Children { get; set; } = new List<DocumenterMenuItem>();
    }
}
