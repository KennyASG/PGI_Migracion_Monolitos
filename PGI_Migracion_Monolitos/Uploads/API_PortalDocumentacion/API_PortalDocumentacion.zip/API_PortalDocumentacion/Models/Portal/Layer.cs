﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Layer
{
    public int LayerId { get; set; }

    public string LayerName { get; set; } = null!;

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public virtual ICollection<Project> Projects { get; set; } = new List<Project>();
}
