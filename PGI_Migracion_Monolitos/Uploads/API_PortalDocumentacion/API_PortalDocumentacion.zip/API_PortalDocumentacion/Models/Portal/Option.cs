﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Option
{
    public int OptionId { get; set; }

    public string OptionName { get; set; } = null!;

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public int? ModuleId { get; set; }

    public int SpId { get; set; }

    public virtual ICollection<Diagram> Diagrams { get; set; } = new List<Diagram>();

    public virtual Module? Module { get; set; }

    public virtual StatusProject Sp { get; set; } = null!;
}
