﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class MatrixTemplateDetail
{
    public int Mtd { get; set; }

    public int MtemplateId { get; set; }

    public int MoptionId { get; set; }

    public virtual MatrixOption Moption { get; set; } = null!;

    public virtual MatrixTemplate Mtemplate { get; set; } = null!;
}
