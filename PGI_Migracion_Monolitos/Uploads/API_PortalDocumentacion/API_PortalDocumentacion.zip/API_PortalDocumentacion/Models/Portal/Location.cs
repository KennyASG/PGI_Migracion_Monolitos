﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Location
{
    public int LocationId { get; set; }

    public string LocationName { get; set; } = null!;

    public string? Description { get; set; }

    public bool Active { get; set; }

    public DateTime CreationDate { get; set; }

    public virtual ICollection<Element> Elements { get; set; } = new List<Element>();
}
