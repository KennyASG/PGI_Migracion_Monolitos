﻿using System.Net;

namespace API_PortalDocumentacion.Models.Portal
{
    public class ResponseAPI
    {
        public ResponseAPI()
        {
            Message = new List<string>();
        }

        public HttpStatusCode StatusCode { get; set; }
        public bool IsSuccess { get; set; } = true;
        public List<string> Message { get; set; }
        public object Detail { get; set; }
    }
}
