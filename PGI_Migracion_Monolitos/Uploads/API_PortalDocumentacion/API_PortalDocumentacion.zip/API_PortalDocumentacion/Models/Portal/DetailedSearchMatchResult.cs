﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class DetailedSearchMatchResult
    {
        public string Element { get; set; }
        public string ElementType { get; set; }
        public string System { get; set; }
        public string Project { get; set; }
        public string Module { get; set; }
        public string Diagram { get; set; }
        public int DiagramId { get; set; }
        public int ElementId { get; set; }
        public int CountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
    }
}
