﻿using System.ComponentModel.DataAnnotations;

namespace API_PortalDocumentacion.Models.Portal
{
    public class GetNotifAndRequestCountModel
    {
        [Required(ErrorMessage = "El corporativo es requerido")]
        public string Corporate { get; set; }
        public NotificationStatus? NotificationStatus { get; set; } = 0;
        public NotificationType? NotificationType { get; set; } = 0;
        public RequestStatus? RequestStatus { get; set; } = 0;
        public UserCountStatus UserCountStatus { get; set; } = 0;
        public ProjectCountStatus ProjectCountStatus { get; set; } = 0;
    }

    public enum NotificationStatus
    {
        None = 0,
        All = 1,
        Pending = 2,
        Accepted = 3,
        Rejected = 4
    }

    public enum NotificationType
    {
        None = 0,
        Documenter = 1,
        Admin = 2
    }

    public enum RequestStatus
    {
        None = 0,
        All = 1,
        Pending = 2,
        Accepted = 3,
        Rejected = 4
    }

    public enum UserCountStatus
    {
        None = 0,
        All = 1
    }

    public enum ProjectCountStatus
    {
        None = 0,
        All = 1
    }
}
