﻿using System;
using System.Collections.Generic;

namespace API_PortalDocumentacion.Models.Portal;

public partial class Element
{
    public int ElementId { get; set; }

    public int ElementTypeId { get; set; }

    public string? Element1 { get; set; }

    public string? Description { get; set; }

    public int? PElementId { get; set; }

    public string? ProgLeng { get; set; }

    public string? Version { get; set; }

    public int? DevBy { get; set; }

    public int? MaintBy { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreationDate { get; set; }

    public string? IpAdministration { get; set; }

    public int? LocationId { get; set; }

    public int? AdminId { get; set; }

    public virtual Administrator? Admin { get; set; }

    public virtual ICollection<Detail> Details { get; set; } = new List<Detail>();

    public virtual Provider? DevByNavigation { get; set; }

    public virtual ElementType ElementType { get; set; } = null!;

    public virtual ICollection<Interface> Interfaces { get; set; } = new List<Interface>();

    public virtual ICollection<Element> InversePElement { get; set; } = new List<Element>();

    public virtual Location? Location { get; set; }

    public virtual Provider? MaintByNavigation { get; set; }

    public virtual ICollection<Monitoring> Monitorings { get; set; } = new List<Monitoring>();

    public virtual Element? PElement { get; set; }
}
