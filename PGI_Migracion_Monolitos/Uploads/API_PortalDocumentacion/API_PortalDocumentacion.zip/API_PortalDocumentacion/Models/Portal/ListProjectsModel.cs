﻿namespace API_PortalDocumentacion.Models.Portal
{
    public class ListProjectsModel
    {
    }
}
