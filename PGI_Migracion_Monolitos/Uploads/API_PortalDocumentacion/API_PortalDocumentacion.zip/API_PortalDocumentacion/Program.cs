using API_PortalDocumentacion.Repository;
using API_PortalDocumentacion.Mappers;
using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using OfficeOpenXml;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Mvc;
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Tools;

var builder = WebApplication.CreateBuilder(args);

//#######################################################################################
//configuration of the connection to SQL SERVER
builder.Services.AddDbContext<DbPortalDocumentacionContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("PathConnectionDBPortal")));

//Add Memory Cache
builder.Services.AddMemoryCache();

//Add repositorys
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IAuthRepository, AuthRepository>();
builder.Services.AddScoped<IAdminRepository, AdminRepository>();
builder.Services.AddScoped<IDashboardRepository, DashboardRepository>();
builder.Services.AddScoped<IMenuRepository, MenuRepository>();
builder.Services.AddScoped<IContentRepository, ContentLLRepository>();
builder.Services.AddScoped<IContentPLRepository, ContentPLRepository>();
builder.Services.AddScoped<IExtractionRepository, ExtractionRepository>();
builder.Services.AddScoped<IProjectRepository, ProjectRepository>();
builder.Services.AddScoped<IAnalystRepository, AnalystRepository>();
builder.Services.AddScoped<INotificationRepository, NotificationRepository>();
builder.Services.AddScoped<ICountryRepository, CountryRepository>();
builder.Services.AddScoped<NotificationSender>();

//Add support CACHE
builder.Services.AddResponseCaching();

// Set EPPlus License Context
ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

//Add cache profile
builder.Services.AddControllers( option =>
{
    option.CacheProfiles.Add("Default20Seconds", new CacheProfile() { Duration = 30});
    option.CacheProfiles.Add("Default24Hours", new CacheProfile() { Duration = 86400});
});

//Add custom error validations
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.InvalidModelStateResponseFactory = context =>
    {
        var errors = context.ModelState
            .Where(e => e.Value.Errors.Count > 0)
            .ToDictionary(
                e => e.Key,
                e => e.Value.Errors.Select(x => x.ErrorMessage).ToArray()
            );

        var errorResponse = new
        {
            StatusCode = StatusCodes.Status400BadRequest,
            isSuccess = false,
            Message = "Uno o más campos no son validos.",
            Detail = errors
        };

        return new BadRequestObjectResult(errorResponse);
    };
});

//Add Mappers
builder.Services.AddAutoMapper(typeof(UserMappper));

//Add CORS
builder.Services.AddCors(options => options.AddPolicy("AllowAllOrigins", builder =>
{
    builder.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
}));

var key = builder.Configuration.GetValue<string>("AppSettings:Secret");

//Add Authentication
builder.Services.AddAuthentication(config =>
{
    config.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    config.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(config =>
{
    config.RequireHttpsMetadata = false;
    config.SaveToken = true;
    config.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(key)),
        ValidateIssuer = false,
        ValidateAudience = false
    };
}
);

builder.Services.AddSwaggerGen(swagger =>
{
    //This is to generate the Default UI of Swagger Documentation
    swagger.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "Bi Portal Documentación API",
        Description = ".NET 8 Web API (Backend) to Bi Portal Documentación.",
        
    });

    // Use XML comments
    var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    //swagger.IncludeXmlComments(xmlPath);

    // To Enable authorization using Swagger (JWT)
    swagger.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
    });
    swagger.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
                 {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
            new string[] {}

        }
    });
});

//#######################################################################################

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

// Configure the HTTP request pipeline
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/back/swagger/v1/swagger.json", "Bi Portal Documentacion API"));
//}

app.UseOpenApi();

app.UseCors("AllowAllOrigins");

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
