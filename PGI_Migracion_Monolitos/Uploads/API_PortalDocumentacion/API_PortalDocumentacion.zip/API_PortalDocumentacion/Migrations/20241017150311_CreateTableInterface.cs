﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_PortalDocumentacion.Migrations
{
    /// <inheritdoc />
    public partial class CreateTableInterface : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "INTERFACE",
                columns: table => new
                {
                    INTERFACE_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ELEMENT_ID = table.Column<int>(type: "int", nullable: false),
                    INTERFACE_NAME = table.Column<string>(type: "varchar(100)", nullable: false),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: false),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INTERFACES", x => x.INTERFACE_ID);
                    table.ForeignKey(
                        name: "FK_INTERFACE_TO_ELEMENT",
                        column: x => x.ELEMENT_ID,
                        principalTable: "ELEMENT",
                        principalColumn: "ELEMENT_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Interfaces_ElementId",
                table: "INTERFACE",
                column: "ELEMENT_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "INTERFACES");
        }
    }
}
