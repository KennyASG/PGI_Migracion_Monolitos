﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_PortalDocumentacion.Migrations
{
    /// <inheritdoc />
    public partial class AlterTableElement : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "IP_ADMINISTRATION",
                table: "ELEMENT",
                type: "varchar(20)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "LOCATION_ID",
                table: "ELEMENT",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_ELEMENT_LocationId",
                table: "ELEMENT",
                column: "LOCATION_ID");

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

            migrationBuilder.DropIndex(
                name: "IX_ELEMENT_LocationId",
                table: "ELEMENT");

            migrationBuilder.DropColumn(
                name: "IP_ADMINISTRATION",
                table: "ELEMENT");

            migrationBuilder.DropColumn(
                name: "LOCATION_ID",
                table: "ELEMENT");
        }
    }
}
