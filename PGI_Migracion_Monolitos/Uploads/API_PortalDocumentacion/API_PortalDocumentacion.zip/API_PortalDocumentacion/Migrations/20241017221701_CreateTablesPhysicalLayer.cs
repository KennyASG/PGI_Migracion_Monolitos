﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_PortalDocumentacion.Migrations
{
    /// <inheritdoc />
    public partial class CreateTablesPhysicalLayer : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LOCATION",
                columns: table => new
                {
                    LOCATION_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LOCATION_NAME = table.Column<string>(type: "varchar(100)", nullable: false),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: false),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Locations", x => x.LOCATION_ID);
                });

            migrationBuilder.CreateTable(
                name: "PLATFORM",
                columns: table => new
                {
                    PLATFORM_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLATFORM_NAME = table.Column<string>(type: "varchar(100)", nullable: false),
                    OWNER = table.Column<string>(type: "varchar(100)", nullable: false),
                    AIOPS_CONNECTION = table.Column<bool>(type: "bit", nullable: false),
                    AIOPS_INTERPRETATION = table.Column<bool>(type: "bit", nullable: false),
                    OBSERVATIONS = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: false),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Platforms", x => x.PLATFORM_ID);
                });

            migrationBuilder.CreateTable(
                name: "SERVICE",
                columns: table => new
                {
                    SERVICE_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SERVICE_NAME = table.Column<string>(type: "varchar(100)", nullable: false),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: false),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Services", x => x.SERVICE_ID);
                });

            migrationBuilder.CreateTable(
                name: "MONITORING",
                columns: table => new
                {
                    MONITORING_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ELEMENT_ID = table.Column<int>(type: "int", nullable: false),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", nullable: false),
                    PLATFORM_ID = table.Column<int>(type: "int", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: false),
                    CREACTION_DATE = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Monitorings", x => x.MONITORING_ID);
                    table.ForeignKey(
                        name: "FK_MONITORING_TO_ELEMENT",
                        column: x => x.ELEMENT_ID,
                        principalTable: "ELEMENT",
                        principalColumn: "ELEMENT_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MONITORING_TO_PLATFORM",
                        column: x => x.PLATFORM_ID,
                        principalTable: "PLATFORM",
                        principalColumn: "PLATFORM_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CONNECTION",
                columns: table => new
                {
                    CONNECTION_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DIAGRAM_ID = table.Column<int>(type: "int", nullable: false),
                    F_INTERFACE_ID = table.Column<int>(type: "int", nullable: false),
                    S_INTERFACE_ID = table.Column<int>(type: "int", nullable: false),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", nullable: false),
                    SERVICE_ID = table.Column<int>(type: "int", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: false),
                    LAST_UPDATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Connections", x => x.CONNECTION_ID);
                    table.ForeignKey(
                        name: "FK_CONNETION_TO_DIAGRAM",
                        column: x => x.DIAGRAM_ID,
                        principalTable: "DIAGRAM",
                        principalColumn: "DIAGRAM_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CONNECTION_TO_INTERFACE_FIRST",
                        column: x => x.F_INTERFACE_ID,
                        principalTable: "INTERFACE",
                        principalColumn: "INTERFACE_ID",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_CONNECTION_TO_INTERFACE_SECOND",
                        column: x => x.S_INTERFACE_ID,
                        principalTable: "INTERFACE",
                        principalColumn: "INTERFACE_ID",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_CONNECTION_TO_SERVICE",
                        column: x => x.SERVICE_ID,
                        principalTable: "SERVICE",
                        principalColumn: "SERVICE_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Connections_DiagramId",
                table: "CONNECTION",
                column: "DIAGRAM_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Connections_FInterfaceId",
                table: "CONNECTION",
                column: "F_INTERFACE_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Connections_ServiceId",
                table: "CONNECTION",
                column: "SERVICE_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Connections_SInterfaceId",
                table: "CONNECTION",
                column: "S_INTERFACE_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Monitorings_ElementId",
                table: "MONITORING",
                column: "ELEMENT_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Monitorings_PlatformId",
                table: "MONITORING",
                column: "PLATFORM_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CONNECTION");

            migrationBuilder.DropTable(
                name: "LOCATION");

            migrationBuilder.DropTable(
                name: "MONITORING");

            migrationBuilder.DropTable(
                name: "SERVICE");

            migrationBuilder.DropTable(
                name: "PLATFORM");
        }
    }
}
