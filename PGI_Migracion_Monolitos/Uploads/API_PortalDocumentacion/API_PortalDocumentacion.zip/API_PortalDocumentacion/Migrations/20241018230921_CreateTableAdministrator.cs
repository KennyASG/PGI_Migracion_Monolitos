﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_PortalDocumentacion.Migrations
{
    /// <inheritdoc />
    public partial class CreateTablesAdministrator : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ADMINISTRATOR",
                columns: table => new
                {
                    ADMIN_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ADMIN_NAME = table.Column<string>(type: "varchar(200)", nullable: false),
                    PHONE_NUMBER = table.Column<string>(type: "varchar(25)", nullable: false),
                    AREA = table.Column<string>(type: "varchar(max)", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: false),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Administrators", x => x.ADMIN_ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ADMINISTRATOR");
        }
    }
}
