﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_PortalDocumentacion.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "COUNTRY",
                columns: table => new
                {
                    COUNTRY_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    COUNTRY_NAME = table.Column<string>(type: "varchar(25)", unicode: false, maxLength: 25, nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__COUNTRY__FC7F5907223325B2", x => x.COUNTRY_CODE);
                });

            migrationBuilder.CreateTable(
                name: "ELEMENT_TYPE",
                columns: table => new
                {
                    ELEMENT_TYPE_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ELEMENT_TYPE = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ELEMENT_TYPE", x => x.ELEMENT_TYPE_ID);
                });

            migrationBuilder.CreateTable(
                name: "INSTALLATION",
                columns: table => new
                {
                    INSTALLATION_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INSTALLATION = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false),
                    RATIONAL = table.Column<int>(type: "int", nullable: true),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INSTALLATION", x => x.INSTALLATION_ID);
                });

            migrationBuilder.CreateTable(
                name: "LAYER",
                columns: table => new
                {
                    LAYER_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LAYER_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__LAYER__038B6C0E7A794B19", x => x.LAYER_ID);
                });

            migrationBuilder.CreateTable(
                name: "LOG_ACTION",
                columns: table => new
                {
                    LA_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ACTION_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__LOG_ACTI__A57D4D584241AF16", x => x.LA_ID);
                });

            migrationBuilder.CreateTable(
                name: "MODULE",
                columns: table => new
                {
                    MODULE_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MODULE_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    PROJECT_ID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MODULE__238A8246826BADC9", x => x.MODULE_ID);
                });

            migrationBuilder.CreateTable(
                name: "OPTION",
                columns: table => new
                {
                    OPTION_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OPTION_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__OPTION__1E24B66940D196A1", x => x.OPTION_ID);
                });

            migrationBuilder.CreateTable(
                name: "PROVIDER",
                columns: table => new
                {
                    PROVIDER_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    EXTERNAL = table.Column<bool>(type: "bit", nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PROVIDER__BF677C76E0187DA6", x => x.PROVIDER_ID);
                });

            migrationBuilder.CreateTable(
                name: "ROLE",
                columns: table => new
                {
                    ROLE_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ROLE_NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__ROL__2A76B76A84C1628D", x => x.ROLE_ID);
                });

            migrationBuilder.CreateTable(
                name: "SEARCH_HISTORY",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CORPORATE = table.Column<string>(type: "varchar(12)", unicode: false, maxLength: 12, nullable: false),
                    DIAGRAM_ID = table.Column<int>(type: "int", nullable: false),
                    ELEMENT_ID = table.Column<int>(type: "int", nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SEARCH_H__3214EC2791C4E1F2", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SYSTEM_REQUEST",
                columns: table => new
                {
                    SR_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CORPORATE = table.Column<string>(type: "varchar(12)", unicode: false, maxLength: 12, nullable: false),
                    EMAIL = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    AUTHORIZED = table.Column<bool>(type: "bit", nullable: true),
                    VERIFICATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    USER_INFORMATION = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYSTEM_R__1D8D1001A2F482AC", x => x.SR_ID);
                });

            migrationBuilder.CreateTable(
                name: "USER",
                columns: table => new
                {
                    CORPORATE = table.Column<string>(type: "varchar(12)", unicode: false, maxLength: 12, nullable: false),
                    USER_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PASSWORDHASH = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true),
                    NAMES = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    SURNAMES = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    EMAIL = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    FIRST_SESSION = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    DEPARTMENT = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true),
                    JOB = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    SALT = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__USER__EFF8E85CD63ED977", x => x.CORPORATE);
                });

            migrationBuilder.CreateTable(
                name: "PROJECT",
                columns: table => new
                {
                    PROJECT_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PROJECT = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    LAYER_ID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PROJECT", x => x.PROJECT_ID);
                    table.ForeignKey(
                        name: "FK_PROJECT_TO_LAYER",
                        column: x => x.LAYER_ID,
                        principalTable: "LAYER",
                        principalColumn: "LAYER_ID");
                });

            migrationBuilder.CreateTable(
                name: "LOG",
                columns: table => new
                {
                    LOG_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CORPORATE = table.Column<string>(type: "varchar(12)", unicode: false, maxLength: 12, nullable: false),
                    DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    LA_ID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__LOG__4364C882AFF4B3C6", x => x.LOG_ID);
                    table.ForeignKey(
                        name: "FK_LOG_TO_LOG_ACTION",
                        column: x => x.LA_ID,
                        principalTable: "LOG_ACTION",
                        principalColumn: "LA_ID");
                });

            migrationBuilder.CreateTable(
                name: "DIAGRAM",
                columns: table => new
                {
                    DIAGRAM_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DIAGRAM = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: false),
                    FILE_PATH = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: false),
                    MODULE_ID = table.Column<int>(type: "int", nullable: true),
                    INSTALLATION_ID = table.Column<int>(type: "int", nullable: true),
                    OPTION_ID = table.Column<int>(type: "int", nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DIAGRAM", x => x.DIAGRAM_ID);
                    table.ForeignKey(
                        name: "FK_DIAGRAM_INSTALLATION",
                        column: x => x.INSTALLATION_ID,
                        principalTable: "INSTALLATION",
                        principalColumn: "INSTALLATION_ID");
                    table.ForeignKey(
                        name: "FK_DIAGRAM_TO_MODULE",
                        column: x => x.MODULE_ID,
                        principalTable: "MODULE",
                        principalColumn: "MODULE_ID");
                    table.ForeignKey(
                        name: "FK_DIAGRAM_TO_OPTION",
                        column: x => x.OPTION_ID,
                        principalTable: "OPTION",
                        principalColumn: "OPTION_ID");
                });

            migrationBuilder.CreateTable(
                name: "ELEMENT",
                columns: table => new
                {
                    ELEMENT_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ELEMENT_TYPE_ID = table.Column<int>(type: "int", nullable: false),
                    ELEMENT = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    P_ELEMENT_ID = table.Column<int>(type: "int", nullable: true),
                    PROG_LENG = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    VERSION = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DEV_BY = table.Column<int>(type: "int", nullable: true),
                    MAINT_BY = table.Column<int>(type: "int", nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ELEMENT", x => x.ELEMENT_ID);
                    table.ForeignKey(
                        name: "FK_ELEMENT_ELEMENT",
                        column: x => x.P_ELEMENT_ID,
                        principalTable: "ELEMENT",
                        principalColumn: "ELEMENT_ID");
                    table.ForeignKey(
                        name: "FK_ELEMENT_ELEMENT_TYPE",
                        column: x => x.ELEMENT_TYPE_ID,
                        principalTable: "ELEMENT_TYPE",
                        principalColumn: "ELEMENT_TYPE_ID");
                    table.ForeignKey(
                        name: "FK_ELEMENT_TO_PROVIDER_DEV",
                        column: x => x.DEV_BY,
                        principalTable: "PROVIDER",
                        principalColumn: "PROVIDER_ID");
                    table.ForeignKey(
                        name: "FK_ELEMENT_TO_PROVIDER_MAINT",
                        column: x => x.MAINT_BY,
                        principalTable: "PROVIDER",
                        principalColumn: "PROVIDER_ID");
                });

            migrationBuilder.CreateTable(
                name: "SYSTEM_REQUEST_DETAIL",
                columns: table => new
                {
                    SRD_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SR_ID = table.Column<int>(type: "int", nullable: false),
                    PROJECT_ID = table.Column<int>(type: "int", nullable: false),
                    AUTHORIZED = table.Column<bool>(type: "bit", nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYSTEM_R__3F51A722FA2ACD02", x => x.SRD_ID);
                    table.ForeignKey(
                        name: "FK_SRD_TO_SYSTEM_REQUEST",
                        column: x => x.SR_ID,
                        principalTable: "SYSTEM_REQUEST",
                        principalColumn: "SR_ID");
                });

            migrationBuilder.CreateTable(
                name: "PERMISSION",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CORPORATE = table.Column<string>(type: "varchar(12)", unicode: false, maxLength: 12, nullable: false),
                    PROJECT_ID = table.Column<int>(type: "int", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PERMISSI__3214EC272F1643DA", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PERMISSION_TO_USER",
                        column: x => x.CORPORATE,
                        principalTable: "USER",
                        principalColumn: "CORPORATE");
                });

            migrationBuilder.CreateTable(
                name: "USER_ROLE",
                columns: table => new
                {
                    UR_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CORPORATE = table.Column<string>(type: "varchar(12)", unicode: false, maxLength: 12, nullable: false),
                    ROLE_ID = table.Column<int>(type: "int", nullable: false),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__USER_ROL__C6073B2AE5BCD4AF", x => x.UR_ID);
                    table.ForeignKey(
                        name: "FK_USER_ROLE_TO_ROLE",
                        column: x => x.ROLE_ID,
                        principalTable: "ROLE",
                        principalColumn: "ROLE_ID");
                    table.ForeignKey(
                        name: "FK_USER_ROLE_TO_USER",
                        column: x => x.CORPORATE,
                        principalTable: "USER",
                        principalColumn: "CORPORATE");
                });

            migrationBuilder.CreateTable(
                name: "SYSTEM",
                columns: table => new
                {
                    SYSTEM_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SYSTEM = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    PROJECT_ID = table.Column<int>(type: "int", nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SYSTEM", x => x.SYSTEM_ID);
                    table.ForeignKey(
                        name: "FK_SYSTEM_PROJECT",
                        column: x => x.PROJECT_ID,
                        principalTable: "PROJECT",
                        principalColumn: "PROJECT_ID");
                });

            migrationBuilder.CreateTable(
                name: "DETAIL",
                columns: table => new
                {
                    DETAIL_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DIAGRAM_ID = table.Column<int>(type: "int", nullable: false),
                    SYSTEM_ID = table.Column<int>(type: "int", nullable: false),
                    ELEMENT_ID = table.Column<int>(type: "int", nullable: false),
                    NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    REPETITION = table.Column<int>(type: "int", nullable: false, defaultValue: 1),
                    DESCRIPTION = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    ACTIVE = table.Column<bool>(type: "bit", nullable: true, defaultValue: true),
                    CREATION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DETAIL", x => x.DETAIL_ID);
                    table.ForeignKey(
                        name: "FK_DETAIL_DIAGRAM",
                        column: x => x.DIAGRAM_ID,
                        principalTable: "DIAGRAM",
                        principalColumn: "DIAGRAM_ID");
                    table.ForeignKey(
                        name: "FK_DETAIL_ELEMENT",
                        column: x => x.ELEMENT_ID,
                        principalTable: "ELEMENT",
                        principalColumn: "ELEMENT_ID");
                    table.ForeignKey(
                        name: "FK_DETAIL_SYSTEM",
                        column: x => x.SYSTEM_ID,
                        principalTable: "SYSTEM",
                        principalColumn: "SYSTEM_ID");
                });

            migrationBuilder.CreateIndex(
                name: "IX_DETAIL_DIAGRAM_ID",
                table: "DETAIL",
                column: "DIAGRAM_ID");

            migrationBuilder.CreateIndex(
                name: "IX_DETAIL_ELEMENT_ID",
                table: "DETAIL",
                column: "ELEMENT_ID");

            migrationBuilder.CreateIndex(
                name: "IX_DETAIL_SYSTEM_ID",
                table: "DETAIL",
                column: "SYSTEM_ID");

            migrationBuilder.CreateIndex(
                name: "IX_DIAGRAM_INSTALLATION_ID",
                table: "DIAGRAM",
                column: "INSTALLATION_ID");

            migrationBuilder.CreateIndex(
                name: "IX_DIAGRAM_MODULE_ID",
                table: "DIAGRAM",
                column: "MODULE_ID");

            migrationBuilder.CreateIndex(
                name: "IX_DIAGRAM_OPTION_ID",
                table: "DIAGRAM",
                column: "OPTION_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ELEMENT_DEV_BY",
                table: "ELEMENT",
                column: "DEV_BY");

            migrationBuilder.CreateIndex(
                name: "IX_ELEMENT_ELEMENT_TYPE_ID",
                table: "ELEMENT",
                column: "ELEMENT_TYPE_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ELEMENT_MAINT_BY",
                table: "ELEMENT",
                column: "MAINT_BY");

            migrationBuilder.CreateIndex(
                name: "IX_ELEMENT_P_ELEMENT_ID",
                table: "ELEMENT",
                column: "P_ELEMENT_ID");

            migrationBuilder.CreateIndex(
                name: "IX_LOG_LA_ID",
                table: "LOG",
                column: "LA_ID");

            migrationBuilder.CreateIndex(
                name: "IX_PERMISSION_CORPORATE",
                table: "PERMISSION",
                column: "CORPORATE");

            migrationBuilder.CreateIndex(
                name: "IX_PERMISSION_MENU_ID",
                table: "PERMISSION",
                column: "PROJECT_ID");

            migrationBuilder.CreateIndex(
                name: "IX_PROJECT_LAYER_ID",
                table: "PROJECT",
                column: "LAYER_ID");

            migrationBuilder.CreateIndex(
                name: "IX_SYSTEM_PROJECT_ID",
                table: "SYSTEM",
                column: "PROJECT_ID");

            migrationBuilder.CreateIndex(
                name: "IX_SYSTEM_REQUEST_DETAIL_SR_ID",
                table: "SYSTEM_REQUEST_DETAIL",
                column: "SR_ID");

            migrationBuilder.CreateIndex(
                name: "IX_USER_ROLE_CORPORATE",
                table: "USER_ROLE",
                column: "CORPORATE");

            migrationBuilder.CreateIndex(
                name: "IX_USER_ROLE_ROLE_ID",
                table: "USER_ROLE",
                column: "ROLE_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "COUNTRY");

            migrationBuilder.DropTable(
                name: "DETAIL");

            migrationBuilder.DropTable(
                name: "LOG");

            migrationBuilder.DropTable(
                name: "PERMISSION");

            migrationBuilder.DropTable(
                name: "SEARCH_HISTORY");

            migrationBuilder.DropTable(
                name: "SYSTEM_REQUEST_DETAIL");

            migrationBuilder.DropTable(
                name: "USER_ROLE");

            migrationBuilder.DropTable(
                name: "DIAGRAM");

            migrationBuilder.DropTable(
                name: "ELEMENT");

            migrationBuilder.DropTable(
                name: "SYSTEM");

            migrationBuilder.DropTable(
                name: "LOG_ACTION");

            migrationBuilder.DropTable(
                name: "SYSTEM_REQUEST");

            migrationBuilder.DropTable(
                name: "ROLE");

            migrationBuilder.DropTable(
                name: "USER");

            migrationBuilder.DropTable(
                name: "INSTALLATION");

            migrationBuilder.DropTable(
                name: "MODULE");

            migrationBuilder.DropTable(
                name: "OPTION");

            migrationBuilder.DropTable(
                name: "ELEMENT_TYPE");

            migrationBuilder.DropTable(
                name: "PROVIDER");

            migrationBuilder.DropTable(
                name: "PROJECT");

            migrationBuilder.DropTable(
                name: "LAYER");
        }
    }
}
