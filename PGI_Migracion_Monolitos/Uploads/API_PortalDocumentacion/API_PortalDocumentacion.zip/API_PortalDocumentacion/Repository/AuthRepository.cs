using API_PortalDocumentacion.Repository.IRepository;
using System.Security.Cryptography;
using Novell.Directory.Ldap;
using LdapConnection = Novell.Directory.Ldap.LdapConnection;
//using System.DirectoryServices.Protocols;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Models.Portal;
using System.Net;

namespace API_PortalDocumentacion.Repository
{
    public class AuthRepository : IAuthRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;
        public LoginResponseDTO responseDTO = new();
        public IConfiguration _configuration;
        public int countryId = 0;

        //Class constructor
        public AuthRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration)
        {
            this._dbContext = dbContext;
            this._configuration = configuration;
        }

        //Login with local user
        public LoginResponseDTO LoginLocal(LoginRequestLocalDTO loginRequestLocalDTO)
        {
            LoginResponseDTO responseDTO = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var userInfo = _dbContext.Users.FirstOrDefault(u => u.Corporate == loginRequestLocalDTO.username);

                transaction.Commit();

                if (userInfo == null) return null;
                if (userInfo.Passwordhash == null || userInfo.Salt == null) return null;

                // Convertir la sal de Base64 a bytes
                byte[] salt = Convert.FromBase64String(userInfo.Salt);

                // Derivar el hash usando la misma sal
                using (var pbkdf2 = new Rfc2898DeriveBytes(loginRequestLocalDTO.Password, salt, 100000, HashAlgorithmName.SHA256))
                {
                    byte[] hash = pbkdf2.GetBytes(32);
                    string hashBase64 = Convert.ToBase64String(hash);

                    // Comparar los hashes
                    if (hashBase64 != userInfo.Passwordhash) return null;

                    responseDTO.Corporate = userInfo.Corporate;
                    responseDTO.Names = userInfo.Names;
                    responseDTO.Surnames = userInfo.Surnames;
                    responseDTO.FirstSession = userInfo.FirstSession;
                    responseDTO.Token = CreateJWT(loginRequestLocalDTO.username, 1);
                    responseDTO.CountryId = null;

                    return responseDTO;
                }
            }
        }

        //LoginLDAP
        public LoginResponseDTO LoginLDAP(LoginRequestLDAP_DTO loginRequestDTO)
        {
            try
            {
                var country = _dbContext.Countries.Where(c => c.Id == loginRequestDTO.CountryId).FirstOrDefault();
                countryId = country.Id;

                using (var connection = new LdapConnection())
                {
                    var domain = (country.Id == 1) ? $"{country.Client}.local" : $"{country.CountryCode}.{country.Client}.local";
                    connection.Connect(domain, 389);

                    // Configurar restricciones para seguir referencias
                    LdapSearchConstraints constraints = connection.SearchConstraints;
                    constraints.ReferralFollowing = true;
                    connection.Constraints = constraints;

                    connection.Bind($"{loginRequestDTO.Corporate}{country.Domain}", loginRequestDTO.Password);

                    return SearchUserLDAP(connection, loginRequestDTO.Corporate, country);
                }
            }
            catch (LdapException ldapEx)
            {
                switch (ldapEx.ResultCode)
                {
                    case 49:
                        responseDTO.Corporate = "Invalid Credentials";
                        break;
                    case 81:
                        responseDTO.Corporate = "Connect Error";
                        break;
                    case 533:
                        responseDTO.Corporate = "Account Locked";
                        break;
                    default:
                        responseDTO.Corporate = ldapEx.Message;
                        break;
                }
                return responseDTO;
            }
        }

        //Function to find data user in database
        private LoginResponseDTO SearchUserLDAP(LdapConnection connection, string corporate, Country country)
        {
            string baseDn = $"DC={country.CountryCode},DC={country.Client},DC=local";
            string searchFilter = $"(sAMAccountName={corporate})";

            if (country.Id == 1) baseDn = $"DC={country.Client},DC=local";

            ILdapSearchResults result = connection.Search(baseDn, 2, searchFilter, null, false);

            var entry = result.Next();
            var attributes = entry.GetAttributeSet();

            string names = attributes.ContainsKey("givenName") ? attributes.GetAttribute("givenName").StringValue : "No asignados";
            string surnames = attributes.ContainsKey("sn") ? attributes.GetAttribute("sn").StringValue : "No asignados";
            string email = attributes.ContainsKey("mail") ? attributes.GetAttribute("mail").StringValue : "No asignado";
            string department = attributes.ContainsKey("department") ? attributes.GetAttribute("department").StringValue : "No asignado";
            string job = attributes.ContainsKey("title") ? attributes.GetAttribute("title").StringValue : "No asignado";

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var userInfo = _dbContext.Users.FirstOrDefault(u => u.Corporate == corporate);

                transaction.Commit();

                if (userInfo == null)
                {
                    responseDTO = new LoginResponseDTO()
                    {
                        Corporate = corporate,
                        Names = names,
                        Surnames = surnames,
                        FirstSession = true,
                        Token = "",
                        Email = email,
                        Department = department,
                        Job = job,
                        CountryId = countryId
                    };

                    return responseDTO;
                }

                if (userInfo.FirstSession == true)
                {
                    if (result.HasMore())
                    {
                        userInfo.Names = names;
                        userInfo.Surnames = surnames;
                        userInfo.Email = email;
                        userInfo.FirstSession = false;
                        userInfo.Department = department;
                        userInfo.Job = job;

                        responseDTO = new LoginResponseDTO()
                        {
                            Corporate = corporate,
                            Names = names,
                            Surnames = surnames,
                            FirstSession = userInfo.FirstSession,
                            CountryId = null,
                            Token = CreateJWT(corporate, countryId)
                        };

                        return responseDTO;
                    }
                    else
                    {
                        throw new Exception("The user was not found on the established route");
                    }
                }
                else
                {
                    responseDTO = new LoginResponseDTO()
                    {
                        Corporate = userInfo.Corporate,
                        Names = userInfo.Names,
                        Surnames = userInfo.Surnames,
                        FirstSession = userInfo.FirstSession,
                        CountryId = null,
                        Token = CreateJWT(corporate, countryId)
                    };

                    return responseDTO;
                }
            }
        }

        //Create JsonWebToken
        public string CreateJWT(string corporate, int countryId)
        {
            try
            {
                using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
                {
                    //Get roles from user
                    List<int> query = _dbContext.UserRoles.Where(r => r.Corporate == corporate && r.Active == true).Select(r => r.RoleId).ToList();
                    transaction.Commit();
                    var roles = string.Join(",", query);

                    //Create token JWT
                    var tokenHandler = new JwtSecurityTokenHandler();
                    var key = Encoding.UTF8.GetBytes(_configuration.GetValue<string>("AppSettings:Secret"));

                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new ClaimsIdentity(new[] { new Claim("corporate", corporate), new Claim("Roles", roles), new Claim("Country", countryId.ToString()) }),
                        Expires = DateTime.UtcNow.AddMinutes(_configuration.GetValue<int>("AppSettings:TokenTime")),
                        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                    };

                    var token = tokenHandler.CreateToken(tokenDescriptor);

                    return tokenHandler.WriteToken(token);
                }
            }
            catch
            {
                return "Ha ocurrido un error";
            }
        }

        //Logout
        public string Logout(string corporate)
        {
            var existsUser = _dbContext.Users.FirstOrDefault(u => u.Corporate == corporate);

            if (existsUser == null) return "No exist user";

            try
            {
                Log log = new()
                {
                    Corporate = corporate,
                    LaId = 2
                };

                _dbContext.Logs.Add(log);
                _dbContext.SaveChanges();
            }
            catch { return "Error"; }

            return "Success";
        }
    }
}
