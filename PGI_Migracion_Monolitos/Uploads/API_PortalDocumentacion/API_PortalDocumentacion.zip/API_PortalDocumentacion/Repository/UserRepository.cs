﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Repository.IRepository;
using API_PortalDocumentacion.Security;
using API_PortalDocumentacion.Tools;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;

namespace API_PortalDocumentacion.Repository
{
    public class UserRepository : IUserRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;
        public IConfiguration _configuration;
        public EmailSender emailSender = new();
        public GenerateRandomPassword genRandomPws = new();

        public UserRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration)
        {
            this._dbContext = dbContext;
            this._configuration = configuration;
        }

        //Function DeleteUser, receives a model (User) and deletes it from the database
        public bool DeleteUser(User user)
        {
            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                _dbContext.Users.Remove(user);
                transaction.Commit();
                return Save();
            }
        }

        //Function to save de information
        public bool Save()
        {
            return _dbContext.SaveChanges() >= 0 ? true : false;
        }

        //Function to update password user's
        public string UpdatePassword(UpdatePasswordLUDTO updateUserDTO)
        {
            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                User? user = _dbContext.Users.FirstOrDefault(c => c.Corporate == updateUserDTO.Username);

                transaction.Commit();

                if (user == null) { return "No exist user"; }

                try
                {
                    byte[] salt = new byte[16];
                    using (var rng = new RNGCryptoServiceProvider())
                    {
                        rng.GetBytes(salt);
                    }

                    using (var pbkdf2 = new Rfc2898DeriveBytes(updateUserDTO.Password, salt, 100000, HashAlgorithmName.SHA256))
                    {
                        byte[] hash = pbkdf2.GetBytes(32);

                        // Convert to Base64
                        string saltBase64 = Convert.ToBase64String(salt);
                        string hashBase64 = Convert.ToBase64String(hash);

                        user.Passwordhash = hashBase64;
                        user.Salt = saltBase64;

                        _dbContext.SaveChanges();

                        UpdateStateFirstSession(updateUserDTO.Username, false);

                        return "Successfully created";
                    }
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
            }
        }

        //Function to confirm if a user exist
        public bool UserExist(string username)
        {
            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var value = _dbContext.Users.Any(c => c.Corporate == username);
                transaction.Commit();
                return value;
            }
        }

        //Function to confirm if the user is unique
        public bool IsUniqueUser(string corporate)
        {
            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var user = _dbContext.Users.FirstOrDefault(u => u.Corporate == corporate);

                transaction.Commit();

                if (user == null)
                    return true;

                return false;
            }
        }

        //Function to update state
        public bool UpdateStateFirstSession(string corporate,bool state)
        {
            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var IsSuccess = false;
                var response = _dbContext.Users.FirstOrDefault(x => x.Corporate == corporate);

                transaction.Commit();

                if (response != null)
                {
                    response.FirstSession = state;
                    _dbContext.SaveChanges();
                    IsSuccess = true;
                }

                return IsSuccess;
            }
        }

        //API restore password, receives a string (corporate) and sends an email with a temporary password to the user's email.
        public string? RestorePassword(string username)
        {
            string passRandom, bodyMessage;
            User? user = new();
            string projectPath = AppContext.BaseDirectory;
            string fullPath = Path.Combine(projectPath, "Content", "TemplatesHTML", "PlantillaRESTABLECERCONTRASENA.html");

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {

                user = _dbContext.Users.FirstOrDefault(u => u.Corporate == username && u.Active == true);

                transaction.Commit();

                if (user == null) return "No exist user";

                //Usuario LDAP no puede reiniciar contraseña
                if (user.Passwordhash == null || user.Salt == null) return null;
                

                passRandom = genRandomPws.GetRandomPassword();
                bodyMessage = File.ReadAllText(fullPath);
                bodyMessage = bodyMessage.Replace("[DOMAIN]", _configuration.GetValue<string>("Domain:URL"))
                                         .Replace("[PASSWORD]", passRandom);
                try
                {
                    byte[] salt = new byte[16];
                    using (var rng = new RNGCryptoServiceProvider())
                    {
                        rng.GetBytes(salt);
                    }

                    using (var pbkdf2 = new Rfc2898DeriveBytes(passRandom, salt, 100000, HashAlgorithmName.SHA256))
                    {
                        byte[] hash = pbkdf2.GetBytes(32);

                        // Convert to Base64
                        string saltBase64 = Convert.ToBase64String(salt);
                        string hashBase64 = Convert.ToBase64String(hash);

                        user.Passwordhash = hashBase64;
                        user.Salt = saltBase64;

                        _dbContext.SaveChanges();
                    }
                }
                catch (Exception ex) { return ex.Message; }

                emailSender.EmailSend(user.Email, "RESTABLECIMIENTO DE CONTRASEÑA, PORTAL DE DOCUMENTACIÓN TI", bodyMessage, _configuration);
                UpdateStateFirstSession(username, true);

                return "Successfully restored";
            }
        }
    }
}
