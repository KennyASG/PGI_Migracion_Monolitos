﻿using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using API_PortalDocumentacion.Models.Portal;
using DocumentFormat.OpenXml.Wordprocessing;
using XAct.Library.Settings;
using API_PortalDocumentacion.Tools;
namespace API_PortalDocumentacion.Repository
{
    public class NotificationRepository : INotificationRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;
        public IConfiguration _configuration;
        public NotificationSender _notifSender;

        //Class constructor
        public NotificationRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration, NotificationSender notifSender)
        {
            this._dbContext = dbContext;
            this._configuration = configuration;
            this._notifSender = notifSender;
        }

        public async Task<List<Notification>> GetAllAdminNotifications(string corporate)
        {
            if (!(await IsAdminValidation(corporate))) return null;

            try
            {
                //Obtiene todas las notificaciones dirigidas a los Admin
                List<Notification> notifications = await _dbContext.Notifications
                    .Where(n => n.DestinationType == 1)
                    .OrderByDescending(n => n.CreationDate)
                    .ToListAsync();
                return notifications;
            }
            catch
            {
                return null;
            }
        }

        public async Task<List<Notification>> GetAllDocuNotifications(string corporate)
        {
            if (corporate == "") return null;
            

            try
            {
                //Obtiene todas las notificaciones creadas y dirigidas al documentador
                List<Notification> notifications = await _dbContext.Notifications
                    .Where(n => (n.ReceiverCorporate == corporate
                        && n.DestinationType == 3))
                    .OrderByDescending(n => n.CreationDate)
                    .ToListAsync();
                return notifications;
            }
            catch
            {
                return null;
            }
        }

        public async Task<List<DetailedNotificationModel>> GetDetailedAdminNotifByType(GetAdminNotificationModel adminNotifModel)
        {
            if(adminNotifModel.NotificationStatus == 0 || !(await IsAdminValidation(adminNotifModel.Corporate))) return null;
            
            try
            {
                var detailedNotifications =
                    from n in _dbContext.Notifications
                    join d in _dbContext.Diagrams on n.DiagramId equals d.DiagramId
                    join m in _dbContext.Modules on d.ModuleId equals m.ModuleId
                    join p in _dbContext.Projects on m.ProjectId equals p.ProjectId
                    join c in _dbContext.Countries on p.CountryId equals c.Id
                    join o in _dbContext.Options on d.OptionId equals o.OptionId into optionGroup
                    from o in optionGroup.DefaultIfEmpty()
                    join u in _dbContext.Users on n.SenderCorporate equals u.Corporate into userGroup
                    from u in userGroup.DefaultIfEmpty()
                    where n.Active == true && n.DestinationType == 1
                    && n.NotificationStatus == adminNotifModel.NotificationStatus
                    orderby n.CreationDate descending
                    select new DetailedNotificationModel
                    {
                        NotificationId = n.NotificationId,
                        SenderCorporate = n.SenderCorporate,
                        SenderName = u.Names + " " + u.Surnames,
                        CreationDate = n.CreationDate,
                        IsUnread = n.IsUnread,
                        Title = n.Title,
                        Body = n.Body,
                        Comment = n.Comment,
                        DiagramId = n.DiagramId,
                        ProjectName = p.Project1,
                        ModuleName = m.ModuleName,
                        OptionName = o.OptionName,
                        DiagramName = d.Diagram1,
                        FilePath = d.FilePath,
                        NotificationStatus = n.NotificationStatus,
                        WasSent = n.WasSent,
                        CountryId = p.CountryId,
                        CountryCode = c.CountryCode,
                        CountryName = c.CountryName
                    };
                return await detailedNotifications.ToListAsync();
            }
            catch
            {
                return null;
            }
        }

        public async Task<List<DetailedNotificationModel>> GetDetailedDocuNotifByType(GetDocumenterNotificationModel docNotifModel)
        {
            if(docNotifModel.Corporate == "" || docNotifModel.NotificationStatus == 0) return null;
            

            try
            {
                var detailedNotifications =
                    from n in _dbContext.Notifications
                    join d in _dbContext.Diagrams on n.DiagramId equals d.DiagramId
                    join m in _dbContext.Modules on d.ModuleId equals m.ModuleId
                    join p in _dbContext.Projects on m.ProjectId equals p.ProjectId
                    join c in _dbContext.Countries on p.CountryId equals c.Id
                    join o in _dbContext.Options on d.OptionId equals o.OptionId into optionGroup
                    from o in optionGroup.DefaultIfEmpty()
                    join u in _dbContext.Users on n.SenderCorporate equals u.Corporate into userGroup
                    from u in userGroup.DefaultIfEmpty()
                    where n.Active == true && n.DestinationType == 3
                    && n.NotificationStatus == docNotifModel.NotificationStatus
                    && n.ReceiverCorporate == docNotifModel.Corporate
                    orderby n.CreationDate descending
                    select new DetailedNotificationModel
                    {
                        NotificationId = n.NotificationId,
                        SenderCorporate = n.SenderCorporate,
                        SenderName = u.Names + " " + u.Surnames,
                        CreationDate = n.CreationDate,
                        IsUnread = n.IsUnread,
                        Title = n.Title,
                        Body = n.Body,
                        Comment = n.Comment,
                        DiagramId = n.DiagramId,
                        ProjectName = p.Project1,
                        ModuleName = m.ModuleName,
                        OptionName = o.OptionName,
                        DiagramName = d.Diagram1,
                        FilePath = d.FilePath,
                        NotificationStatus = n.NotificationStatus,
                        RelatedNotificationDate = n.RelatedNotificationDate,
                        WasSent = n.WasSent,
                        CountryId = p.CountryId,
                        CountryCode = c.CountryCode,
                        CountryName = c.CountryName
                    };
                return await detailedNotifications.ToListAsync();
            }
            catch
            {
                return null;
            }
        }

        public string MarkNotification(MarkNotificationModel MarkedNotifModel)
        {
            if (MarkedNotifModel.NotificationId == 0) return null;

            try
            {
                var notification = _dbContext.Notifications.FirstOrDefault(n => n.NotificationId == MarkedNotifModel.NotificationId);
                if (notification != null)
                {
                    notification.IsUnread = MarkedNotifModel.IsUnread;
                    _dbContext.SaveChanges();
                }
                return "Notificación actualizada con éxito";
            }
            catch
            {
                return null;
            }
        }

        public async Task<string> ApproveDiagram(ChangeNotificationStatusModel approveDiagramModel)
        {
            if (approveDiagramModel.NotificationId == 0 || !(await IsAdminValidation(approveDiagramModel.ActionUser))) return null;
            
            try
            {
                var notification = _dbContext.Notifications.FirstOrDefault(n => n.NotificationId == approveDiagramModel.NotificationId);
                var user = _dbContext.Users.FirstOrDefault(u => u.Corporate == approveDiagramModel.ActionUser);
                string fullname = user.Names + " " + user.Surnames;

                if (notification != null)
                {
                    var diagram = _dbContext.Diagrams.FirstOrDefault(d => d.DiagramId == notification.DiagramId);
                    string tempPath = $@"{_configuration.GetValue<string>("AppSettings:PathTemp")}{diagram.FilePath}";
                    string prodPath = $@"{_configuration.GetValue<string>("AppSettings:PathPrincipal")}{diagram.FilePath}";
                    //Verificar existencia del path
                    if (!Directory.Exists(Path.GetDirectoryName(prodPath))) Directory.CreateDirectory(Path.GetDirectoryName(prodPath));
                    //Mover el archivo de la carpeta temporal a la carpeta de diagramas
                    var extensions = _dbContext.FileExtensions.ToList();
                    foreach (var extension in extensions)
                    {
                        string tempFile = $@"{tempPath}{extension.Extension}";
                        string prodFile = $@"{prodPath}{extension.Extension}";
                        if (File.Exists(tempFile))//Copiar y reemplazar, como en analystRepository
                        {
                            // Validar si se debe borrar si ya existe o no
                            if (File.Exists(prodFile)) File.Delete(prodFile); 
                            File.Copy(tempFile, prodFile);
                        }
                    }
                    //Pasar estado del proyecto a SP_ID = 4
                    diagram.SpId = 4;
                    //Verificar los padres del diagrama: opción, módulo, proyecto, si no están en estado 4, pasarlos a estado 4
                    var option = _dbContext.Options.FirstOrDefault(o => o.OptionId == diagram.OptionId);
                    if (option != null)
                    {
                        if (option.SpId != 4) option.SpId = 4;
                    }
                    //Module y project no pueden ser null
                    var module = _dbContext.Modules.FirstOrDefault(m => m.ModuleId == diagram.ModuleId);
                    if(module.SpId!=4) module.SpId = 4;
                    var project = _dbContext.Projects.FirstOrDefault(p => p.ProjectId == module.ProjectId);
                    if (project.SpId != 4) project.SpId = 4;

                    //Crear notificación hacía el documentador
                    notification.NotificationStatus = 2;
                    notification.Title = $"Solicitud aprobada por: {approveDiagramModel.ActionUser} - {fullname}";
                    _dbContext.SaveChanges();

                    Notification notificationData = new()
                    {
                        SenderCorporate = approveDiagramModel.ActionUser,
                        ReceiverCorporate = notification.SenderCorporate,
                        DestinationType = 3,
                        CreationDate = DateTime.Now,
                        IsUnread = true,
                        DiagramId = notification.DiagramId,
                        NotificationStatus = 2,
                        Active = true,
                        RelatedNotificationDate = notification.CreationDate
                    };

                    if(_notifSender.CreateNotification(notificationData) == "ERROR") return null;
                    
                }
                return "Notificación actualizada con éxito";
            }
            catch
            {
                return null;
            }
        }

        public async Task<string> RejectDiagram(ChangeNotificationStatusModel rejectDiagramModel)
        {
            if (rejectDiagramModel.NotificationId == 0 || rejectDiagramModel.Comment == null || !(await IsAdminValidation(rejectDiagramModel.ActionUser))) return null;

            try
            {
                var notification = _dbContext.Notifications.FirstOrDefault(n => n.NotificationId == rejectDiagramModel.NotificationId);
                var user = _dbContext.Users.FirstOrDefault(u => u.Corporate == rejectDiagramModel.ActionUser);
                string fullname = user.Names + " " + user.Surnames;

                if (notification != null)
                {
                    notification.NotificationStatus = 3;
                    notification.Title = $"Solicitud rechazada por: {rejectDiagramModel.ActionUser} - {fullname}";
                    notification.Comment = rejectDiagramModel.Comment;
                    _dbContext.SaveChanges();

                    //Crear notificación hacía el documentador
                    Notification notificationData = new()
                    {
                        SenderCorporate = rejectDiagramModel.ActionUser,
                        ReceiverCorporate = notification.SenderCorporate,
                        DestinationType = 3,
                        CreationDate = DateTime.Now,
                        IsUnread = true,
                        Comment = rejectDiagramModel.Comment,
                        DiagramId = notification.DiagramId,
                        NotificationStatus = 3,
                        Active = true,
                        RelatedNotificationDate = notification.CreationDate
                    };
                    if (_notifSender.CreateNotification(notificationData) == "ERROR") return null;
                    
                }
                return "Notificación actualizada con éxito";
            }
            catch
            {
                return null;
            }
        }

        public async Task<bool> IsAdminValidation(string corporate)
        {
            try
            {
                //Verificar los permisos del usuario
                var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Corporate == corporate && u.Active == true);
                if (user == null) return false;
                

                //user_role
                var userRole = _dbContext.UserRoles.Where(ur => ur.Corporate == corporate && ur.Active == true);
                bool isAdmin = false;
                foreach (var role in userRole)
                {
                    if (role.RoleId == 2)
                    {
                        isAdmin = true;
                        break;
                    }
                }
                return isAdmin;
            }
            catch
            {
                return false;
            }
        }

        public string MarkAsSent(int notificationId)
        {
            if (notificationId == 0) return null;

            try
            {
                var notification = _dbContext.Notifications.FirstOrDefault(n => n.NotificationId == notificationId);
                if (notification != null)
                {
                    notification.WasSent = true;
                    _dbContext.SaveChanges();
                }
                return "Notificación actualizada con éxito";
            }
            catch
            {
                return null;
            }
        }
    }
}
