﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;


namespace API_PortalDocumentacion.Repository
{
    public class MenuRepository : IMenuRepository
    {
        public DbPortalDocumentacionContext _dbContext;
        public MenuRepository(DbPortalDocumentacionContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<MenuItem> GetListItems(string corporate)
        {
            var parametroCorporate = new SqlParameter("@Corporate", corporate);
            var query = $"EXEC GetMenuItemsbyCorporate @Corporate";
            List<MenuItem> menuItems = _dbContext.Set<MenuItem>().FromSqlRaw(query, parametroCorporate).ToList();

            return menuItems;
        }

        public List<MenuItem> BuildMenuTree(List<MenuItem> menuItems)
        {
            var menuMap = new Dictionary<int, MenuItem>();
            var rootItems = new List<MenuItem>();

            // Map all items by their ID
            foreach (var item in menuItems)
            {
                menuMap[item.Id] = item;
            }

            // Build the tree structure
            foreach (var item in menuItems)
            {
                if (item.ParentId == null)
                {
                    rootItems.Add(item);
                }
                else
                {
                    if (menuMap.TryGetValue(item.ParentId.Value, out var parentMenuItem))
                    {
                        parentMenuItem.Children.Add(item);
                    }
                }
            }

            return rootItems;
        }

        public List<DocumenterMenuItem> BuildMenuTree(List<DocumenterMenuItem> documenterMenuItems)
        {
            var PMODMap = new Dictionary<int, DocumenterMenuItem>();
            var rootItems = new List<DocumenterMenuItem>();

            // Map all items by their ID
            foreach (var item in documenterMenuItems)
            {
                PMODMap[item.Id] = item;
            }

            // Build the tree structure
            foreach (var item in documenterMenuItems)
            {
                if (item.ParentId == null)
                {
                    rootItems.Add(item);
                }
                else
                {
                    if (PMODMap.TryGetValue(item.ParentId.Value, out var parentPMODItem))
                    {
                        parentPMODItem.Children.Add(item);
                    }
                }
            }

            return rootItems;
        }

        public List<DocumenterMenuItem> GetDocumenterMenuItems(string corporate)
        {
            var query = $"EXEC GetAssignedProModOptDiagByCorporate {corporate}";
            List<DocumenterMenuItem> listPMOD = _dbContext.Set<DocumenterMenuItem>().FromSqlRaw(query).ToList();

            var structuredDocumenterMenuItems = BuildMenuTree(listPMOD);

            return structuredDocumenterMenuItems;
        }

        public async Task<NotificationAndRequestCountModel> GetNotificationAndRequestCount(GetNotifAndRequestCountModel details)
        {
            if(details.NotificationType == NotificationType.None
                && details.NotificationStatus == NotificationStatus.None
                && details.RequestStatus == RequestStatus.None
                && details.ProjectCountStatus == ProjectCountStatus.None
                && details.UserCountStatus == UserCountStatus.None) return null;
            
            //Notificaciones
            int totalNotifications = 0;
            int pendingNotifications = 0;
            int acceptedNotifications = 0;
            int rejectedNotifications = 0;
            int allPendingNotifications = 0;//Unread & Read

            //Solicitudes de acceso
            int totalRequests = 0;
            int pendingRequests = 0;
            int acceptededRequests = 0;
            int rejectedRequests = 0;

            //Proyectos
            int totalProjects = 0;

            //Usuarios
            int totalUsers = 0;

            //Validar rol
            bool IsAdmin = await IsAdminValidation(details.Corporate);

            if (details.NotificationType != NotificationType.None && details.NotificationStatus != NotificationStatus.None) {
                try
                {
                    //Rol Documentador por defecto
                    int type = 3;

                    //Validar rol
                    if (details.NotificationType == NotificationType.Admin)
                    {
                        if (!IsAdmin) return null;
                        else type = 1;
                    }

                    //Obtener cantidades de notificaciones
                    List<Notification>? notificacions;
                    if (type == 1)
                    {
                        notificacions = await _dbContext.Notifications.Where(n => n.DestinationType == type && n.IsUnread == true && n.Active == true).ToListAsync();
                        allPendingNotifications = await _dbContext.Notifications.Where(n => n.DestinationType == type && n.Active == true && n.NotificationStatus == 1).CountAsync();
                    }
                    else
                        notificacions = await _dbContext.Notifications
                            .Where(n => n.DestinationType == type && n.IsUnread == true && n.ReceiverCorporate == details.Corporate && n.Active == true)
                            .ToListAsync();
                    
                    totalNotifications = (details.NotificationStatus == NotificationStatus.All) 
                        ? notificacions.Count : 0;

                    pendingNotifications = (details.NotificationStatus == NotificationStatus.All || details.NotificationStatus == NotificationStatus.Pending) && type == 1
                        ? notificacions.Where(n => n.NotificationStatus == 1).Count()
                        : 0;

                    acceptedNotifications = (details.NotificationStatus == NotificationStatus.All || details.NotificationStatus == NotificationStatus.Accepted) 
                        ? notificacions.Where(n => n.NotificationStatus == 2).Count()
                        : 0;

                    rejectedNotifications = (details.NotificationStatus == NotificationStatus.All || details.NotificationStatus == NotificationStatus.Rejected)
                        ? notificacions.Where(n => n.NotificationStatus == 3).Count()
                        : 0;
                }
                catch
                {
                    return null;
                }
            }

            if(details.RequestStatus != RequestStatus.None && IsAdmin)
            {
                try
                {
                    List<SystemRequest>? systemRequests;
                    systemRequests = await _dbContext.SystemRequests.Where(sr => sr.Active == true).ToListAsync();

                    totalRequests = details.RequestStatus == RequestStatus.All 
                        ? systemRequests.Count 
                        : 0;
                    pendingRequests = details.RequestStatus == RequestStatus.Pending || details.RequestStatus == RequestStatus.All 
                        ? systemRequests.Where(sr => sr.Authorized == null).Count()
                        : 0;
                    acceptededRequests = details.RequestStatus == RequestStatus.Accepted || details.RequestStatus == RequestStatus.All
                        ? systemRequests.Where(sr => sr.Authorized == true).Count()
                        :0 ;
                    rejectedRequests = details.RequestStatus == RequestStatus.Rejected || details.RequestStatus == RequestStatus.All
                        ? systemRequests.Where(sr => sr.Authorized == false).Count()
                        :0 ;
                }
                catch
                {
                    return null;
                }
            }

            if (details.UserCountStatus != UserCountStatus.None && IsAdmin) {
                try
                {
                    List<User>? userList = await _dbContext.Users
                        .Where(u =>
                            u.Active == true &&
                            u.Corporate != null &&
                            u.Names != null &&
                            u.Surnames != null &&
                            u.Department != null &&
                            _dbContext.UserRoles.Any(ur => ur.Corporate == u.Corporate && ur.Active == true)
                        )
                        .ToListAsync();
                    totalUsers = details.UserCountStatus == UserCountStatus.All
                        ? userList.Count
                        : 0;
                }
                catch
                {
                    return null;
                }
            }

            if (details.ProjectCountStatus != ProjectCountStatus.None && IsAdmin)
            {
                try
                {
                    List<Project>? projectList = await _dbContext.Projects.Where(p => p.Active == true).ToListAsync();
                    totalProjects = details.ProjectCountStatus == ProjectCountStatus.All
                        ? projectList.Count
                        : 0;
                }
                catch
                {
                    return null;
                }
            }

            var notifications = new NotificationCount
            {
                Total = totalNotifications,
                Pending = pendingNotifications,
                Accepted = acceptedNotifications,
                Rejected = rejectedNotifications,
                AllPending = allPendingNotifications
            };

            var requests = new RequestCount
            {
                Total = totalRequests,
                Pending = pendingRequests,
                Accepted = acceptededRequests,
                Rejected = rejectedRequests
            };

            var projects = new ProjectCount
            {
                Total = totalProjects
            };

            var users = new UserCount
            {
                Total = totalUsers
            };

            return new NotificationAndRequestCountModel { 
                NotificationCount = notifications,
                RequestCount = requests,
                ProjectCount = projects,
                UserCount = users
            };
        }

        public async Task<bool> IsAdminValidation(string corporate)
        {
            try
            {
                //Verificar los permisos del usuario
                var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Corporate == corporate && u.Active == true);
                if (user == null) return false;


                //user_role
                var userRole = _dbContext.UserRoles.Where(ur => ur.Corporate == corporate && ur.Active == true);
                bool isAdmin = false;
                foreach (var role in userRole)
                {
                    if (role.RoleId == 2)
                    {
                        isAdmin = true;
                        break;
                    }
                }
                return isAdmin;
            }
            catch
            {
                return false;
            }
        }
    }
}
