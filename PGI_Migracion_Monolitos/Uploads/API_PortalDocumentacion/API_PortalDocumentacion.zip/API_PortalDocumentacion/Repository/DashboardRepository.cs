#pragma warning disable IDE0028
#pragma warning disable IDE0290
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using XAct;

namespace API_PortalDocumentacion.Repository
{
    public class DashboardRepository : IDashboardRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;

        //Class constructor
        public DashboardRepository(DbPortalDocumentacionContext dbContext)
        {
            _dbContext = dbContext;
        }

        //Function to return the most used system by project.
        public List<MostUsedElementbyProject> MostUsedElembyProj(int projectId)
        {
            List<MostUsedElementbyProject> ListMostUsedElem = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {

                var query = (from e in _dbContext.Elements
                             join d in _dbContext.Details on e.ElementId equals d.ElementId
                             join di in _dbContext.Diagrams on d.DiagramId equals di.DiagramId
                             join et in _dbContext.ElementTypes on e.ElementTypeId equals et.ElementTypeId
                             join m in _dbContext.Modules on di.ModuleId equals m.ModuleId
                             join s in _dbContext.Systems on d.SystemId equals s.SystemId
                             where m.ProjectId == projectId && e.Active == true && d.Active == true
                             group d by new { e.Element1, et.ElementType1, s.System1 } into g
                             orderby g.Sum(x => x.Repetition) descending
                             select new
                             {
                                 Element = g.Key.Element1,
                                 ElementType = g.Key.ElementType1,
                                 System = g.Key.System1,
                                 Repetition = g.Sum(x => x.Repetition)
                             })
                .Take(15)
                .ToList();

                transaction.Commit();

                if (query == null || query.Count == 0) return null;

                foreach (var elem in query)
                {

                    MostUsedElementbyProject MostUsedElem = new()
                    {
                        Element = elem.Element,
                        ElementType = elem.ElementType,
                        System = elem.System,
                        Repetition = elem.Repetition,
                    };

                    ListMostUsedElem.Add(MostUsedElem);
                }

                return ListMostUsedElem;
            }
        }

        public List<ElementTypebyProject> ElemTbyProj(int projectId)
        {
            List<ElementTypebyProject> ListElementTypebyProject = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var innerQuery = from e in _dbContext.Elements
                                 join d in _dbContext.Details on e.ElementId equals d.ElementId
                                 join di in _dbContext.Diagrams on d.DiagramId equals di.DiagramId
                                 join et in _dbContext.ElementTypes on e.ElementTypeId equals et.ElementTypeId
                                 join m in _dbContext.Modules on di.ModuleId equals m.ModuleId
                                 join s in _dbContext.Systems on d.SystemId equals s.SystemId
                                 where m.ProjectId == projectId && e.Active == true && d.Active == true
                                 group e by new { et.ElementTypeId, et.ElementType1, s.System1 } into g
                                 select new
                                 {
                                     ElementTypeId = g.Key.ElementTypeId,
                                     ElementType = g.Key.ElementType1,
                                     Repeticion = g.Select(x => x.ElementId).Distinct().Count() // Count distinct elements
                                 };

                var result = from temp in innerQuery
                             group temp by new { temp.ElementTypeId, temp.ElementType } into grouped
                             select new
                             {
                                 ElementTypeId = grouped.Key.ElementTypeId,
                                 ElementType = grouped.Key.ElementType,
                                 SumRepeticion = grouped.Sum(x => x.Repeticion)
                             }
                             into final
                             orderby final.SumRepeticion descending
                             select final;

                var query = result.ToList();


                transaction.Commit();

                if (query == null || query.Count == 0) return null;

                foreach (var elem in query)
                {
                    ElementTypebyProject elementTypebyProject = new()
                    {
                        ElementTypeId = elem.ElementTypeId,
                        ElementType = elem.ElementType,
                        Repetition = elem.SumRepeticion
                    };

                    ListElementTypebyProject.Add(elementTypebyProject);
                }

                return ListElementTypebyProject;
            }
        }

        public List<ElementsbyElementTypeAndProject> ElembyElemTAndProj(int projectId, int elementTypeId)
        {
            List<ElementsbyElementTypeAndProject> ListElementsbyETAndProj = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var query = (from e in _dbContext.Elements
                             join d in _dbContext.Details on e.ElementId equals d.ElementId
                             join di in _dbContext.Diagrams on d.DiagramId equals di.DiagramId
                             join et in _dbContext.ElementTypes on e.ElementTypeId equals et.ElementTypeId
                             join m in _dbContext.Modules on di.ModuleId equals m.ModuleId
                             join s in _dbContext.Systems on d.SystemId equals s.SystemId
                             where m.ProjectId == projectId && et.ElementTypeId == elementTypeId && e.Active == true && d.Active == true
                             group d by new { e.Element1, et.ElementType1, s.System1 } into grouped

                             select new
                             {
                                 Element = grouped.Key.Element1,
                                 ElementType = grouped.Key.ElementType1,
                                 System = grouped.Key.System1,
                                 Repetition = grouped.Sum(x => x.Repetition)
                             })
                             .OrderByDescending(x => x.Repetition)
                             .ToList();

                transaction.Commit();

                if (query == null || query.Count == 0) return null;

                foreach (var elem in query)
                {

                    ElementsbyElementTypeAndProject elementsbyETAndProj = new()
                    {
                        Element = elem.Element,
                        ElementType = elem.ElementType,
                        System = elem.System,
                        Repetition = elem.Repetition
                    };

                    ListElementsbyETAndProj.Add(elementsbyETAndProj);
                }

                return ListElementsbyETAndProj;
            }
        }

        public List<MostUsedElementbyProjectAndModule> MostUsedElembyProjAndMod(int projectId, int moduleId)
        {
            List<MostUsedElementbyProjectAndModule> ListMostUsedElembyProjAndMod = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var query = (from e in _dbContext.Elements
                             join d in _dbContext.Details on e.ElementId equals d.ElementId
                             join di in _dbContext.Diagrams on d.DiagramId equals di.DiagramId
                             join et in _dbContext.ElementTypes on e.ElementTypeId equals et.ElementTypeId
                             join m in _dbContext.Modules on di.ModuleId equals m.ModuleId
                             join s in _dbContext.Systems on d.SystemId equals s.SystemId
                             where m.ProjectId == projectId && m.ModuleId == moduleId && e.Active == true && d.Active == true
                             group new { e, et, s, d } by new { e.Element1, et.ElementType1, s.System1 } into grouped
                             orderby grouped.Sum(x => x.d.Repetition) descending
                             select new
                             {
                                 Element = grouped.Key.Element1,
                                 ElementType = grouped.Key.ElementType1,
                                 System = grouped.Key.System1,
                                 Repetition = grouped.Sum(x => x.d.Repetition)
                             }).Take(15).ToList();

                transaction.Commit();

                if (query == null || query.Count == 0) return null;

                foreach (var elem in query)
                {
                    MostUsedElementbyProjectAndModule mostUsedElembyProjAndMod = new()
                    {
                        Element = elem.Element,
                        ElementType = elem.ElementType,
                        System = elem.System,
                        Repetition = elem.Repetition
                    };

                    ListMostUsedElembyProjAndMod.Add(mostUsedElembyProjAndMod);
                }

                return ListMostUsedElembyProjAndMod;
            }
        }

        public List<ElementTypebyProjectAndModule> ElemTbyProjAndMod(int projectId, int moduleId)
        {
            List<ElementTypebyProjectAndModule> ListETbyProjAndMod = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var innerQuery = from e in _dbContext.Elements
                                 join d in _dbContext.Details on e.ElementId equals d.ElementId
                                 join di in _dbContext.Diagrams on d.DiagramId equals di.DiagramId
                                 join et in _dbContext.ElementTypes on e.ElementTypeId equals et.ElementTypeId
                                 join m in _dbContext.Modules on di.ModuleId equals m.ModuleId
                                 join s in _dbContext.Systems on d.SystemId equals s.SystemId
                                 where m.ProjectId == projectId && m.ModuleId == moduleId && e.Active == true && d.Active == true
                                 group e by new { et.ElementTypeId, et.ElementType1, s.System1 } into g
                                 select new
                                 {
                                     ElementTypeId = g.Key.ElementTypeId,
                                     ElementType = g.Key.ElementType1,
                                     Repeticion = g.Select(x => x.ElementId).Distinct().Count() // Count distinct elements
                                 };

                var result = from temp in innerQuery
                             group temp by new { temp.ElementTypeId, temp.ElementType } into grouped
                             select new
                             {
                                 ElementTypeId = grouped.Key.ElementTypeId,
                                 ElementType = grouped.Key.ElementType,
                                 SumRepeticion = grouped.Sum(x => x.Repeticion)
                             }
                             into final
                             orderby final.SumRepeticion descending
                             select final;
                var query = result.ToList();
                transaction.Commit();

                if (query == null || query.Count == 0) return null;

                foreach (var elem in query)
                {
                    ElementTypebyProjectAndModule elemTypebyProjAndMod = new()
                    {
                        ElementTypeId = elem.ElementTypeId,
                        ElementType = elem.ElementType,
                        Repetition = elem.SumRepeticion
                    };

                    ListETbyProjAndMod.Add(elemTypebyProjAndMod);
                }

                return ListETbyProjAndMod;
            }
        }

        public List<ElementsbyElementTypeProjectAndModule> ElembyElemTProjAndMod(int projectId, int elementTypeId, int moduleId)
        {
            List<ElementsbyElementTypeProjectAndModule> ListElementsbyETProjAndMod = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var query = (from e in _dbContext.Elements
                             join d in _dbContext.Details on e.ElementId equals d.ElementId
                             join di in _dbContext.Diagrams on d.DiagramId equals di.DiagramId
                             join et in _dbContext.ElementTypes on e.ElementTypeId equals et.ElementTypeId
                             join m in _dbContext.Modules on di.ModuleId equals m.ModuleId
                             join s in _dbContext.Systems on d.SystemId equals s.SystemId
                             where m.ProjectId == projectId && et.ElementTypeId == elementTypeId && m.ModuleId == moduleId && e.Active == true && d.Active == true
                             group new { e, et, s, d } by new { e.Element1, et.ElementType1, s.System1 } into grouped
                             orderby grouped.Sum(x => x.d.Repetition) descending
                             select new
                             {
                                 Element = grouped.Key.Element1,
                                 ElementType = grouped.Key.ElementType1,
                                 System = grouped.Key.System1,
                                 Repetition = grouped.Sum(x => x.d.Repetition)
                             }).ToList();

                transaction.Commit();

                if (query == null || query.Count == 0) return null;

                foreach (var elem in query)
                {
                    ElementsbyElementTypeProjectAndModule elementsbyETProjAndMod = new()
                    {
                        Element = elem.Element,
                        ElementType = elem.ElementType,
                        System = elem.System,
                        Repetition = elem.Repetition
                    };

                    ListElementsbyETProjAndMod.Add(elementsbyETProjAndMod);
                }

                return ListElementsbyETProjAndMod;
            }
        }

        public List<ElementsOrion> GetElementOrionByProject(int ProjectId)
        {
            var parameter = new SqlParameter("@ProjectId", ProjectId);
            var query = $"EXEC GetElemetsOrionByPro @ProjectId";
            List<ElementsOrion> ElemOrion = _dbContext.Set<ElementsOrion>().FromSqlRaw(query, parameter).ToList();

            return ElemOrion;
        }

        public List<ElementsOrion> GetElementOrionByProAndMod(int ProjectId, int ModuleId)
        {
            var parameterPro = new SqlParameter("@ProjectId", ProjectId);
            var parameterMod = new SqlParameter("@ModuleId", ModuleId);
            var query = $"EXEC GetElemetsOrionByProAndMod @ProjectId, @ModuleId";
            List<ElementsOrion> ElemOrion = _dbContext.Set<ElementsOrion>().FromSqlRaw(query, parameterPro, parameterMod).ToList();

            return ElemOrion;
        }

        public GetProjectProgressWithModulesModel GetProjectProgressWithModules(int ProjectId)
        {
            try
            {
                var query = $"EXEC GetProjectProgressWithModules {ProjectId}";
                List<GetAllProjectDiagrams> projectProgress = _dbContext.Set<GetAllProjectDiagrams>()
                    .FromSqlRaw(query)
                    .AsEnumerable()
                    .ToList();
                //Primero, debemos obtener los c�lculos para el proyecto
                GetProjectProgressWithModulesModel stats = new();
                //Obtener la cantidad de diagramas en el proyecto
                stats.TotalDiagramsInProject = projectProgress.Count;
                //Obtener el total de puntos posibles
                stats.TotalPossiblePoints = stats.TotalDiagramsInProject * 100;
                //Sumar toda la columna Percentage de la lista de diagramas
                stats.PointsByMatrix = projectProgress
                    .Sum(x => (x.Percentage ?? 0));
                //Contar todos los diagramas que tienen 100 puntos
                stats.CompletedDiagrams = projectProgress.Count(x => x.Percentage >= 100);
                //Diagramas con SP_ID = 4 no suman
                stats.PointsByCompletedDiagrams = 0;
                //Obtener el total de puntos actuales
                stats.CurrentPoints = stats.PointsByMatrix;
                //Obtener el porcentaje de avance actual
                if (stats.TotalPossiblePoints == 0)
                {
                    stats.CurrentPercentage = 0;
                }
                else
                {
                    stats.CurrentPercentage = ((decimal)stats.CurrentPoints / (decimal)stats.TotalPossiblePoints) * 100;
                }

                //Ahora, agrupar por modulos, y repetir el c�lculo de los proyectos, pero a nivel de m�dulo
                var groupedByModule = projectProgress.GroupBy(x => x.ModuleId).ToList();
                List<ModuleProgress> modules = new();
                foreach (var module in groupedByModule)
                {
                    ModuleProgress moduleProgress = new();
                    //Obtener la cantidad de diagramas en el m�dulo
                    moduleProgress.TotalDiagramsInModule = module.Count();
                    //Obtener el total de puntos posibles
                    moduleProgress.TotalPossiblePoints = moduleProgress.TotalDiagramsInModule * 100;
                    //Sumar toda la columna Percentage de la lista de diagramas
                    moduleProgress.PointsByMatrix = module
                        .Sum(x => (x.Percentage ?? 0));
                    //Contar todos los diagramas que tienen 100 puntos
                    moduleProgress.CompletedDiagrams = module.Count(x => x.Percentage >= 100);
                    //Diagramas con SP_ID = 4 no suman
                    moduleProgress.PointsByCompletedDiagrams = 0;
                    //Obtener el total de puntos actuales
                    moduleProgress.CurrentPoints = moduleProgress.PointsByMatrix;
                    //Obtener el porcentaje de avance actual
                    if(moduleProgress.TotalPossiblePoints == 0)
                    {
                        moduleProgress.CurrentPercentage = 0;
                    }
                    else
                    {
                        moduleProgress.CurrentPercentage = ((decimal)moduleProgress.CurrentPoints / (decimal)moduleProgress.TotalPossiblePoints) * 100;
                    }
                    //Agregar id y nombre, ya que todos lo traen, el primero se puede usar de referencia
                    moduleProgress.ModuleId = module.FirstOrDefault().ModuleId;
                    moduleProgress.ModuleName = module.FirstOrDefault().ModuleName;
                    modules.Add(moduleProgress);
                }
                stats.Modules = modules;

                return stats;
            }
            catch
            {
                return null;
            }
        }

        public GetModuleProgress GetModuleProgress(int ModuleId)
        {
            try
            {
                var query = $"EXEC GetModuleProgress {ModuleId}";
                List<GetAllModuleDiagrams> moduleProgress = _dbContext.Set<GetAllModuleDiagrams>()
                    .FromSqlRaw(query)
                    .AsEnumerable()
                    .ToList();
                //C�lculos para el M�dulo
                GetModuleProgress stats = new();
                stats.TotalDiagramsInModule = moduleProgress.Count;
                stats.TotalPossiblePoints = stats.TotalDiagramsInModule * 100;
                stats.PointsByMatrix = moduleProgress
                    .Sum(x => (x.Percentage ?? 0));
                stats.CompletedDiagrams = moduleProgress.Count(x => x.Percentage >= 100);
                stats.PointsByCompletedDiagrams = 0;
                stats.CurrentPoints = stats.PointsByMatrix + stats.PointsByCompletedDiagrams;
                if (stats.TotalPossiblePoints == 0)
                {
                    stats.CurrentPercentage = 0;
                }
                else
                {
                    stats.CurrentPercentage = ((decimal)stats.CurrentPoints / (decimal)stats.TotalPossiblePoints) * 100;
                }

                //Ahora, agrupar por opciones, y repetir el c�lculo a este nivel
                var groupedByOption = moduleProgress.GroupBy(x => x.OptionId).ToList();
                List<OptionProgress> options = new();
                foreach (var option in groupedByOption)
                {
                    OptionProgress optionProgress = new();
                    optionProgress.TotalDiagramsInOption = option.Count();
                    optionProgress.TotalPossiblePoints = optionProgress.TotalDiagramsInOption * 100;
                    optionProgress.PointsByMatrix = option
                        .Sum(x => (x.Percentage ?? 0));
                    optionProgress.CompletedDiagrams = option.Count(x => x.Percentage >= 100);
                    optionProgress.PointsByCompletedDiagrams = 0;
                    optionProgress.CurrentPoints = optionProgress.PointsByMatrix + optionProgress.PointsByCompletedDiagrams;
                    if (optionProgress.TotalPossiblePoints == 0)
                    {
                        optionProgress.CurrentPercentage = 0;
                    }
                    else
                    {
                        optionProgress.CurrentPercentage = ((decimal)optionProgress.CurrentPoints / (decimal)optionProgress.TotalPossiblePoints) * 100;
                    }
                    optionProgress.OptionId = option.FirstOrDefault()?.OptionId ?? null;
                    optionProgress.OptionName = option.FirstOrDefault()?.OptionName ?? "Sin opci�n";
                    options.Add(optionProgress);
                }
                stats.Options = options;

                return stats;
            }
            catch
            {
                return null;
            }
        }
    }   
}
