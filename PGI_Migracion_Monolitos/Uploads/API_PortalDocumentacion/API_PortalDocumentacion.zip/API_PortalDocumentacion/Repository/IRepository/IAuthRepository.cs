using API_PortalDocumentacion.Models.Portal.Dtos;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IAuthRepository
    {
        public LoginResponseDTO LoginLocal(LoginRequestLocalDTO loginRequestDTO);

        public LoginResponseDTO LoginLDAP(LoginRequestLDAP_DTO loginRequestDTO);

        public string CreateJWT(string corporate, int countryId);

        public string Logout(string corporate);
    }
}
