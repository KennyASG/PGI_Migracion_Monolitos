﻿using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface INotificationRepository
    {
        public Task<List<Notification>> GetAllDocuNotifications(string corporate);
        public Task<List<Notification>> GetAllAdminNotifications(string corporate);
        public Task<List<DetailedNotificationModel>> GetDetailedDocuNotifByType(GetDocumenterNotificationModel docNotifModel);
        public Task<List<DetailedNotificationModel>> GetDetailedAdminNotifByType(GetAdminNotificationModel adminNotifModel);
        public string MarkNotification(MarkNotificationModel Notification);
        public Task<string> ApproveDiagram(ChangeNotificationStatusModel approveDiagramModel);
        public Task<string> RejectDiagram(ChangeNotificationStatusModel rejectDiagramModel);
        public string MarkAsSent(int notificationId);
    }
}
