﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IContentPLRepository
    {
        Task<List<SearchMatchPLResult>> SearchMatch(string searchedWord, string corporate);
        Task<DataDiagramPLDTO> GetDataDiagramPL(int diagramId);
        List<LayerDTO> LayersByCorporate(string corporate);
        public NodesAndGraphs GetNodesAndGraphs();
        Task<MacroResponseModel> GetMacro(int projectId);
    }
}
