﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IUserRepository
    {
        public string? RestorePassword(string username);
        string UpdatePassword(UpdatePasswordLUDTO updateUserDTO);
        bool UserExist(string corporate);
        bool IsUniqueUser(string corporate);
        bool DeleteUser(User user);
        bool Save();
    }
}
