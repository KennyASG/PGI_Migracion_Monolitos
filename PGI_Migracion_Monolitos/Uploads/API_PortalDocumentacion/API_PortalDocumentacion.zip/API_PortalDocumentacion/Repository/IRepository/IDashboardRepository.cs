﻿using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IDashboardRepository
    {
        public List<MostUsedElementbyProject> MostUsedElembyProj(int projectId);
        public List<ElementTypebyProject> ElemTbyProj(int projectId);
        public List<ElementsbyElementTypeAndProject> ElembyElemTAndProj(int projectId, int elementTypeId);
        public List<MostUsedElementbyProjectAndModule> MostUsedElembyProjAndMod(int projectId, int moduleId);
        public List<ElementTypebyProjectAndModule> ElemTbyProjAndMod(int projectId, int moduleId);
        public List<ElementsbyElementTypeProjectAndModule> ElembyElemTProjAndMod(int projectId, int elementTypeId, int moduleId);
        public List<ElementsOrion> GetElementOrionByProject(int ProjectId);
        public List<ElementsOrion> GetElementOrionByProAndMod(int ProjectId, int ModuleId);
        public GetProjectProgressWithModulesModel GetProjectProgressWithModules(int ProjectId);
        public GetModuleProgress GetModuleProgress(int ModuleId);
    }
}
