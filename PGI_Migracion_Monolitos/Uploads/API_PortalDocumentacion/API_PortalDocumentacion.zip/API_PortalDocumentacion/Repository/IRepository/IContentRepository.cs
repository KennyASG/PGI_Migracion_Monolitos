﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IContentRepository
    {
        Task<DataDiagramLLDTO> GetDataDiagrams(int diagramId, string? corporate = null, int? elementID = 0);
        Task<List<SearchMatchResult>> SearchMatch(string searchedWord, string corporate);
        Task<List<DetailedSearchMatchResult>> DetailedSearchMatch(BodyDetailedSearchDTO bodyDetailedSearchDTO);
        Task<List<Project>> GetProjectsByCorp(string corporate);
        Task<List<Module>> GetModuleByProject(int projectId);
        Task<List<Models.Portal.System>> GetSystemByModule(int moduleId);        
        Task<List<Project>> GetProjects();
        string SubmitRequest(SubmitRequest submitRequest);
        Task<List<SearchMatchResult>> ReturnHistory(string corporate);
        Task<List<ElementType>> GetElementTypeByCorp(string corporate);
        Task<List<Project>> GetProjects(int countryId);
    }
}
