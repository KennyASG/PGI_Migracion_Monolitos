﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface ICountryRepository
    {
        public Task<List<Country>> GetCountries();
        public Task<List<GetUserCountriesModel>> GetUserCountries(string corporate);
    }
}
