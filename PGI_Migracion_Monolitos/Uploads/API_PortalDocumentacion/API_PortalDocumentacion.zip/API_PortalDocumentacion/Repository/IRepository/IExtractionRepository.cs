﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IExtractionRepository
    {
        VisioExtractionResult  extractionData(string filePath, int diagramId, int flag);

    }
}
