using API_PortalDocumentacion.Models.Portal;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IProjectRepository
    {
        public string CreateProject(CreateProjectModel createProjectModel);
        public string UpdateProject(UpdateCreateProjectModel updateCreateProjModel);
        public string DeleteProjects(DeleteProjectModel delProjModel);
        public List<GetProModOptDiag> GetProjectsAndDocumenters();
        public Task<List<ReturnDocumentersModel>> GetListDocumenters();
        public Task<List<Classification>> GetClassifications();
        public Task<List<Layer>> GetLayers();
        public string CreateMatrix(CreateMatrixModel createMatrixModel);
        public string UpdateMatrix(UpdateMatrixModel updateMatrixModel);
        public GetMatrixAndDetailModel GetMatrixByDiagramId(int DiagramId);
        public string DiagramInstallation(InstallationModel InstallationDetails);
        public Task<List<InstallType>> GetInstallationTypes();
    }
}
