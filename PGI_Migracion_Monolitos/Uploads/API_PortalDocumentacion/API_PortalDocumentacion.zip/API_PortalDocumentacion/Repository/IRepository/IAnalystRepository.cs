using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IAnalystRepository
    {
        public string UploadDiagramaFileAsync(FileVisioModel fvisioModel);


    }
}
