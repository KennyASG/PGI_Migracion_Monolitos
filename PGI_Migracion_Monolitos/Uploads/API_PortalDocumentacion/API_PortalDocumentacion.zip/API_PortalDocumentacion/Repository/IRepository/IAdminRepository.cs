using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IAdminRepository
    {
        public string ApproveRequest([FromBody] ShowSystemRequest showSystemRequest);
        public List<ShowSystemRequest> ShowSystemRequest();
        public Task CreateNewContentLogicalLayer(Parameters_LogicalLayer parametersLL);
        public Task CreateNewContentPhysicalLayer(Parameters_PhysicalLayer parameters_PL);
        public Task DisableContent(Parameters_LogicalLayer parametersLL);
        public string CreateUser(CreateLocalUserDTO registerUserDTO);
        public List<AssignedPermission> AssignedPermissions();
        public bool UpdateProjects(AssignProjectsDTO assignPermissionDTO);
        public bool UpdateUserRoles(AssignRolesDTO assignRolesDTO);
        void SaveLog(string corporate, int action, int diagramId, string comment);
    }
}
