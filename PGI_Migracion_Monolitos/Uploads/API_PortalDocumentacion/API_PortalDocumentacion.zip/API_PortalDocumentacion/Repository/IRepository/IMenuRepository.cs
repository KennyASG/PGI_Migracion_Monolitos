﻿using API_PortalDocumentacion.Models.Portal;
using Microsoft.AspNetCore.Mvc;

namespace API_PortalDocumentacion.Repository.IRepository
{
    public interface IMenuRepository
    {
        public List<MenuItem> BuildMenuTree(List<MenuItem> menuItems);
        public List<MenuItem> GetListItems(string corporate);
        public List<DocumenterMenuItem> GetDocumenterMenuItems(string corporate);
        public Task<NotificationAndRequestCountModel> GetNotificationAndRequestCount(GetNotifAndRequestCountModel details);
    }
}
