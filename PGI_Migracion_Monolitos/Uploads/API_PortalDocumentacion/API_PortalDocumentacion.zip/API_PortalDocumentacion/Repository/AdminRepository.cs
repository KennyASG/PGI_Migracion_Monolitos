#pragma warning disable IDE0028
#pragma warning disable IDE0290
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Repository.IRepository;
using System.Data;
using API_PortalDocumentacion.Security;
using API_PortalDocumentacion.Tools;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using XAct;

namespace API_PortalDocumentacion.Repository
{
    public class AdminRepository : IAdminRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;

        public IConfiguration _configuration;
        public string bodyMessage, currentPath, projectPath, fullPath, titleEmail, LogicalLayer, PhysicalLayer;
        bool isApprove;
        public EmailSender emailSender = new();
        public GenerateRandomPassword genRandomPws = new();

        public AdminRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration)
        {
            _dbContext = dbContext;
            _configuration = configuration;
        }

        //Function ShowSystemRequest return list user request.
        public List<ShowSystemRequest> ShowSystemRequest()
        {
            List<ShowSystemRequest> ssrDTO = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var query = (from srd in _dbContext.SystemRequestDetails
                             join sr in _dbContext.SystemRequests on srd.SrId equals sr.SrId
                             join p in _dbContext.Projects on srd.ProjectId equals p.ProjectId
                             join u in _dbContext.Users on sr.Corporate equals u.Corporate into usrGroup
                             from u in usrGroup.DefaultIfEmpty() // Left join
                             where srd.Active == true && sr.Active == true
                             orderby srd.SrId
                             select new
                             {
                                 AuthorizedRequest = sr.Authorized,
                                 srd.SrdId,
                                 sr.SrId,
                                 srd.ProjectId,
                                 AuthorizedDetail = srd.Authorized,
                                 p.Project1,
                                 p.LayerId,
                                 sr.Corporate,
                                 sr.UserInformation,
                                 State = srd.Active,
                                 srd.CreationDate
                             }).ToList();

                transaction.Commit();

                if (query == null || query.Count == 0) return null;

                //Obtener datos de país, por legacy, tomamos inactivos
                //Si se elimina a un país, aún podrá ver cual fue su petición en su momento
                var countries = _dbContext.Countries.ToList();

                var groupedResults = query
                    .GroupBy(r => r.SrId)
                    .Select(g => new ShowSystemRequest
                    {
                        SrId = g.First().SrId,
                        Corporate = g.First().Corporate,
                        Name = g.First().UserInformation?.Split(';').ElementAtOrDefault(0) ?? string.Empty,
                        Department = g.First().UserInformation?.Split(';').ElementAtOrDefault(1) ?? string.Empty,
                        Job = g.First().UserInformation?.Split(';').ElementAtOrDefault(2) ?? string.Empty,
                        AuthorizedRequest = g.First().AuthorizedRequest,
                        CountryId = g.First().UserInformation?.Split(';').ElementAtOrDefault(3).ToInt16() ?? 0,
                        CountryCode = countries.Where(c=> c.Id == (g.First().UserInformation?.Split(';').ElementAtOrDefault(3).ToInt16() ?? 0)).Select(c => c.CountryCode).FirstOrDefault(),
                        CountryName = countries.Where(c => c.Id == (g.First().UserInformation?.Split(';').ElementAtOrDefault(3).ToInt16() ?? 0)).Select(c => c.CountryName).FirstOrDefault(),
                        ProjectsRequest = g.Select(item => new ShowSystemRequestDetail
                        {
                            SrdId = item.SrdId,
                            ProjectId = item.ProjectId,
                            ProjectName = item.Project1,
                            layerId = item.LayerId,
                            AuthorizedDetail = item.AuthorizedDetail,
                            Active = true,
                            CreationDate = item.CreationDate,
                        }).ToList()
                    }).ToList();

                ssrDTO.AddRange(groupedResults);
            }
            return ssrDTO;
        }

        //Function to approve user's request 
        public string ApproveRequest([FromBody] ShowSystemRequest showSystemRequest)
        {
            SystemRequest? UserRequest;

            try
            {
                using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
                {
                    UserRequest = _dbContext.SystemRequests.FirstOrDefault(u => u.Corporate == showSystemRequest.Corporate & u.Authorized == null & u.Active == true);

                    transaction.Commit();

                    if (UserRequest == null) return null;

                    if (showSystemRequest.AuthorizedRequest == true)
                    {
                        User user = new() { Corporate = showSystemRequest.Corporate, FirstSession = true, CountryId = showSystemRequest.CountryId };

                        UserRole userRole = new()
                        {
                            Corporate = user.Corporate,
                            RoleId = 1
                        };

                        _dbContext.Users.Add(user);
                        _dbContext.UserRoles.Add(userRole);
                        _dbContext.SaveChanges();
                    }

                    UserRequest.Authorized = showSystemRequest.AuthorizedRequest;
                    UserRequest.VerificationDate = DateTime.Now;

                    _dbContext.SystemRequests.Update(UserRequest);
                    _dbContext.SaveChanges();

                    foreach (var item in showSystemRequest.ProjectsRequest)
                    {
                        SystemRequestDetail srd = new()
                        {
                            SrdId = item.SrdId,
                            SrId = UserRequest.SrId,
                            ProjectId = item.ProjectId,
                            Authorized = item.AuthorizedDetail,
                            Active = item.Active,
                            CreationDate = item.CreationDate
                        };

                        _dbContext.SystemRequestDetails.Update(srd);

                        if (item.AuthorizedDetail == true)
                        {
                            Permission permission = new()
                            {
                                Corporate = showSystemRequest.Corporate,
                                ProjectId = item.ProjectId
                            };

                            _dbContext.Permissions.Add(permission);
                        }
                        _dbContext.SaveChanges();
                    }
                }
            }
            catch (Exception ex) { return ex.Message; }

            string projectPath = AppContext.BaseDirectory;
            string fullPath = Path.Combine(projectPath, "Content", "TemplatesHTML", "PlantillaSOLICITUDDENEGADA.html");
            titleEmail = "SOLICITUD DENEGADA PARA PORTAL DE DOCUMENTACIÓN TI";

            if (showSystemRequest.AuthorizedRequest == true)
            {
                fullPath = Path.Combine(projectPath, "Content", "TemplatesHTML", "PlantillaSOLICITUDAPROBADA.html");
                titleEmail = "SOLICITUD APROBADA PARA PORTAL DE DOCUMENTACIÓN TI";
                isApprove = true;
            }

            try
            {
                bodyMessage = File.ReadAllText(fullPath);
                bodyMessage = bodyMessage.Replace("[DOMAIN]", _configuration.GetValue<string>("Domain:URL"));
            }
            catch
            { return "Ha ocurrido un error"; }

            emailSender.EmailSend(UserRequest.Email, titleEmail, bodyMessage, _configuration);

            string response = (isApprove) ? "Aprobado" : "Denegado";

            return response;
        }

        //Function to create new data in DB
        public async Task CreateNewContentLogicalLayer(Parameters_LogicalLayer PLL)
        {
            try
            {
                LogicalLayer = "Capa Lógica";
                await _dbContext.Database.ExecuteSqlRawAsync("EXEC CreatingNewDataForLogicalLayers @PROJECT={0}, @LAYER={1}, @MODULE={2}, @OPTION={3}, @DIAGRAM_NAME={4}, @FILE_NAME={5}, @SYSTEM={6}, @ELEMENTT={7}, @ELEMENT={8}, @CLASSIFICATION={9}, @FILE_EXT={10}",
                    PLL.project, LogicalLayer, PLL.module, PLL.option, PLL.diagramName, PLL.fileName, PLL.system,
                    PLL.elementt, PLL.element, PLL.classification, PLL.fileExtension);

            }
            catch (Exception ex) { Console.WriteLine("Error: " + ex); }
        }

        public async Task CreateNewContentPhysicalLayer(Parameters_PhysicalLayer PPL)
        {
            try
            {
                PhysicalLayer = "Capa Física";
                await _dbContext.Database.ExecuteSqlRawAsync("EXEC CreatingNewDataForPhysicalLayers @PROJECT={0}, @LAYER={1}, @MODULE={2}, @OPTION={3}, @DIAGRAM_NAME={4}, @FILE_NAME={5}, @LOGICAL_CONN={6}, @SERVICE={7}, @LOCATION_A={8}, @AREA_A={9}, @PLATFORM_A={10}, @ELEMENTT_A={11}, @ELEMENT_A={12}, @IP_A={13}, @INTERFACE_A={14}, @LOCATION_Z={15}, @AREA_Z={16}, @PLATFORM_Z={17}, @ELEMENTT_Z={18}, @ELEMENT_Z={19}, @IP_Z={20}, @INTERFACE_Z={21}, @CLASSIFICATION={22}, @FILE_EXT={23}",
                      PPL.project, PhysicalLayer, PPL.module, PPL.option, PPL.diagramName, PPL.fileName, PPL.logicalConn, 
                      PPL.service, PPL.locationA, PPL.areaA, PPL.platformA, PPL.elementtA,PPL.elementA, PPL.ipA, PPL.interfaceA, 
                      PPL.locationZ, PPL.areaZ, PPL.platformZ, PPL.elementtZ, PPL.elementZ, PPL.ipZ, PPL.interfaceZ, PPL.classification, PPL.fileExtension);

            }
            catch (Exception ex) { Console.WriteLine("Error: " + ex); }
        }

        public async Task DisableContent(Parameters_LogicalLayer PLL)
        {
            await _dbContext.Database.ExecuteSqlRawAsync("EXEC DisableRecordsFromDETAIL @PROJECT={0}, @MODULE={1}, @OPTION={2}, @DIAGRAM_NAME={3},  @SYSTEM={4};",
               PLL.project, PLL.module, PLL.option, PLL.diagramName, PLL.system);
        }

        //Function create user, receive a model (username, full name, email, department and job) and send an email with a temporary password.
        public string CreateUser(CreateLocalUserDTO registerUserDTO)
        {
            string projectPath = AppContext.BaseDirectory;
            string fullPath = Path.Combine(projectPath, "Content", "TemplatesHTML", "PlantillaSOLICITUDAPROBADALOCAL.html");
            var passRandom = genRandomPws.GetRandomPassword();
            User user = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {

                var uniqueUser = _dbContext.Users.Any(u => u.Corporate == registerUserDTO.Username);

                transaction.Commit();

                if (uniqueUser) return "User exist";

                try
                {
                    byte[] salt = new byte[16];
                    using (var rng = new RNGCryptoServiceProvider())
                    {
                        rng.GetBytes(salt);
                    }

                    using (var pbkdf2 = new Rfc2898DeriveBytes(passRandom, salt, 100000, HashAlgorithmName.SHA256))
                    {
                        byte[] hash = pbkdf2.GetBytes(32);

                        // Convert to Base64
                        string saltBase64 = Convert.ToBase64String(salt);
                        string hashBase64 = Convert.ToBase64String(hash);

                        user.Corporate = registerUserDTO.Username;
                        user.Passwordhash = hashBase64;
                        user.Names = registerUserDTO.Names;
                        user.Surnames = registerUserDTO.Surnames;
                        user.Email = registerUserDTO.Email;
                        user.Department = registerUserDTO.Department;
                        user.Job = registerUserDTO.Job;
                        user.Salt = saltBase64;
                        user.CountryId = registerUserDTO.CountryId;

                        _dbContext.Users.Add(user);
                        _dbContext.SaveChanges();

                        foreach (var item in registerUserDTO.RequestSystem)
                        {
                            Permission permission = new()
                            {
                                Corporate = registerUserDTO.Username,
                                ProjectId = item.Id
                            };

                            _dbContext.Permissions.Add(permission);
                        }

                        UserRole userRole = new()
                        {
                            Corporate = user.Corporate,
                            RoleId = 4
                        };

                        _dbContext.UserRoles.Add(userRole);
                        _dbContext.SaveChanges();

                        string bodyMessage = File.ReadAllText(fullPath);
                        bodyMessage = bodyMessage.Replace("[DOMAIN]", _configuration.GetValue<string>("Domain:URL"))
                                                 .Replace("[USERNAME]", user.Corporate)
                                                 .Replace("[PASSWORD]", passRandom);

                        emailSender.EmailSend(user.Email, "BIENVENIDO/A A PORTAL DE DOCUMENTACIÓN TI", bodyMessage, _configuration);

                        return "Successfully created";
                    }
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
            }
        }

        //Function to show assigned permissions
        public List<AssignedPermission> AssignedPermissions()
        {
            List<AssignedPermission> listAssignedP = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var query = from u in _dbContext.Permissions.Select(p => p.Corporate).Distinct()
                            from p in _dbContext.Projects
                            join perm in _dbContext.Permissions on new { Corp = u, ProjId = p.ProjectId }
                                equals new { Corp = perm.Corporate, ProjId = perm.ProjectId }
                                into permJoin
                            from perm in permJoin.DefaultIfEmpty()
                            join us in _dbContext.Users on perm.Corporate equals us.Corporate into userJoin
                            from us in userJoin.DefaultIfEmpty()
                            join ur in _dbContext.UserRoles on us.Corporate equals ur.Corporate into roleJoin
                            from ur in roleJoin.DefaultIfEmpty()
                            join r in _dbContext.Roles on ur.RoleId equals r.RoleId into roleNameJoin
                            from r in roleNameJoin.DefaultIfEmpty()
                            join c in _dbContext.Countries on p.CountryId equals c.Id
                            where p.SpId == 4
                            select new
                            {
                                Id = perm != null ? perm.Id : (int?)null,
                                Corporate = u,
                                Username = us != null ? us.Names + " " + us.Surnames : null,
                                Email = us != null ? us.Email : null,
                                Job = us != null ? us.Job : null,
                                Department = us != null ? us.Department : null,
                                Project_Id = p.ProjectId,
                                layerId = p.LayerId,
                                ProjectName = p.Project1,
                                P_Active = perm != null ? perm.Active ?? false : false,
                                UserRoleId = ur != null ? ur.UrId : (int?)null,
                                RoleId = ur != null ? ur.RoleId : (int?)null,
                                RoleName = r != null ? r.RoleName : null,
                                R_Active = ur != null ? ur.Active ?? false : false,
                                CountryId = p.CountryId,
                                CountryCode = c.CountryCode,
                                CountryName = c.CountryName
                            };

                transaction.Commit();

                // Obtener todos los roles disponibles
                var allRoles = _dbContext.Roles.ToList();

                var result = query.OrderBy(r => r.Corporate).ThenBy(r => r.Project_Id).ToList();

                var groupedResults = result
               .GroupBy(r => r.Corporate)
               .Select(g => {
                   // Seleccionar el mejor registro con más información
                   var bestItem = g
                       .OrderByDescending(item => !string.IsNullOrEmpty(item.Username))
                       .ThenByDescending(item => !string.IsNullOrEmpty(item.Email))
                       .ThenByDescending(item => !string.IsNullOrEmpty(item.Job))
                       .ThenByDescending(item => !string.IsNullOrEmpty(item.Department))
                       .FirstOrDefault();

                   return new AssignedPermission
                   {
                       Corporate = g.Key,
                       User = bestItem?.Username,
                       Email = bestItem?.Email,
                       Job = bestItem?.Job,
                       Department = bestItem?.Department,

                       // Asignar todos los roles sin duplicados
                       AssignedRoles = allRoles
                           .GroupJoin(
                               g.Where(item => item.RoleId != null),
                               role => role.RoleId,
                               userRole => userRole.RoleId,
                               (role, userRoles) => new { role, userRoles })
                           .SelectMany(
                               x => x.userRoles.DefaultIfEmpty(),
                               (x, userRole) => new AssignedRoles
                               {
                                   UserRoleId = userRole?.UserRoleId,
                                   RoleId = x.role.RoleId,
                                   RoleName = x.role.RoleName,
                                   Active = userRole?.R_Active ?? false
                               })
                           .GroupBy(ar => ar.RoleId) 
                           .Select(grp => grp.First()) 
                           .ToList(),

                       // Asignar proyectos
                       AssignedProjects = g
                           .GroupBy(item => new { item.Project_Id, item.ProjectName, item.P_Active, item.layerId })
                           .Select(grp => grp.FirstOrDefault())
                           .Where(item => item != null)
                           .Select(item => new AssignedProject
                           {
                               PermissionId = item.Id,
                               ProjectId = item.Project_Id,
                               ProjectName = item.ProjectName,
                               LayerId = item.layerId,
                               Active = item.P_Active,
                               CountryId = item.CountryId,
                               CountryCode = item.CountryCode,
                               CountryName = item.CountryName
                           })
                           .ToList()
                   };
               })
               .OrderBy(g => g.Corporate)
               .ToList();

                listAssignedP.Add(groupedResults);
            }

            return listAssignedP;
        }

        //Funciton Update permission
        public bool UpdateProjects(AssignProjectsDTO assignPermissionsDTO)
        {
            try { 
                using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
                {
                    var existingPermissions = _dbContext.Permissions
                    .Where(p => p.Corporate == assignPermissionsDTO.Corporate)
                    .ToList();

                    transaction.Commit();

                    foreach (var item in assignPermissionsDTO.AssignedProjects)
                    {
                        if (item.PermissionId == 0 && item.Active == true)
                        {
                            var newPermission = new Permission
                            {
                                Corporate = assignPermissionsDTO.Corporate,
                                ProjectId = item.ProjectId,
                                Active = item.Active
                            };

                            _dbContext.Permissions.Add(newPermission);
                        }

                        if (item.PermissionId != 0)
                        {
                            var existingPermission = existingPermissions.FirstOrDefault(p => p.Id == item.PermissionId);

                            if (existingPermission != null && existingPermission.Active != item.Active)
                            {
                                existingPermission.Active = item.Active;
                            }
                        }
                    }

                    _dbContext.SaveChanges();
                }
            } catch { return false; }

            return true;
        }

        public bool UpdateUserRoles(AssignRolesDTO assignRolesDTO)
        {
            try { 
                using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
                {
                    var existingRoles = _dbContext.UserRoles
                   .Where(p => p.Corporate == assignRolesDTO.Corporate)
                   .ToList();

                    if (existingRoles.Count == 0) return false;

                    transaction.Commit();

                    foreach (var item in assignRolesDTO.AssignedRoles)
                    {
                        if (item.UserRoleId == 0 && item.Active == true)
                        {
                            if(!existingRoles.Any(p => p.RoleId == item.RoleId))
                            {
                                var newUserRole = new UserRole
                                {
                                    Corporate = assignRolesDTO.Corporate,
                                    RoleId = item.RoleId,
                                    Active = item.Active
                                };

                                _dbContext.UserRoles.Add(newUserRole);
                            }
                        }

                        if (item.UserRoleId != 0)
                        {
                            var existingRole = existingRoles.FirstOrDefault(p => p.RoleId == item.RoleId);

                            if (existingRole != null && existingRole.Active != item.Active)
                            {
                                existingRole.Active = item.Active;
                            }
                        }
                    }

                    _dbContext.SaveChanges();
                }
            } catch { return false; }

            return true;
        }

        //Save log the user
        public void SaveLog(string corporate, int action, int diagramId, string comment)
        {
            Log log = new()
            {
                Corporate = corporate,
                LaId = action,
                DiagramId = (diagramId != 0) ? diagramId : null,
                Comment = (comment.Length != 0 ) ? comment : null
            };

            _dbContext.Logs.Add(log);
            _dbContext.SaveChanges();
        }
    }
}
