﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.EntityFrameworkCore;

namespace API_PortalDocumentacion.Repository
{
    public class CountryRepository : ICountryRepository
    {
        public DbPortalDocumentacionContext _dbContext;
        public CountryRepository(DbPortalDocumentacionContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Country>> GetCountries()
        {
            try
            {
                var countries = await _dbContext.Countries.Where(c => c.Active == true).ToListAsync();

                List<Country> result = new List<Country>();
                foreach (var country in countries) { 
                    result.Add(new Country
                    {
                        Id = country.Id,
                        CountryName = country.CountryName,
                        CountryCode = country.CountryCode,
                        Active = country.Active,
                        CreationDate = null,
                        Projects = []
                    });
                }
                return result;
            }
            catch
            {
                return null;
            }
        }

        public async Task<List<GetUserCountriesModel>> GetUserCountries(string Corporate)
        {
            if (Corporate == null) return null;
            try
            {
                var countries = await (from c in _dbContext.Countries
                                       join p in _dbContext.Projects on c.Id equals p.CountryId
                                       join pe in _dbContext.Permissions on p.ProjectId equals pe.ProjectId
                                       join l in _dbContext.Layers on p.LayerId equals l.LayerId
                                       where c.Active == true && p.Active == true && pe.Active == true && l.Active == true
                                       && pe.Corporate == Corporate
                                       select new 
                                       {
                                           c.Id,
                                           c.CountryCode,
                                           c.CountryName,
                                           l.LayerId
                                       }).Distinct()
                                       .ToListAsync();

                List<GetUserCountriesModel> result = [];

                foreach (var country in countries)
                {
                    var existingCountry = result.FirstOrDefault(c => c.Id == country.Id);
                    if (existingCountry != null)
                    {
                        if (existingCountry.HasLogicalProjects == false && country.LayerId == (int)Classification.LogicalLayer) 
                            existingCountry.HasLogicalProjects = true;
                        
                        if (existingCountry.HasPhysicalProjects == false && country.LayerId == (int)Classification.PhysicalLayer)
                            existingCountry.HasPhysicalProjects = true;
                    }
                    else
                    {
                        result.Add(new GetUserCountriesModel
                        {
                            Id = country.Id,
                            CountryCode = country.CountryCode,
                            CountryName = country.CountryName,
                            HasLogicalProjects = country.LayerId == (int)Classification.LogicalLayer,
                            HasPhysicalProjects = country.LayerId == (int)Classification.PhysicalLayer
                        });
                    }
                }

                return result;
            }
            catch
            {
                return null;
            }
        }

        private enum Classification
        {
            LogicalLayer = 1,
            PhysicalLayer = 2
        }
    }
}
