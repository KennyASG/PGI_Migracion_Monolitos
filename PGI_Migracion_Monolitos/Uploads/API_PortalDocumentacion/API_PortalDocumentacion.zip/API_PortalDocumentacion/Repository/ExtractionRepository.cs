﻿
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Repository.IRepository;
using API_PortalDocumentacion.Tools;
using Microsoft.EntityFrameworkCore;

namespace API_PortalDocumentacion.Repository
{
    public class ExtractionRepository : IExtractionRepository
    {
        private DbPortalDocumentacionContext _dbContext;
        private ExtractData extract;
        public IConfiguration configuration;
        
        public ExtractionRepository(DbPortalDocumentacionContext dbContext,IConfiguration configuration, IAdminRepository adminRepository)
        {
            _dbContext = dbContext;
            this.configuration = configuration;
            extract = new ExtractData();
        }

        public  VisioExtractionResult extractionData(string filePath, int diagramId, int flag)
        {
            VisioExtractionResult result = extract.ProcessVisioFile(filePath, diagramId);
            switch (flag)
            {
                case 0: // solo extraccion 
                    return result;

                case 1: // extraccion insercion nuevo diagrama
                    if (result.UnrecognizedShapes.Count > 0)
                    {
                        return result;
                    }
                    else
                    {                        
                        foreach (ShapeData shapeData in result.ShapesList)
                        {
                            if (shapeData.Element.Length < 1) { continue; }

                            _dbContext.Database.ExecuteSqlRaw("EXEC [dbo].[CreateDataDiagram] @DIAGID={0}, @SYSTEM={1}, @ELEMENTT={2}, @ELEMENT={3}",
                               diagramId,
                               shapeData.System,
                               shapeData.ElementType,
                               shapeData.Element
                               );
                        }
                    }
                    return result;

                case 2: // extraccion actualizacion de diagrama
                       
                    if (result.UnrecognizedShapes.Count > 0)
                    {
                        return result;
                    }
                    else {
                        try
                        {
                            _dbContext.Database.ExecuteSqlRaw("EXEC [dbo].[DisableRecordsDETAILByDiagram] @DIAGID={0}", diagramId);
                        }
                        catch (Exception ex) { 
                            Console.WriteLine(ex.ToString());   
                        }
                        foreach (ShapeData shapeData in result.ShapesList)
                        {
                             _dbContext.Database.ExecuteSqlRaw("EXEC UpdateDataDiagram @DIAGID={0}, @SYSTEM={1}, @ELEMENTT={2}, @ELEMENT={3}",
                                diagramId,
                                shapeData.System,
                                shapeData.ElementType,
                                shapeData.Element
                                );
                        }
                    }
                    return result;
                   
                default:
                    return result;
            }           
        }
    }
}