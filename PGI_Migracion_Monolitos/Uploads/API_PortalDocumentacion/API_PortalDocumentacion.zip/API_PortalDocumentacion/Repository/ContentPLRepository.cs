﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using API_PortalDocumentacion.Models.Portal.Dtos;
using Microsoft.Extensions.Caching.Memory;
using System.Data;

namespace API_PortalDocumentacion.Repository
{
    public class ContentPLRepository: IContentPLRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;
        private readonly IMemoryCache _memoryCache;
        public IConfiguration _configuration;

        public ContentPLRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration, IMemoryCache memoryCache)
        {
            _dbContext = dbContext;
            _memoryCache = memoryCache;
            _configuration = configuration;
        }

        public async Task<List<SearchMatchPLResult>> SearchMatch(string searchedWord, string corporate)
        {
            var searchedWordParam = new SqlParameter("@searchedWord", searchedWord);
            var corporateParam = new SqlParameter("@corporate", corporate);
            var results = new List<SearchMatchPLResult>();
            try
            {
                // Llamar al procedimiento almacenado usando FromSqlRaw
                results = await _dbContext.Set<SearchMatchPLResult>()
                    .FromSqlRaw("EXEC [dbo].[SearchMatchPL] @searchedWord, @corporate", searchedWordParam, corporateParam)
                    .ToListAsync();

            }
            catch (Exception ex) { 
                Console.WriteLine(ex.ToString());
            }
            
            return results;
        }

        public async Task<DataDiagramPLDTO> GetDataDiagramPL(int diagramId)
        {
            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var diagramContent = await (from d in _dbContext.Diagrams
                                           join f in _dbContext.FileExtensions on d.FeId equals f.FeId
                                           where d.DiagramId == diagramId
                                           select new
                                           {
                                               FilePath = d.FilePath + f.Extension,
                                               SVGPath = d.FilePath + ".svg",
                                               d.CreationDate,
                                               d.UpdateDate
                                           }).FirstOrDefaultAsync();

                if (diagramContent == null) return null;

                var query = await (from cn in _dbContext.Connections
                                   join i1 in _dbContext.Interfaces on cn.FInterfaceId equals i1.InterfaceId
                                   join i2 in _dbContext.Interfaces on cn.SInterfaceId equals i2.InterfaceId
                                   join e1 in _dbContext.Elements on i1.ElementId equals e1.ElementId
                                   join e2 in _dbContext.Elements on i2.ElementId equals e2.ElementId
                                   where cn.DiagramId == diagramId
                                   select new
                                   {
                                       Id = cn.ConnectionId,
                                       ServiceName = _dbContext.Services
                                        .Where(s => s.ServiceId == cn.ServiceId)
                                        .Select(s => s.ServiceName)
                                        .FirstOrDefault() ?? "Conexión",
                                       OriginElement = e1.Element1,
                                       OriginIp = e1.IpAdministration,
                                       OriginInterface = i1.InterfaceName,
                                       DestinationElement = e2.Element1,
                                       DestinationIp = e2.IpAdministration,
                                       DestinationInterface = i2.InterfaceName,
                                       LC = cn.LogicalConnection
                                   }).ToListAsync();

                transaction.Commit();

                var connectionsResult = query
                .Select(g => new ConnectionsDiagramDTO
                {
                    Id = g.Id,
                    ServiceName = g.ServiceName,
                    SourceElement = g.OriginElement,
                    SourceIp = g.OriginIp,
                    SourceInterface = g.OriginInterface,
                    TargetElement = g.DestinationElement,
                    TargetIp = g.DestinationIp,
                    TargetInterface = g.DestinationInterface,
                    LogicalConnection = g.LC
                })
                .ToList();

                DataDiagramPLDTO responseDTO = new()
                {
                    FilePath = diagramContent.FilePath,
                    SVGPath = diagramContent.SVGPath,
                    ConnectionsDiagram = connectionsResult,
                    CreationDate = diagramContent.CreationDate,
                    UpdateDate = diagramContent.UpdateDate
                };

                return responseDTO;
            }
        }

        public List<LayerDTO> LayersByCorporate(string corporate)
        {
            List<LayerDTO> layersList = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var result = (from per in _dbContext.Permissions
                              join p in _dbContext.Projects on per.ProjectId equals p.ProjectId
                              join y in _dbContext.Layers on p.LayerId equals y.LayerId
                              where per.Corporate == corporate && per.Active == true
                              group y by new { y.LayerId, y.LayerName } into groupedLayers
                              select new
                              {
                                  LayerId = groupedLayers.Key.LayerId,
                                  LayerName = groupedLayers.Key.LayerName
                              }).ToList();

                if (result.Count == 0) return null;

                foreach (var item in result)
                {
                    LayerDTO layer = new()
                    {
                        LayerId = item.LayerId,
                        LayerName = item.LayerName
                    };

                    layersList.Add(layer);
                }
            }

            return layersList;
        }

        public NodesAndGraphs GetNodesAndGraphs()
        {
            if (!_memoryCache.TryGetValue("MyDataCacheKey", out NodesAndGraphs cachedData))
            {
                string connectionString = _configuration.GetConnectionString("PathConnectionDBOrion");

                var NodesData = GetNodes(connectionString);

                cachedData = new NodesAndGraphs
                {
                    Nodes = NodesData,
                    Edges = GetEdges(connectionString),
                    Locations = GetLocations(NodesData),
                    Types = GetMachineTypes(NodesData),
                    Areas = GetAreas(NodesData),
                    Vendors = GetVendors(NodesData)
                };

                _memoryCache.Set("MyDataCacheKey", cachedData, TimeSpan.FromDays(1));
            }

            return cachedData;
        }

        private List<Nodess> GetNodes(string connectPath)
        {
            var listNodes = new List<Nodess>();
            string machine;

            string queryNodes = @"SELECT DISTINCT
	                            UPPER(IIF(nds.NodeID = '', 'Desconocido', nds.NodeID)) AS ID,
	                            UPPER(IIF(nds.Caption = '', 'Desconocido', nds.Caption)) AS Label,
	                            UPPER(IIF(nds.IP_Address = '', 'Desconocido', nds.IP_Address)) AS IP_Adress,
	                            UPPER(IIF(ncp.Sitio IS NULL, 'Desconocido', ncp.Sitio)) AS Location,
	                            UPPER(IIF(nds.Vendor = '', 'Desconocido', nds.Vendor)) AS Vendor,
	                            UPPER(IIF(ncp.OwnerGroup IS NULL, 'Desconocido', ncp.OwnerGroup)) AS Contact,
	                            UPPER(IIF(ncp.Tipo_equipo IS NULL, 'Desconocido', ncp.Tipo_equipo)) AS MachineType
                                FROM TopologyConnections tc
	                            JOIN NodesData nds ON (nds.NodeID = SourceNodeID OR nds.NodeID = MappedNodeID)
	                            JOIN NodesCustomProperties ncp ON ncp.NodeID = nds.NodeID
                                WHERE LinkType != 'Layer2CamBasedLinkTo' AND DestType != 'Orion.ShadowNodes';";

            using (var connection = new SqlConnection(connectPath))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction(IsolationLevel.ReadUncommitted))
                using (var command = new SqlCommand(queryNodes, connection, transaction))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var nodes = new Nodess
                            {
                                NodeId = reader.GetString(0),
                                Label = reader.GetString(1),
                                IpAddress = reader.GetString(2),
                                Location = reader.GetString(3),
                                Vendor = reader.GetString(4),
                                Contact = reader.GetString(5),
                                MachineType = reader.GetString(6),
                            };
                            listNodes.Add(nodes);
                        }
                    }
                    transaction.Commit();
                }
                connection.Close();
            }

            return listNodes;
        }

        private List<Edgess> GetEdges(string connectPath)
        {
            var listEdges = new List<Edgess>();

            string queryEdges = @"SELECT nds.NodeID AS Source, IIF(its.InterfaceName IS NULL, 'Desconocida', 
            its.InterfaceName) AS InterfazOrigen, ndd.NodeID AS Target, IIF(itd.InterfaceName IS NULL, 'Desconocida', 
            itd.InterfaceName) AS InterfazDestino, LastUpdateUtc, Layer_Type, LinkType, CONCAT(IIF(its.InterfaceName IS NULL, 
            'Desconocida', its.InterfaceName), ' <-> ', IIF(itd.InterfaceName IS NULL, 'Desconocida', 
            itd.InterfaceName)) AS Label FROM TopologyConnections tc JOIN NodesData nds ON SourceNodeID = nds.NodeID JOIN NodesData ndd ON MappedNodeID = ndd.NodeID 
            LEFT JOIN Interfaces its ON SourceInterfaceID = its.InterfaceID LEFT JOIN Interfaces itd ON MappedInterfaceID = itd.InterfaceID WHERE DestType != 'Orion.ShadowNodes' AND LinkType != 'Layer2CamBasedLinkTo';";

            using (var connection = new SqlConnection(connectPath))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction(IsolationLevel.ReadUncommitted))
                using (var command = new SqlCommand(queryEdges, connection, transaction))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var edges = new Edgess
                            {
                                Source = reader.GetInt32(0),
                                InterfaceOrigin = reader.GetString(1),
                                Target = reader.GetInt32(2),
                                InterfaceDestino = reader.GetString(3)
                            };
                            listEdges.Add(edges);
                        }
                    }
                    transaction.Commit();
                }
                connection.Close();
            }

            return listEdges;
        }

        private List<Various> GetLocations(List<Nodess> node)
        {
            List<Various> listLocation = new();
            var locations = node.GroupBy(x => x.Location).Select(g => g.First()).ToList();

            foreach (var n in locations)
            {
                Various various = new()
                {
                    Key = n.Location,
                    Label = n.Location
                };
                listLocation.Add(various);
            }

            listLocation = listLocation.OrderBy(v => v.Label).ToList();

            return listLocation;
        }

        private List<MachineTypes> GetMachineTypes(List<Nodess> node)
        {
            string[] Colors = ["#338C9E", "#FFB81C", "#00C1D4", "#FDD26E", "#2D8C9E", "#FF7F00"];
            int index = 0;
            Random random = new Random();
            List<MachineTypes> listDeviceTypes = new();
            var deviceTypes = node.GroupBy(x => x.MachineType).Select(g => g.First()).ToList();

            foreach (var mt in deviceTypes)
            {
                index = random.Next(Colors.Length);

                MachineTypes devicesT = new()
                {
                    Key = mt.MachineType,
                    Color = Colors[index],
                    Icon = mt.MachineType,
                    Size = 10
                };
                listDeviceTypes.Add(devicesT);
            }

            return listDeviceTypes;
        }

        private List<Various> GetAreas(List<Nodess> node)
        {
            var listAreas = new List<Various>();

            var group = node.GroupBy(x => x.Contact).Select(g => g.First()).ToList();

            foreach (var n in group)
            {
                Various various = new()
                {
                    Key = n.Contact,
                    Label = n.Contact
                };
                listAreas.Add(various);
            }

            return listAreas;
        }

        private List<Various> GetVendors(List<Nodess> node)
        {
            var listVendors = new List<Various>();

            var vendors = node.GroupBy(x => x.Vendor).Select(g => g.First()).ToList();

            foreach (var n in vendors)
            {
                Various various = new()
                {
                    Key = n.Vendor,
                    Label = n.Vendor
                };
                listVendors.Add(various);
            }

            return listVendors;
        }

        public async Task<MacroResponseModel> GetMacro(int projectId)
        {
            MacroResponseModel macroResp = new();
            var infoProj = (from p in _dbContext.Projects
                              join c in _dbContext.Countries on p.CountryId equals c.Id
                              where p.ProjectId == projectId
                              select new
                              {
                                  countryName = c.CountryName,
                                  projectName = p.Project1
                              }).FirstOrDefault();

            if (infoProj == null) return null;

            string mainPath = $@"{_configuration.GetValue<string>("AppSettings:PathPrincipal")}/{infoProj.countryName}/Infraestructura/{infoProj.projectName}/MACRO-{infoProj.projectName.ToUpper()}";

            if (File.Exists($"{mainPath}.svg")) 
                macroResp.UrlSVG = $"/{infoProj.countryName}/Infraestructura/{infoProj.projectName}/MACRO-{infoProj.projectName.ToUpper()}.svg";
            else
                macroResp.UrlSVG = "Not found";

            if (File.Exists($"{mainPath}.drawio"))
                macroResp.UrlVisio = $"/{infoProj.countryName}/Infraestructura/{infoProj.projectName}/MACRO-{infoProj.projectName.ToUpper()}.drawio";
            else
                macroResp.UrlVisio = "Not found";

            return macroResp;
        }
    }
}
