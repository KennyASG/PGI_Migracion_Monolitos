#pragma warning disable IDE0290
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using API_PortalDocumentacion.Repository.IRepository;
using API_PortalDocumentacion.Tools;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using XAct;

namespace API_PortalDocumentacion.Repository
{
    public class ContentLLRepository : IContentRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;
        public IConfiguration _configuration;
        public EmailSender emailSender = new();

        //Class constructor
        public ContentLLRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration)
        {
            _dbContext = dbContext;
            _configuration = configuration;
        }

        //Function GetDataDiagrams, get the path of the diagrams.
        public async Task<DataDiagramLLDTO> GetDataDiagrams(int diagramId, string? corporate = null, int? elementID = 0)
        {
            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var diagramContent = await (from d in _dbContext.Diagrams
                                            join f in _dbContext.FileExtensions on d.FeId equals f.FeId
                                            where d.DiagramId == diagramId
                                            select new
                                            {
                                                FilePath = d.FilePath+ (d.Version > 1 ? "-v"+d.Version:"") + f.Extension,
                                                SVGPath = d.FilePath + (d.Version > 1 ? "-v" + d.Version : "") + ".svg",
                                                d.CreationDate,
                                                d.UpdateDate
                                            }).FirstOrDefaultAsync();

                if (diagramContent == null) return null;

                var systemsUsed_Query = await (from d in _dbContext.Details
                                               join s in _dbContext.Systems on d.SystemId equals s.SystemId
                                               join e in _dbContext.Elements on d.ElementId equals e.ElementId
                                               join et in _dbContext.ElementTypes on e.ElementTypeId equals et.ElementTypeId
                                               where d.DiagramId == diagramId
                                               orderby d.Version, s.System1
                                               select new
                                               {
                                                   Version = d.Version,
                                                   System = s.System1,
                                                   ElementType = et.ElementType1,
                                                   Element = e.Element1
                                               }).ToListAsync();

                var diagramVersionsContent = await (from i in _dbContext.Installations
                                                   join it in _dbContext.InstallTypes on i.InstallTypeId equals it.InstallTypeId
                                                   where i.DiagramId == diagramId
                                                   && i.Active == true
                                                   orderby i.Version
                                                   select new DiagramVersion
                                                   {
                                                       Version = i.Version,
                                                       InstallationNumber = i.InstallationNumber ?? null,
                                                       InstallationType = it.InstallType1,
                                                       InstallationDate = i.InstallationDate ?? null,
                                                       UpdateDate = i.CreationDate ?? null
                                                   }).ToListAsync();

                //Insertar primer versión en el listado de versiones
                DiagramVersion initialVersion = new()
                {
                    Version = 1,
                    InstallationNumber = null,
                    InstallationType = "Versión inicial",
                    InstallationDate = diagramContent.CreationDate ?? null,
                    UpdateDate = diagramContent.CreationDate ?? null
                };
                diagramVersionsContent.Insert(0, initialVersion);

                transaction.Commit();

                //Preparar los elementos de cada versión
                foreach(var version in diagramVersionsContent)
                {
                    var versionResult = systemsUsed_Query
                    .Filter(x => x.Version == version.Version)
                    .GroupBy(x => x.System)
                    .Select(g => new SystemUsedDTO
                    {
                        System = g.Key,
                        ElementType = g.GroupBy(x => x.ElementType)
                                        .Select(et => new ElementTypeDto
                                        {
                                            ElementType = et.Key,
                                            Elements = et.Select(x => x.Element).ToList()
                                        })
                                        .ToList()
                    })
                    .ToList();
                    version.SystemsUsed = versionResult;

                    //Obtener Filepath y reemplazar por la versión correspondiente
                    MatchCollection matches = Regex.Matches(diagramContent.FilePath, "-v\\d+.");
                    if (matches.Count > 0)
                    {
                        string versionValue = version.Version > 1 
                            ? $"-v{version.Version}."
                            : ".";
                        Match lastMatch = matches[matches.Count - 1];
                        version.FilePath = diagramContent.FilePath
                            .Remove(lastMatch.Index, lastMatch.Length)
                            .Insert(lastMatch.Index, versionValue);
                        version.SvgPath = diagramContent.SVGPath
                            .Remove(lastMatch.Index, lastMatch.Length)
                            .Insert(lastMatch.Index, versionValue);
                    }
                    else
                    {
                        version.FilePath = diagramContent.FilePath;
                        version.SvgPath = diagramContent.SVGPath;
                    }
                }
                

                if (corporate != null && elementID != null)
                {
                    SearchHistory searchHistory = new()
                    {
                        Corporate = corporate,
                        DiagramId = diagramId,
                        ElementId = elementID
                    };

                    _dbContext.SearchHistories.Add(searchHistory);
                    _dbContext.SaveChanges();
                }
                DataDiagramLLDTO responseDTO = new()
                {
                    FilePath = diagramContent.FilePath,
                    SVGPath = diagramContent.SVGPath,
                    CreationDate = diagramContent.CreationDate,
                    UpdateDate = diagramContent.UpdateDate,
                    LastVersion = diagramVersionsContent.ElementAt(diagramVersionsContent.Count - 1).Version,
                    Versions = diagramVersionsContent,
                    SystemsUsed = diagramVersionsContent.ElementAt(diagramVersionsContent.Count - 1).SystemsUsed
                };

                return responseDTO;
            }
        }

        //Function SearchMatch, recibe two strings (searchedWord and corporate) and return a list.
        public async Task<List<SearchMatchResult>> SearchMatch(string searchedWord, string corporate)
        {
            var searchedWordParam = new SqlParameter("@searchedWord", searchedWord);
            var corporateParam = new SqlParameter("@corporate", corporate);

            // Llamar al procedimiento almacenado usando FromSqlRaw
            var results = await _dbContext.Set<SearchMatchResult>()
                .FromSqlRaw("EXEC [dbo].[SearchMatchLL] @searchedWord, @corporate", searchedWordParam, corporateParam)
                .ToListAsync();

            return results;
        }

        public async Task<List<DetailedSearchMatchResult>> DetailedSearchMatch(BodyDetailedSearchDTO bdsDTO)
        {
            var searchedWordParam = new SqlParameter("@searchedWord", bdsDTO.searchedWord);
            var corporateParam = new SqlParameter("@corporate", bdsDTO.corporate);
            var projectParam = new SqlParameter("@project", bdsDTO.project);
            var moduleParam = new SqlParameter("@module", bdsDTO.module);
            var systemParam = new SqlParameter("@system", bdsDTO.system);
            var diagramParam = new SqlParameter("@DiagramId", bdsDTO.diagram);
            var elementTypeParam = new SqlParameter("@ElementTypeId", bdsDTO.elementType);

            // Llamar al procedimiento almacenado usando FromSqlRaw
            var results = await _dbContext.Set<DetailedSearchMatchResult>()
                .FromSqlRaw("EXEC [dbo].[DetailedMatchSearch] @searchedWord, @corporate, @project, @module, @system, @DiagramId, @ElementTypeId"
                , searchedWordParam
                ,corporateParam
                ,projectParam
                ,moduleParam
                ,systemParam
                ,diagramParam
                ,elementTypeParam)
                .ToListAsync();

            return results;
        }

        public async Task<List<Project>> GetProjectsByCorp(string corporate)
        {
            var Projects_Query = await (from p in _dbContext.Projects
                                           join per in _dbContext.Permissions on p.ProjectId equals per.ProjectId                                           
                                           where per.Corporate == corporate && per.Active == true 
                                           orderby p.ProjectId
                                           select new
                                           {
                                               p.ProjectId,
                                               project = p.Project1,
                                               p.LayerId 
                                           }).ToListAsync();
            List<Project> Projects = new List<Project>();
            foreach (var project in Projects_Query) {
                Project p = new()
                {
                    Project1 = project.project,
                    ProjectId = project.ProjectId,
                    LayerId = project.LayerId
                };
                Projects.Add(p);                    
            }
            return Projects;
        }

        public async Task<List<Module>> GetModuleByProject(int projectId)
        {
            var Modules_Query = await (from m in _dbContext.Modules
                                        join p in _dbContext.Projects on m.ProjectId equals p.ProjectId
                                        where p.ProjectId == projectId
                                        orderby p.ProjectId
                                        select new
                                        {
                                            m.ModuleId,
                                            m.ModuleName
                                        }).ToListAsync();

            List<Models.Portal.Module> modules = new List<Models.Portal.Module>();
            foreach (var module in Modules_Query)
            {
                Models.Portal.Module m = new()
                {
                    ModuleName = module.ModuleName,
                    ModuleId = module.ModuleId
                };
                modules.Add(m);
            }
            return modules;
        }

        public async Task<List<Models.Portal.System>> GetSystemByModule(int moduleId)
        {
            var systems_Query = await (from s in _dbContext.Systems
                                        join de in _dbContext.Details on s.SystemId equals de.SystemId
                                        join d in _dbContext.Diagrams on de.DiagramId equals d.DiagramId
                                        join m in _dbContext.Modules on d.ModuleId equals m.ModuleId
                                        where m.ModuleId == moduleId
                                        orderby s.System1
                                        select new
                                        {
                                          s.SystemId,
                                          system = s.System1
                                        }).ToListAsync();

            var systemsDistincs = systems_Query.Distinct();
            List<Models.Portal.System> systems = new List<Models.Portal.System>();
            foreach (var system in systemsDistincs)
            {
                Models.Portal.System m = new()
                {
                    SystemId = system.SystemId,
                    System1 = system.system
                };
                systems.Add(m);
            }
            return systems;
        }


        //Get all projects
        public async Task<List<Project>> GetProjects() => await _dbContext.Projects.Where(p => p.Active == true && p.SpId == 4).ToListAsync();

        //Function SubmitRequest
        public string SubmitRequest(SubmitRequest submitRequest)
        {
            if (submitRequest == null) return "No Contenido";

            string SystemNames, bodyMessage;
            StringBuilder sb = new();
            StringBuilder userInformation = new();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                var isRequesting = _dbContext.SystemRequests.Any(u => u.Corporate == submitRequest.Corporate & u.Authorized == null & u.Active == true);

                if (!isRequesting)
                {
                    try
                    {
                        SystemRequest systemRequest = new()
                        {
                            Corporate = submitRequest.Corporate,
                            Email = submitRequest.Email,
                            UserInformation = string.Format("{0} {1}; {2}; {3}; {4}",
                            submitRequest.Names,
                            submitRequest.Surnames,
                            submitRequest.Department,
                            submitRequest.Job,
                            submitRequest.CountryId)
                        };

                        _dbContext.SystemRequests.Add(systemRequest);
                        _dbContext.SaveChanges();

                        foreach (var items in submitRequest.RequestSystem)
                        {
                            var idSR = _dbContext.SystemRequests.FirstOrDefault(s => s.Corporate == submitRequest.Corporate & s.Authorized == null & s.Active == true);

                            SystemRequestDetail systemRequestDetail = new()
                            {
                                SrId = idSR.SrId,
                                ProjectId = items.Id
                            };

                            if (sb.Length > 0) sb.Append(", ");
                            sb.Append(items.displayText);
                            _dbContext.SystemRequestDetails.Add(systemRequestDetail);
                            _dbContext.SaveChanges();
                        }

                        transaction.Commit();

                        SystemNames = sb.ToString();

                        string projectPath = AppContext.BaseDirectory;
                        string fullPath = Path.Combine(projectPath, "Content", "TemplatesHTML", "PlantillaSOLICITUDACCESO.html");

                        try
                        {
                            bodyMessage = File.ReadAllText(fullPath);
                            bodyMessage = bodyMessage.Replace("[FULLNAME]", (submitRequest.Names + " " + submitRequest.Surnames))
                                                     .Replace("[CORPORATE]", submitRequest.Corporate)
                                                     .Replace("[DEPARMENT]", submitRequest.Department)
                                                     .Replace("[EMAIL]", submitRequest.Email)
                                                     .Replace("[JOB]", submitRequest.Job)
                                                     .Replace("[SYSTEMS]", SystemNames)
                                                     .Replace("[DOMAIN]", _configuration.GetValue<string>("Domain:URL"));
                        }
                        catch { return "Ha ocurrido un error"; }

                        emailSender.EmailSend(_configuration.GetValue<string>("EmailSenderSettings:EmailReceiver"), "SOLICITUD DE ACCESO Y PERMISOS PARA PORTAL DE DOCUMENTACIÓN TI", bodyMessage, _configuration);

                        return "Exito";

                    }
                    catch { return "Ha ocurrido un error"; }
                }
                else
                {
                    return "En Proceso";
                }
            }
        }

        public async Task<List<SearchMatchResult>> ReturnHistory(string corporate)
        {
            var corporateParam = new SqlParameter("@corporate", corporate);

            // Llamar al procedimiento almacenado usando FromSqlRaw
            var results = await _dbContext.Set<SearchMatchResult>()
                .FromSqlRaw("EXEC [dbo].[SearchHistoryUser] @corporate",corporateParam)
                .ToListAsync();

            return results;

        }

        public async Task<List<ElementType>> GetElementTypeByCorp(string corporate)
        {
            var corporateParam = new SqlParameter("@corporate", corporate);

            var ElementTypesQuery = await _dbContext.Set<ElementType>()
                .FromSqlRaw("EXEC [dbo].[GetElementTypeByCorporate] @corporate", corporateParam)
                .ToListAsync();

            List<ElementType> results = [];
            foreach (var elementType in ElementTypesQuery)
            {
                ElementType et = new()
                {
                    ElementTypeId = elementType.ElementTypeId,
                    ElementType1 = elementType.ElementType1
                };
                results.Add(et);
            }

            return results;
        }

        //Get all projects by country's user
        public async Task<List<Project>> GetProjects(int countryId) => await _dbContext.Projects.Where(p => p.CountryId == countryId && p.Active == true && p.SpId == 4).ToListAsync();
    }
}
