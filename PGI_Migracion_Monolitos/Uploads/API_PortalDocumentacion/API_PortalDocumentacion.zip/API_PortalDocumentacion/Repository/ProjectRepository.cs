using API_PortalDocumentacion.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using XAct;

namespace API_PortalDocumentacion.Repository
{
    public class ProjectRepository : IProjectRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;
        public IConfiguration _configuration;

        //Class constructor
        public ProjectRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration)
        {
            this._dbContext = dbContext;
            this._configuration = configuration;
        }

        public string CreateProject(CreateProjectModel createProjModel)
        {
            List<ProjectCollaborator> collaboratorsToAdd = new();
            int projectId = 0, moduleId = 0, optionId = 0;

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            try
            {
                    //Buscar si el proyecto ya existe
                    var existingProject = _dbContext.Projects.SingleOrDefault(p => p.Project1 == createProjModel.ProjectName && p.CountryId == createProjModel.CountryId && p.LayerId == createProjModel.LayerId && p.CId == createProjModel.ClassificationId && p.Active == true);

                    if (existingProject != null) return "Proyecto existente.";

                // Crear nuevo proyecto si no existe
                var newProject = new Project()
                {
                    Project1 = createProjModel.ProjectName,
                    CId = createProjModel.ClassificationId,
                    LayerId = createProjModel.LayerId,
                    CountryId = createProjModel.CountryId,
                    SpId = 1
                };

                _dbContext.Projects.Add(newProject);
                _dbContext.SaveChanges();

                projectId = newProject.ProjectId;

                foreach (var item in createProjModel.modules)
                {
                    var existingModule = _dbContext.Modules.SingleOrDefault(p => p.ModuleName == item.ModuleName && p.ProjectId == newProject.ProjectId && p.Active == true);

                    if (existingModule != null) return "Modulo existente.";

                    var newModule = new Module() { ModuleName = item.ModuleName, ProjectId = projectId, SpId = 1 };

                    _dbContext.Modules.Add(newModule);
                    _dbContext.SaveChanges();

                    moduleId = newModule.ModuleId;

                    foreach (var item2 in item.Diagram)
                    {
                        Diagram diagram;

                        var existingDiagram = _dbContext.Diagrams.SingleOrDefault(p => p.Diagram1 == item2.DiagramName && p.ModuleId == newModule.ModuleId && p.Active == true);

                        if (existingModule != null) return "Diagrama existente.";

                        if (item2.OptionName != "")
                        {
                            var existingOption = _dbContext.Options.SingleOrDefault(p => p.OptionName == item2.OptionName && p.ModuleId == newModule.ModuleId && p.Active == true);
                            
                            if (existingOption == null) 
                            {
                                var newOption = new Option() { OptionName = item2.OptionName, ModuleId = moduleId, SpId = 1 };

                                _dbContext.Options.Add(newOption);
                                _dbContext.SaveChanges();
                                optionId = newOption.OptionId;
                            } 
                            else
                            {
                                optionId = existingOption.OptionId;
                            }
                        } else { optionId = 0; }

                        if (optionId != 0)
                            { diagram = new() { Diagram1 = item2.DiagramName, ModuleId = moduleId, OptionId = optionId, SpId = 1 }; }
                            else
                            { diagram = new() { Diagram1 = item2.DiagramName, ModuleId = moduleId, SpId = 1 }; }

                        _dbContext.Diagrams.Add(diagram);
                        _dbContext.SaveChanges();
                    }
                }

                if (createProjModel.AssignDocumenters?.Any() == true)
                {
                    foreach (var item in createProjModel.AssignDocumenters)
                    {
                        collaboratorsToAdd.Add(new ProjectCollaborator
                        {
                            ProjectId = projectId,
                            Corporate = item
                        });

                        _dbContext.ProjectCollaborators.AddRange(collaboratorsToAdd);
                    }
                    _dbContext.SaveChanges();
                }

                transaction.Commit();
                return "EXITO";
            }
            catch {
                transaction.Rollback();
                return null;
            }
        }

        public string UpdateProject(UpdateCreateProjectModel updateCreateProjModel)
        {
            List<ProjectCollaborator> listProjColl = new List<ProjectCollaborator>();
            var deletedOptions = new HashSet<int>();
            var modifiedOptions = new HashSet<int>();

            using (var transaction = _dbContext.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                try
                {
                    // Buscar el proyecto
                    var _project = _dbContext.Projects
                        .SingleOrDefault(p => p.ProjectId == updateCreateProjModel.ProjectId && p.Active == true);

                    if (_project == null) return "Proyecto no encontrado.";

                    if (updateCreateProjModel.State == 1) // Modificar proyecto
                    {
                        _project.Project1 = updateCreateProjModel.ProjectName;
                        _project.CId = updateCreateProjModel.ClassificationId;
                        _project.LayerId = updateCreateProjModel.LayerId;
                        _dbContext.SaveChanges();
                    }

                    // PROCESAR MÓDULOS
                    foreach (var item in updateCreateProjModel.Modules)
                    {
                        int moduleId = 0;
                        Module _module = null;

                        if (item.State != 3)
                        {
                            _module = _dbContext.Modules.SingleOrDefault(p => p.ModuleId == item.ModuleId && p.ProjectId == updateCreateProjModel.ProjectId && p.Active == true);
                            moduleId = item.ModuleId;
                            if (_module == null) return $"El módulo {item.ModuleName} no fue encontrado.";
                        }

                        switch (item.State)
                        {
                            case 1: //Module modified
                                _module.ModuleName = item.ModuleName;
                                _dbContext.SaveChanges();
                                break;
                            case 2: //Module deleted
                                var options = _dbContext.Options.Where(o => o.ModuleId == item.ModuleId && o.Active == true).ToList();
                                var diagrams = _dbContext.Diagrams.Where(d => d.ModuleId == item.ModuleId && d.Active == true).ToList();

                                if (_project.SpId != 1)
                                {
                                    _module.Active = false;
                                    options.ForEach(o => o.Active = false);
                                    diagrams.ForEach(d => d.Active = false);
                                }
                                else
                                {
                                    _dbContext.Diagrams.RemoveRange(diagrams);
                                    _dbContext.Options.RemoveRange(options);
                                    _dbContext.Modules.Remove(_module);
                                }

                                _dbContext.SaveChanges();
                                break;
                            case 3: //New module
                                if (_module != null) return $"El módulo {item.ModuleName} ya existe.";

                                var newModule = new Module()
                                {
                                    ModuleName = item.ModuleName,
                                    ProjectId = updateCreateProjModel.ProjectId,
                                    SpId = 1
                                };

                                _dbContext.Modules.Add(newModule);
                                _dbContext.SaveChanges();
                                moduleId = newModule.ModuleId;
                                break;
                        }

                        // PROCESAR OPCIONES Y DIAGRAMAS
                        foreach (var item2 in item.OptAndDiag)
                        {
                            int optionId = 0;
                            Option _option = null;

                            if (item2.StateOpt != 0)
                            {
                                if (deletedOptions.Contains(item2.OptionId.Value)) continue;

                                if (item2.StateOpt == 1)
                                    _option = _dbContext.Options.SingleOrDefault(o => o.OptionId == item2.OptionId && o.ModuleId == moduleId);
                                else
                                    _option = _dbContext.Options.SingleOrDefault(o => o.OptionName == item2.OptionName && o.ModuleId == moduleId);

                                if (_option == null && item2.StateOpt != 3) return $"La opción {item2.OptionName} no fue encontrada.";
                            }

                            switch (item2.StateOpt)
                            {
                                case 1: //Option modified
                                    if (!modifiedOptions.Contains(_option.OptionId)) // Solo eliminar si no ha sido eliminado antes
                                    {
                                        _option.OptionName = item2.OptionName;
                                        _dbContext.SaveChanges();
                                        modifiedOptions.Add(_option.OptionId);
                                    }
                                    optionId = _option.OptionId;
                                    break;
                                case 2: //Option deleted
                                    if (!deletedOptions.Contains(_option.OptionId)) // Solo eliminar si no ha sido eliminado antes
                                    {
                                        var connectedDiagrams = _dbContext.Diagrams.Where(d => d.OptionId == _option.OptionId && d.Active == true).ToList();
                                        if (_project.SpId != 1)
                                        {
                                            _option.Active = false;
                                            foreach(var diagram in connectedDiagrams)
                                            {
                                                diagram.Active = false;
                                            }
                                        }
                                        else
                                        {
                                            if (connectedDiagrams != null && connectedDiagrams.Count != 0) _dbContext.Diagrams.RemoveRange(connectedDiagrams);
                                            _dbContext.Options.Remove(_option);
                                        }
                                        _dbContext.SaveChanges();
                                        deletedOptions.Add(_option.OptionId);
                                    }
                                    break;
                                case 3:
                                    if (_option == null)
                                    {
                                        optionId = 0;

                                        var newOption = new Option()
                                        {
                                            OptionName = item2.OptionName,
                                            ModuleId = moduleId,
                                            SpId = 1
                                        };

                                        _dbContext.Options.Add(newOption);
                                        _dbContext.SaveChanges();
                                        optionId = newOption.OptionId;
                                    }
                                    else
                                    {
                                        optionId = _option.OptionId;
                                    }
                                    break;
                            }

                            if (deletedOptions.Contains(optionId)) continue;

                            // PROCESAR DIAGRAMAS

                            var _diagram = new Diagram();
                            if (!new[] { 3, 0 }.Contains(item2.StateDiag))
                            {
                                _diagram = _dbContext.Diagrams.SingleOrDefault(d => d.DiagramId == item2.DiagramId && d.ModuleId == moduleId);
                                if (_diagram == null) return $"El diagrama {item2.DiagramName} no fue encontrado.";
                            }

                            switch (item2.StateDiag)
                            {
                                case 1: //Diagram modified
                                    _diagram.Diagram1 = item2.DiagramName;
                                    _dbContext.SaveChanges();
                                    break;
                                case 2://Diagram deleted 
                                    if (_project.SpId != 1)
                                    {
                                        _diagram.Active = false;
                                    }
                                    else
                                    {
                                        _dbContext.Diagrams.Remove(_diagram);
                                        _dbContext.SaveChanges();
                                    }

                                    break;
                                case 3://New diagram
                                    var newDiag = new Diagram()
                                    {
                                        Diagram1 = item2.DiagramName,
                                        ModuleId = moduleId,
                                        OptionId = optionId > 0 ? optionId : null,
                                        SpId = 1
                                    };

                                    _dbContext.Diagrams.Add(newDiag);
                                    _dbContext.SaveChanges();
                                    break;
                            }
                        }
                    }

                    // PROCESAR COLABORADORES
                    foreach (var item in updateCreateProjModel.AssignDocumenters)
                    {
                        var _projCollaborator = _dbContext.ProjectCollaborators
                            .SingleOrDefault(pc => pc.Corporate == item.Corporate && pc.ProjectId == updateCreateProjModel.ProjectId);

                        if (_projCollaborator != null && item.State == 3)
                            return $"El colaborador {item.Corporate} ya está asignado al proyecto.";

                        switch (item.State)
                        {
                            case 2: // Eliminar colaborador
                                _dbContext.ProjectCollaborators.Remove(_projCollaborator);
                                _dbContext.SaveChanges();
                                break;

                            case 3: // Nuevo colaborador
                                listProjColl.Add(new ProjectCollaborator
                                {
                                    ProjectId = updateCreateProjModel.ProjectId,
                                    Corporate = item.Corporate
                                });
                                break;
                        }
                    }

                    if (listProjColl.Count > 0)
                    {
                        _dbContext.ProjectCollaborators.AddRange(listProjColl);
                        _dbContext.SaveChanges();
                    }

                    transaction.Commit();
                    return "ÉXITO";
                }
                catch
                {
                    transaction.Rollback();
                    return "ERROR";
                }
            }
        }

        public async Task<List<ReturnDocumentersModel>> GetListDocumenters()
        {
            List<ReturnDocumentersModel> listDocumenters = new();

            try
            {
                var query = await (from ur in _dbContext.UserRoles
                                   join u in _dbContext.Users on ur.Corporate equals u.Corporate
                                   where ur.RoleId == 3 && ur.Active == true
                                   select new
                                   {
                                       corporate = u.Corporate,
                                       name = u.Names + " " + u.Surnames
                                   }).Distinct().ToListAsync();

                if (query == null) return null;

                foreach (var item in query)
                {
                    ReturnDocumentersModel rdModel = new()
                    {
                        corporate = item.corporate,
                        name = item.name
                    };
                    listDocumenters.Add(rdModel);
                }
            }
            catch{ 
                return null; 
            };

            return listDocumenters;
        }

        public async Task<List<Classification>> GetClassifications() => await _dbContext.Classifications.ToListAsync();

        public async Task<List<Layer>> GetLayers() => await _dbContext.Layers.ToListAsync();

        public List<GetProModOptDiag> GetProjectsAndDocumenters()
        {
            var query = $"EXEC GetProModOptDiag";
            List<GetProModOptDiag> listPMOD = _dbContext.Set<GetProModOptDiag>().FromSqlRaw(query).ToList();

            var projCollab =
                (from p in _dbContext.Projects
                 join pc in _dbContext.ProjectCollaborators on p.ProjectId equals pc.ProjectId
                 join u in _dbContext.Users on pc.Corporate equals u.Corporate
                 where pc.Active == true
                 select new ProjectCollaboratorsModel
                 {
                     ProjectId = p.ProjectId,
                     Corporate = pc.Corporate,
                     FullName = u.Names + " " + u.Surnames
                 })
                .Distinct()
                .ToList();

            var structuredProModOptDiagCollab = BuildMenuTree(listPMOD, projCollab);


            return structuredProModOptDiagCollab;
        }

        public List<GetProModOptDiag> BuildMenuTree(List<GetProModOptDiag> projAndDoctrsItems, List<ProjectCollaboratorsModel> projCollaborators)
        {
            var PMODMap = new Dictionary<int, GetProModOptDiag>();
            var rootItems = new List<GetProModOptDiag>();

            // Map all items by their ID
            foreach (var item in projAndDoctrsItems)
            {
                PMODMap[item.Id] = item;
            }

            // Build the tree structure
            foreach (var item in projAndDoctrsItems)
            {
                //Si el padre es nulo, es proyecto
                if (item.ParentId == null)
                {
                    rootItems.Add(item);
                    //Colaboradores asignados al proyecto
                    var projColl = projCollaborators.Where(p => p.ProjectId == item.ProjectId).ToList();
                    foreach (var item2 in projColl)
                    {
                        item.Collaborators.Add(item2);
                    }
                }
                else
                {
                    //Módulos, Diagramas y Opciones
                    if (PMODMap.TryGetValue(item.ParentId.Value, out var parentPMODItem))
                    {
                        parentPMODItem.Children.Add(item);
                    }
                }
            }
            return rootItems;
        }

        public string DeleteProjects(DeleteProjectModel delProjModel)
        {
            try
            {
                var project = _dbContext.Projects.FirstOrDefault(p => p.ProjectId == delProjModel.ProjectId);
                //ERROR, no project found / received
                if (project == null) return null;

                //Obtención de elementos comunes en ambos flujos
                var modules = _dbContext.Modules.Where(m => m.ProjectId == delProjModel.ProjectId && m.Active == true).ToList();

                var options = _dbContext.Options
                        .Where(o => _dbContext.Modules
                            .Where(m => m.ProjectId == delProjModel.ProjectId)
                            .Select(m => m.ModuleId)
                            .Contains(o.ModuleId ?? 0)
                            && o.Active == true)
                        .ToList();
                
                var diagrams = _dbContext.Diagrams
                        .Where(d => _dbContext.Modules
                            .Where(m => m.ProjectId == delProjModel.ProjectId)
                            .Select(m => m.ModuleId)
                            .Contains(d.ModuleId ?? 0)
                            && d.Active == true)
                        .ToList();


                var collaborators = _dbContext.ProjectCollaborators
                    .Where(pc => pc.ProjectId == delProjModel.ProjectId && pc.Active == true)
                    .ToList();

                //Flujo SP != 1, se desactiva
                if (project.SpId != 1)
                {
                    if (project.Active == false) return "ERROR";

                    project.Active = false;
                    
                    foreach (Module module in modules)
                        module.Active = false;
                    
                    foreach (var diagram in diagrams)
                        diagram.Active = false;
                    
                    foreach (var o in options)
                        o.Active = false;

                    foreach (ProjectCollaborator collaborator in collaborators)
                        collaborator.Active = false;
                    

                    var matrices = _dbContext.Matrices
                        .Where(m => _dbContext.Diagrams
                            .Where(d => _dbContext.Modules
                                .Where(m => m.ProjectId == delProjModel.ProjectId)
                                .Select(m => m.ModuleId)
                                .Contains(d.ModuleId ?? 0)
                            )
                            .Select(d => d.DiagramId)
                            .Contains(m.DiagramId)
                            && m.Active == true)
                        .ToList();

                    foreach (var matrix in matrices)
                        matrix.Active = false;

                    // Details
                    var details = _dbContext.Details.Where(d => _dbContext.Diagrams
                            .Where(d => _dbContext.Modules
                                .Where(m => m.ProjectId == delProjModel.ProjectId)
                                .Select(m => m.ModuleId)
                                .Contains(d.ModuleId ?? 0)
                            )
                            .Select(d => d.DiagramId)
                            .Contains(d.DiagramId)
                            && d.Active == true)
                        .ToList();

                    foreach (var detail in details)
                        detail.Active = false;

                    // Connections
                    var connections = _dbContext.Connections.Where(c => _dbContext.Diagrams
                            .Where(d => _dbContext.Modules
                                .Where(m => m.ProjectId == delProjModel.ProjectId)
                                .Select(m => m.ModuleId)
                                .Contains(d.ModuleId ?? 0)
                            )
                            .Select(d => d.DiagramId)
                            .Contains(c.DiagramId)
                            && c.Active == true)
                        .ToList();

                    foreach (var connection in connections)
                        connection.Active = false;
                }
                else
                {
                    //Flujo SP == 1, se borra

                    //Borrar colaboradores
                    _dbContext.ProjectCollaborators.RemoveRange(collaborators);
                    //Borrar diagramas
                    _dbContext.Diagrams.RemoveRange(diagrams);
                    //Borrar opciones
                    _dbContext.Options.RemoveRange(options);
                    //Borrar módulos
                    _dbContext.Modules.RemoveRange(modules);
                    //Borrar proyecto
                    _dbContext.Projects.Remove(project);
                }

                _dbContext.SaveChanges();
                return "¡Elementos eliminados exitosamente!";
            }
            catch
            {
                return null;
            }
        }

        public string CreateMatrix(CreateMatrixModel createMatrixModel)
        {
            if (createMatrixModel.DiagramId == 0)
            {
                return "ERROR: Debe utilizar un diagrama existente";
            }

            var existentMatrix = _dbContext.Matrices.FirstOrDefault(m => m.DiagramId == createMatrixModel.DiagramId && m.Active == true);
            if (existentMatrix != null)
            {
                return "ERROR: Ya existe una matriz para el diagrama seleccionado";
            }

            try
            {
                //Default templateId
                int templateId = 1;

                //Search for template
                if (createMatrixModel.ProjectId != null && createMatrixModel.ProjectId != 0)
                {
                    var templateProject = _dbContext.Projects.FirstOrDefault(p => p.ProjectId == createMatrixModel.ProjectId);
                    
                    if (templateProject != null)
                    {

                        var matrixTemplate = _dbContext.MatrixTemplates
                            .FirstOrDefault(mt => mt.ProjectId == templateProject.ProjectId);
                        if(matrixTemplate != null)
                        {
                            templateId = matrixTemplate.MtemplateId;
                        }
                    }
                }

                Matrix matrix = new() { DiagramId = createMatrixModel.DiagramId, HasDynatrace = (!createMatrixModel.HasDynatrace.IsNull() && createMatrixModel.HasDynatrace == true), Active = true };
                _dbContext.Matrices.Add(matrix);
                _dbContext.SaveChanges();

                var matrixId = _dbContext.Matrices
                    .Where(m => m.DiagramId == createMatrixModel.DiagramId)
                    .Select(m => m.MatrixId)
                    .FirstOrDefault();

                var matrixTemplateDetails = _dbContext.MatrixTemplateDetails
                    .Where(mtd => mtd.MtemplateId == templateId)
                    .ToList();
                
                foreach (var item in matrixTemplateDetails)
                {
                    MatrixDetail matrixDetail = new() { MatrixId = matrixId, MoptionId = item.MoptionId};
                    _dbContext.MatrixDetails.Add(matrixDetail);
                }

                //El diagrama pasa a estar en SP_ID = 2, en proceso
                var diagram = _dbContext.Diagrams.FirstOrDefault(d => d.DiagramId == createMatrixModel.DiagramId);
                if (diagram != null)
                {
                    if(diagram.SpId == 1) diagram.SpId = 2;
                } 

                //Revisar los padres, pasarlos a en proceso
                var option = _dbContext.Options.FirstOrDefault(o => o.OptionId == diagram.OptionId);
                if (option != null)
                {
                    if (option.SpId == 1) option.SpId = 2;
                }
                //Module y project no pueden ser null
                var module = _dbContext.Modules.FirstOrDefault(m => m.ModuleId == diagram.ModuleId);
                if (module.SpId == 1) module.SpId = 2;

                var project = _dbContext.Projects.FirstOrDefault(p => p.ProjectId == module.ProjectId);
                if (project.SpId == 1) project.SpId = 2;

                _dbContext.SaveChanges();

                return "Matriz creada con éxito";
            }
            catch
            {
                return null;
            }
        }

        public string UpdateMatrix(UpdateMatrixModel updateMatrixModel)
        {
            if(updateMatrixModel.MatrixId == 0 || updateMatrixModel.DiagramId == 0)
            {
                return "ERROR: Los ids de la matriz y del diagrama a actualizar son requerido";
            }

            var matrix = _dbContext.Matrices.FirstOrDefault(m => m.MatrixId ==  updateMatrixModel.MatrixId && (m.Active == null || m.Active == true));
            
            if (matrix == null) {
                return "ERROR: No se ha encontrado la matriz indicada";
            }

            if (updateMatrixModel.UpdatedDetails == null || updateMatrixModel.UpdatedDetails.Count == 0) {
                return "ERROR: No hay detalles de la matriz para actualizar";
            }

            try
            {
                //Update Has Dynatrace
                if(updateMatrixModel.HasDynatrace != null && updateMatrixModel.HasDynatrace != matrix.HasDynatrace)
                {
                    matrix.HasDynatrace = (updateMatrixModel.HasDynatrace == true);
                }
                //Get matrix details for selected matrix, and update current completition percentage
                var detailsToUpdate = _dbContext.MatrixDetails.Where(md => md.MatrixId == matrix.MatrixId).ToList();
                int currentPercentage = 0;
                foreach (MatrixDetail detail in detailsToUpdate)
                {
                    var receivedDetail = updateMatrixModel.UpdatedDetails.Where(i => i.Id == detail.MdId).FirstOrDefault();

                    //If detail is found, update field
                    if (receivedDetail != null)
                    {
                        if(detail.Status != receivedDetail.Status)
                        {
                            detail.Status = receivedDetail.Status;
                            detail.LastUpdate = DateTime.Now;
                        }
                    }

                    // 1 - No terminado
                    // 2 - Terminado
                    // 3 - No aplica
                    if (detail.Status == 2 || detail.Status == 3)
                    {
                        currentPercentage += (matrix.HasDynatrace == true)
                            ? _dbContext.MatrixOptions.Where(o => o.MoptionId == detail.MoptionId).Select(s => s.ScoreDynatrace).FirstOrDefault()
                            : _dbContext.MatrixOptions.Where(o => o.MoptionId == detail.MoptionId).Select(s => s.ScoreNoDynatrace).FirstOrDefault();
                    }
                }

                //Update matrix percentage
                matrix.Percentage = currentPercentage;
                if (matrix.Active.IsNull())
                {
                    matrix.Active = true;
                }

                if(currentPercentage >= 100)
                {
                    matrix.FinishDate = DateTime.Now;
                }

                return "Matriz actualizada con éxito, avance: "+matrix.Percentage;
            }
            catch (DbUpdateException)
            {
                return null;
            }
            catch (ArgumentNullException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public GetMatrixAndDetailModel GetMatrixByDiagramId(int DiagramId)
        {
            try
            {
                var query = $"EXEC GetMatrixAndDetails {DiagramId}";
                List<MatrixDetailsModel> listMatrix = _dbContext.Set<MatrixDetailsModel>().FromSqlRaw(query).ToList();

                var structuredMatrix = BuildMatrix(listMatrix);
                try
                {

                    var diagram = _dbContext.Diagrams.FirstOrDefault(d => d.DiagramId == DiagramId);
                    if (diagram != null)
                    {
                        if (diagram.SpId == 3) structuredMatrix.HasFile = true;
                        else
                        {
                            if (diagram.FilePath != null)
                            {
                                // Verify if file exists, both in files/ and filesTemp/
                                string path = Path.GetDirectoryName(diagram.FilePath).TrimStart('\\');
                                string fileName = Path.GetFileName(diagram.FilePath);
                                var filePath = Path.Combine($@"{_configuration.GetValue<string>("AppSettings:PathPrincipal")}", path);
                                var tempPath = Path.Combine($@"{_configuration.GetValue<string>("AppSettings:PathTemp")}", path);

                                //Obtener archivos del directorio
                                if (Directory.EnumerateFiles(filePath, fileName + ".*").Any()) structuredMatrix.HasFile = true;
                                if (Directory.EnumerateFiles(tempPath, fileName + ".*").Any()) structuredMatrix.HasFile = true;
                            }
                        }
                    }
                }
                catch
                {
                    structuredMatrix.HasFile = false;
                }

                if (structuredMatrix != null && structuredMatrix.MatrixId != 0 && structuredMatrix.Details?.Count != 0)
                {
                    return structuredMatrix;
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        public GetMatrixAndDetailModel BuildMatrix(List<MatrixDetailsModel> Details)
        {
            GetMatrixAndDetailModel Matrix = new();
            Matrix.Details = [];

            foreach (var Detail in Details)
            {
                if (Detail.Level == 0)
                {
                    Matrix.MatrixId = Detail.Matrix_Id ?? 0;
                    Matrix.HasDynatrace = Detail.HasDYNA ?? false;
                    Matrix.Percentage = Detail.Percentage ?? 0;
                    Matrix.Active = (Detail.MStatus.IsNull()) ? null : (Detail.MStatus == 1 ? true : false);
                    Matrix.CreationDate = Detail.CreationDate;
                    Matrix.FinishDate = Detail.FinishDate;
                }
                else
                {
                    GetMatrixAndDetailModel.Detail newDetail = new()
                    {
                        DetailId = Detail.MD_ID ?? 0,
                        DetailName = Detail.DetailName ?? "",
                        ScoreDynatrace = (Detail.ScoreDyn ?? 0),
                        ScoreNoDynatrace = (Detail.ScoreNoDyn ?? 0),
                        UpdateDate = Detail.UpdateDate,
                        DetailStatus = Detail.MStatus,
                        StatusDescription = Detail.MStatus == 1 
                        ? "No terminado" 
                        : (Detail.MStatus == 2 
                            ? "Terminado" 
                            : "No aplica")
                    };
                    Matrix.Details?.Add(newDetail);
                }
            }

            return Matrix;
        }

        public string DiagramInstallation(InstallationModel InstallationDetails)
        {
            try
            {
                if(InstallationDetails.DiagramId == 0 || InstallationDetails.InstallationType == 0) return null;

                Diagram diagram = _dbContext.Diagrams.Where(d => d.DiagramId == InstallationDetails.DiagramId).FirstOrDefault();

                if (diagram == null) return null;

                Installation installation = new() {
                    InstallTypeId = InstallationDetails.InstallationType,
                    InstallationNumber = InstallationDetails.InstallationNumber ?? null,
                    UpdateReason = InstallationDetails.InstallationType == 4 ? InstallationDetails.UpdateReason ?? null : null,
                    InstallationDate = InstallationDetails.InstallationDate ?? null,
                    DiagramId = InstallationDetails.DiagramId,
                    Version = diagram.Version,
                    Active = true,
                    CreationDate = DateTime.Now
                };

                _dbContext.Installations.Add(installation);
                
                diagram.UpdateDate = DateTime.Now;

                _dbContext.SaveChanges();
                
                return "Instalación guardada con éxito, nueva versión: "+diagram.Version;
            }
            catch
            {
                return null;
            }
        }

        public async Task<List<InstallType>> GetInstallationTypes()
        {
            return await _dbContext.InstallTypes.Where(it => it.Active == true).ToListAsync();
        }
    }
}
