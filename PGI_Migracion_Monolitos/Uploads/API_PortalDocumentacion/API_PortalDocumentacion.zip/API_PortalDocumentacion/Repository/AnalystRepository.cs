using API_PortalDocumentacion.Repository.IRepository;
using API_PortalDocumentacion.Models.Portal;
using System.Xml.Linq;
using GroupDocs.Conversion;
using API_PortalDocumentacion.Tools;
using System.Text.RegularExpressions;

namespace API_PortalDocumentacion.Repository
{
    public class AnalystRepository : IAnalystRepository
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;
        public IConfiguration _configuration;
        public NotificationSender _notifSender;

        //Class constructor
        public AnalystRepository(DbPortalDocumentacionContext dbContext, IConfiguration configuration, NotificationSender sender)
        {
            this._dbContext = dbContext;
            this._configuration = configuration;
            this._notifSender = sender;
        }

        public string UploadDiagramaFileAsync(FileVisioModel fvisioModel)
        {
            string Response = "";

            if(fvisioModel.flag == 0 && string.IsNullOrEmpty(fvisioModel.Corporate))
            {
                return Response = "El corporativo es requerido.";
            }

            if (fvisioModel.FileVisio == null || fvisioModel.FileVisio.Length == 0)
            {
                return Response = "No se ha seleccionado un archivo.";
            }

            string extension = Path.GetExtension(fvisioModel.FileVisio.FileName);
            string[] allowedExtensions = { ".vsdx", ".drawio" };

            if (!allowedExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
            {
                return Response = "Solo se permiten archivos con extensi�n .vsdx o .drawio.";
            }
            var diagram = _dbContext.Diagrams
                            .Where(x => x.DiagramId == fvisioModel.Diagram)
                            .FirstOrDefault();

            if (diagram == null) return "El diagrama seleccionado no existe.";
            
            var option = _dbContext.Options
                            .Where(x => x.OptionId == diagram.OptionId)
                            .FirstOrDefault();

            var module = _dbContext.Modules
                            .Where(x => x.ModuleId == diagram.ModuleId)
                            .FirstOrDefault();

            var project = _dbContext.Projects
                            .Where(p => p.ProjectId == module.ProjectId)
                            .FirstOrDefault();

            var country = _dbContext.Countries
                            .Where(c => c.Id == project.CountryId)
                            .FirstOrDefault();

            string filePath = "";

            if(fvisioModel.flag == 0)
            {
                //Si es nuevo, Proyecto/M�dulo/Opci�n-Diagrama-v#
                var regex = @"[\\/:*?""<>|.\+]+";
                string cleanProject = Regex.Replace(project.Project1, regex, "-");
                string cleanModule = Regex.Replace(module.ModuleName, regex, "-");
                string cleanDiagram = Regex.Replace(diagram.Diagram1, regex, "-").ToUpper();
                string cleanOption = "";
                if (option != null) cleanOption = Regex.Replace(option.OptionName, regex, "-").ToUpper();

                if (country == null) filePath = $"/Guatemala/{cleanProject}/{cleanModule}/";
                else filePath = $"/{country.CountryName}/{cleanProject}/{cleanModule}/";
                if (option == null) filePath += $"{cleanDiagram}";
                else filePath += $"{cleanOption}-{cleanDiagram}";
            }
            else
            {
                //Si no es nuevo, Proyecto/Modulo/Diagrama-v#
                filePath = diagram.FilePath;
            }

            var version = diagram.Version;
          
            string path2 = Path.GetDirectoryName(filePath);
            var diagramName = Path.GetFileName(filePath);
            string path;
            if (fvisioModel.flag == 0)// creacion de archivos en carpeta temporal 
            {
                path = $@"{_configuration.GetValue<string>("AppSettings:PathTemp")}{path2}";
            }
            else { // creacion de archivos en carpeta principal (Creacion/Actualizacion)
                path = $@"{_configuration.GetValue<string>("AppSettings:PathPrincipal")}{path2}";
            }
           

            if (!Directory.Exists(path)) Directory.CreateDirectory(path);

            string newFileNamevsdx = $"{diagramName}{(version > 1 ? "-v" + version : "")}{extension}";
            string newFileNamesvg = $"{diagramName}{(version > 1 ? "-v" + version : "")}.svg";


            var tempFilePath = Path.Combine(path, newFileNamevsdx);
            var tempFilePathSvg = Path.Combine(path, newFileNamesvg);
            using (var stream = new FileStream(tempFilePath, FileMode.Create))
            {
                fvisioModel.FileVisio.CopyTo(stream);
            }
            // Proceed with conversion
            FluentConverter
                 .Load(tempFilePath)               // Set up input VSDX file
            .ConvertTo(tempFilePathSvg)     // Specify output path for converted file
                 .Convert();
            var svgDoc = XDocument.Load(tempFilePathSvg);
            string[] watermarkText = {
                                        "Created with",
                                        "Created with evaluation version",
                                        "GroupDocs.Conversion",
                                        "Created with evaluation version of GroupDocs.Conversion � Aspose Pty", 
                                        "All Rights Reserved.", 
                                        "Reserved." };

            // Buscar y eliminar elementos <text> que contengan el texto espec�fico
            var textElements = svgDoc.Descendants()
                                      .Where(e => (e.Name.LocalName == "text" || e.Name.LocalName == "title") &&
                                      (e.Value.Contains(watermarkText[0]) ||
                                      e.Value.Contains(watermarkText[1]) ||
                                      e.Value.Contains(watermarkText[2]) ||
                                      e.Value.Contains(watermarkText[3]) ||
                                      e.Value.Contains(watermarkText[4]) ||
                                      e.Value.Contains(watermarkText[5])
                                      ))
                                      .ToList();

            foreach (var textElement in textElements)
            {
                textElement.Remove();
            }

            svgDoc.Save(tempFilePathSvg);            
            Response = "Archivo subido correctamente.";
            if(fvisioModel.flag == 0)
            {
                //"En revisi�n"
                diagram.SpId = 3;
                diagram.FilePath = filePath;
                //Buscar FE_ID
                if(extension == ".vsdx") diagram.FeId = 1; //vsdx
                else diagram.FeId = 3; //drawio
                _dbContext.SaveChanges();
                //Notificaci�n para el administrador
                Notification notificationData = new()
                {
                    SenderCorporate = fvisioModel.Corporate,
                    ReceiverCorporate = null,
                    DestinationType = 1,
                    CreationDate = DateTime.Now,
                    IsUnread = true,
                    DiagramId = fvisioModel.Diagram,
                    NotificationStatus = 1,
                    Active = true
                };

                _notifSender.CreateNotification(notificationData);
            }
            return Response;
        }
    }
}
