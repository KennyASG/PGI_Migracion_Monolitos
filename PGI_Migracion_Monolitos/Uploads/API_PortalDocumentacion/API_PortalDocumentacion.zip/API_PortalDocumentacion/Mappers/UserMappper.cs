﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using AutoMapper;

namespace API_PortalDocumentacion.Mappers
{
    public class UserMappper: Profile
    {
        public UserMappper()
        {
            CreateMap<User, UserDTO>().ReverseMap();
            CreateMap<User, CreateLocalUserDTO>().ReverseMap();
            CreateMap<User, UpdatePasswordLUDTO>().ReverseMap();
        }
    }
}
