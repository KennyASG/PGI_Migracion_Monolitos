using ClosedXML.Excel;
using Microsoft.Office.Interop.Visio;
using System.Globalization;
using System.Text;
using XAct;

namespace textsVisios
{
    internal class CountFigure
    {
        public void OpenVisio(string visioFilePath, IXLWorksheet worksheet, ref int row)
        {
            if (!File.Exists(visioFilePath))
            {
                Console.WriteLine($"El archivo {visioFilePath} no existe.");
                return;
            }

            Application visioApp = new Application();
            Document visioDoc = null;

            try
            {
                visioDoc = visioApp.Documents.Open(visioFilePath);
                Console.WriteLine($"Archivo {visioFilePath} abierto correctamente.");

                string visioFileName = GetVisioFileName(visioDoc);

                Figure figure = new Figure
                {
                    Project = GetProject(visioFileName),
                    Module = GetModule(visioFileName),
                    Option = GetOption(visioFileName),
                };

                ProcessVisioDocument(visioDoc, worksheet, figure, ref row, figure.Project);
            }
            catch
            {
                Console.WriteLine("Error al abrir el archivo");
            }
            finally
            {
                if (visioDoc != null)
                {
                    visioDoc.Close();
                }
                visioApp.Quit();
            }
        }


        private string globalSoapServiceElement;
        private void ProcessVisioDocument(Document visioDoc, IXLWorksheet worksheet, Figure figure, ref int row, string project)
        {
            foreach (Page page in visioDoc.Pages)
            {
                figure.Diagram = GetDiagramName(page);
                if ("BROKER".Equals(project.ToUpper())){
                    figure.Archive = !figure.Option.IsNullOrEmpty() ? figure.Option.ToUpper() + "-" + RemoveDiacritics(figure.Diagram)?.ToUpper() : RemoveDiacritics(figure.Diagram)?.ToUpper();

                }
                else {
                    figure.Archive = RemoveDiacritics(figure.Diagram)?.ToUpper();
                }
                
               
                foreach (Shape shape in page.Shapes)
                {
                    if (ShapeFilter(shape))
                    {
                        continue;
                    }

                    try
                    {
                        string figureType = DetectFigureType(shape);
                        if (figureType == "Metodo")
                        {
                            ProcessMethod(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Metodo");
                        }
                        else if (figureType == "Servicio")
                        {
                            ProcessService(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Servicio");
                        }
                        else if (figureType == "Consumo")
                        {
                            ProcessDB(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Consumo");
                        }
                        else if (figureType == "Programa")
                        {
                            ProcessProgram(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Programa");
                        }
                        else if (figureType == "Estatus")
                        {
                            ProcessStatus(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Estatus");
                        }
                        else if (figureType == "Ruta")
                        {
                            ProcessRoute(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Ruta");
                        }
                        else if (figureType == "Cola")
                        {
                            ProcessQueue(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Cola");
                        }
                        else if (figureType == "Gestor")
                        {
                            ProcessManager(shape, figure, worksheet, ref row);
                            Console.WriteLine("Procesando Figura Gestor");
                        }
                    }
                    catch
                    {
                        Console.WriteLine($"Error en la figura '{shape.Name}'");
                    }
                }
            }
        }

        public void InitializeWorksheetHeaders(IXLWorksheet worksheet)
        {
            var headers = new[] { "PROYECTO", "MÓDULO", "OPCIÓN", "DIAGRAMA", "ARCHIVO", "SISTEMA", "TIPO DE CONSUMO", "ELEMENTO", "MÉTODO" };
            for (int i = 0; i < headers.Length; i++)
            {
                worksheet.Cell(1, i + 1).Value = headers[i];
            }
        }


        private void ProcessStatus(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            var currentFigure = new Figure
            {
                Name = GetName(shape),
                Function = GetFunction(shape),
                Project = figure.Project,
                Module = figure.Module,
                Option = figure.Option,
                Diagram = figure.Diagram,
                Archive = figure.Archive
            };

            string[] lines = shape.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            string currentQueryType = null;
            bool isTableSection = false;

            for (int i = 0; i < lines.Length; i++)
            {
                string trimmedLine = lines[i].Trim();

                if (trimmedLine.Contains("CAMBIO ESTATUS DE", StringComparison.OrdinalIgnoreCase))
                {
                    currentQueryType = "QUERY UPDATE";
                }
                else if (trimmedLine.Contains("ESTATUS DE", StringComparison.OrdinalIgnoreCase) ||
                         trimmedLine.Contains("VALIDACIÓN", StringComparison.OrdinalIgnoreCase) ||
                         trimmedLine.Contains("Valida Tabla de colas", StringComparison.OrdinalIgnoreCase))
                {
                    currentQueryType = "QUERY SELECT";
                }

                if (trimmedLine.Contains("QUERY SELECT:", StringComparison.OrdinalIgnoreCase) ||
                    trimmedLine.Contains("QUERY UPDATE:", StringComparison.OrdinalIgnoreCase))
                {
                    isTableSection = true;
                    continue;
                }

                if (isTableSection)
                {
                    if (!string.IsNullOrWhiteSpace(trimmedLine))
                    {
                        if (currentQueryType != null)
                        {
                            currentFigure.Service = currentQueryType;
                            currentFigure.Element = trimmedLine;
                            AddRegister(worksheet, currentFigure, ref row);
                        }
                        else
                        {
                            Console.WriteLine($"Warning: No query type set for line '{trimmedLine}'");
                        }
                    }
                }
            }
        }

        private void ProcessProgram(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            var currentFigure = new Figure
            {
                Name = GetName(shape),
                Function = GetFunction(shape),
                Project = figure.Project,
                Module = figure.Module,
                Option = figure.Option,
                Diagram = figure.Diagram,
                Archive = figure.Archive
            };

            string[] lines = shape.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);


            for (int i = 0; i < lines.Length; i++)
            {
                string trimmedLine = lines[i].Trim();

                if (trimmedLine.Contains("PROGRAMA zSeries:", StringComparison.OrdinalIgnoreCase) || trimmedLine.Contains("PROGRAMA AS400:", StringComparison.OrdinalIgnoreCase))
                {
                    currentFigure.Service = "PROGRAMA COBOL";
                    currentFigure.Element = GetElementFromNextLineOrApplicationID(lines, i);
                    break;
                }
                else if (trimmedLine.Contains("PROGRAMA (Demonio", StringComparison.OrdinalIgnoreCase) ||
                         trimmedLine.Contains("PROGRAMA: (Demonio", StringComparison.OrdinalIgnoreCase))
                {
                    currentFigure.Service = "PROGRAMA";
                    if ((i + 1) < lines.Length)
                    {
                        currentFigure.Element = lines[i + 1].Trim();
                    }
                    break;
                }
            }

            if (!string.IsNullOrWhiteSpace(currentFigure.Service) && !string.IsNullOrWhiteSpace(currentFigure.Element))
            {
                AddRegister(worksheet, currentFigure, ref row);
            }
        }

        private void ProcessRoute(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            try
            {
                string[] formats = { "Ruta de Acceso:", "Transacción CICS:", "Transacción zSeries:" };
                string[] lines = shape.Text.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                string service = string.Empty;
                string element = string.Empty;

                string cicsTransaction = string.Empty;
                string rutaAcceso = string.Empty;

                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();

                    if (line.StartsWith("Transacción CICS:", StringComparison.OrdinalIgnoreCase) || line.StartsWith("Transacción zSeries:", StringComparison.OrdinalIgnoreCase))
                    {
                        service = "TRANSACCIÓN CICS";
                        if (i + 1 < lines.Length)
                        {
                            cicsTransaction = lines[i + 1].Trim();
                        }
                    }

                    else if (line.StartsWith("Ruta de Acceso:", StringComparison.OrdinalIgnoreCase))
                    {
                        service = "RUTA DE ACCESO";

                        List<string> elements = new List<string>();
                        for (int j = i + 1; j < lines.Length; j++)
                        {
                            string subsequentLine = lines[j].Trim();
                            if (string.IsNullOrWhiteSpace(subsequentLine)) break;
                            elements.Add(subsequentLine);
                        }
                        rutaAcceso = string.Join("|", elements);
                    }
                }

                if (!string.IsNullOrWhiteSpace(cicsTransaction))
                {
                    var cicsFigure = new Figure
                    {
                        Name = GetName(shape),
                        Function = GetFunction(shape),
                        Service = "TRANSACCIÓN CICS",
                        Element = cicsTransaction,
                        Method = string.Empty,
                        Project = figure.Project,
                        Module = figure.Module,
                        Option = figure.Option,
                        Diagram = figure.Diagram,
                        Archive = figure.Archive
                    };
                    AddRegister(worksheet, cicsFigure, ref row);
                }

                if (!string.IsNullOrWhiteSpace(rutaAcceso))
                {
                    var rutaFigure = new Figure
                    {
                        Name = GetName(shape),
                        Function = GetFunction(shape),
                        Service = "RUTA DE ACCESO",
                        Element = rutaAcceso,
                        Method = string.Empty,
                        Project = figure.Project,
                        Module = figure.Module,
                        Option = figure.Option,
                        Diagram = figure.Diagram,
                        Archive = figure.Archive
                    };
                    AddRegister(worksheet, rutaFigure, ref row);
                }
            }
            catch
            {
                Console.WriteLine($"Error al procesar la figura {shape.NameU}");
            }
        }

        private void ProcessQueue(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            string[] validQueues = { "COLA MQ", "COLA 390", "COLA AS400", "COLA AUTORIZA" };

            string queueType = string.Empty;
            string queueContent = string.Empty;

            try
            {
                string[] lines = shape.Text.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < lines.Length; i++)
                {
                    string trimmedLine = lines[i].Trim();

                    foreach (var queue in validQueues)
                    {
                        if (trimmedLine.StartsWith(queue, StringComparison.OrdinalIgnoreCase))
                        {
                            queueType = queue;
                            if (i + 1 < lines.Length)
                            {
                                queueContent = lines[i + 1].Trim();
                            }
                            break;
                        }
                    }
                }

                var currentFigure = new Figure
                {
                    Name = GetName(shape),
                    Function = GetFunction(shape),
                    Service = queueType,
                    Element = queueContent,
                    Method = string.Empty,
                    Project = figure.Project,
                    Module = figure.Module,
                    Option = figure.Option,
                    Diagram = figure.Diagram,
                    Archive = figure.Archive
                };

                if (!string.IsNullOrWhiteSpace(currentFigure.Service) && !string.IsNullOrWhiteSpace(currentFigure.Element))
                {
                    AddRegister(worksheet, currentFigure, ref row);
                }
            }
            catch
            {
                Console.WriteLine($"Error al procesar la cola de la figura {shape.NameU}");
            }
        }

        private void ProcessManager(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            try
            {
                string[] lines = shape.Text.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                bool processingCanales = false;

                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();

                    if (line.StartsWith("GESTOR:", StringComparison.OrdinalIgnoreCase))
                    {
                        if (i + 1 < lines.Length)
                        {
                            string gestorContent = lines[i + 1].Trim();

                            var gestorFigure = new Figure
                            {
                                Name = GetName(shape),
                                Function = GetFunction(shape),
                                Service = "GESTOR",
                                Element = gestorContent,
                                Method = string.Empty,
                                Project = figure.Project,
                                Module = figure.Module,
                                Option = figure.Option,
                                Diagram = figure.Diagram,
                                Archive = figure.Archive
                            };

                            AddRegister(worksheet, gestorFigure, ref row);
                        }
                    }

                    if (line.StartsWith("CANALES:", StringComparison.OrdinalIgnoreCase) ||
                        line.StartsWith("CANAL:", StringComparison.OrdinalIgnoreCase))
                    {
                        processingCanales = true;
                        continue;
                    }

                    if (processingCanales)
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {

                            var canalFigure = new Figure
                            {
                                Name = GetName(shape),
                                Function = GetFunction(shape),
                                Service = "CANAL",
                                Element = line,
                                Method = string.Empty,
                                Project = figure.Project,
                                Module = figure.Module,
                                Option = figure.Option,
                                Diagram = figure.Diagram,
                                Archive = figure.Archive
                            };

                            AddRegister(worksheet, canalFigure, ref row);
                        }
                    }
                }
            }
            catch
            {
                Console.WriteLine($"Error al procesar la figura {shape.NameU}");
            }
        }

        private string GetElementFromNextLineOrApplicationID(string[] lines, int currentIndex)
        {
            if ((currentIndex + 1) < lines.Length && !lines[currentIndex + 1].Contains("DESCRIPCIÓN:", StringComparison.OrdinalIgnoreCase))
            {
                return lines[currentIndex + 1].Trim();
            }
            else
            {
                for (int i = currentIndex + 1; i < lines.Length; i++)
                {
                    if (lines[i].Contains("ApplicationID:", StringComparison.OrdinalIgnoreCase))
                    {
                        return lines[i].Substring("ApplicationID:".Length).Trim();
                    }
                }
            }
            return null;
        }

        private void ProcessService(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            var currentFigure = new Figure
            {
                Name = GetName(shape),
                Function = GetFunction(shape),
                Service = GetService(shape),
                Element = GetElement(shape),
                Method = GetMethod(shape),
                Project = figure.Project,
                Module = figure.Module,
                Option = figure.Option,
                Diagram = figure.Diagram,
                Archive = figure.Archive
            };

            if (figure.Project.Equals("BROKER", StringComparison.OrdinalIgnoreCase) &&
                currentFigure.Service.Equals("SOAP SERVICE", StringComparison.OrdinalIgnoreCase))
            {
                globalSoapServiceElement = currentFigure.Element;
            }
            if (!string.IsNullOrWhiteSpace(currentFigure.Service))
            {
                AddRegister(worksheet, currentFigure, ref row);
            }
        }

        private void ProcessMethod(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            var currentFigure = new Figure
            {
                Name = GetName(shape),
                Function = GetFunction(shape),
                Service = "SOAP SERVICE",
                Element = globalSoapServiceElement,
                Method = GetMethod(shape),
                Project = figure.Project,
                Module = figure.Module,
                Option = figure.Option,
                Diagram = figure.Diagram,
                Archive = figure.Archive
            };

            if (!string.IsNullOrWhiteSpace(currentFigure.Method))
            {
                AddRegister(worksheet, currentFigure, ref row);
            }
        }

        private void AddRegister(IXLWorksheet worksheet, Figure figure, ref int row)
        {
            worksheet.Cell(row, 1).Value = figure.Project;
            worksheet.Cell(row, 2).Value = figure.Module;
            worksheet.Cell(row, 3).Value = figure.Option;
            worksheet.Cell(row, 4).Value = figure.Diagram;
            worksheet.Cell(row, 5).Value = figure.Archive;
            worksheet.Cell(row, 6).Value = figure.Function;
            worksheet.Cell(row, 7).Value = figure.Service.ToUpper();
            worksheet.Cell(row, 8).Value = figure.Element;
            worksheet.Cell(row, 9).Value = figure.Method;
            row++;
        }

        private void ProcessDB(Shape shape, Figure figure, IXLWorksheet worksheet, ref int row)
        {
            var currentFigure = new Figure
            {
                Name = GetName(shape),
                Function = GetFunction(shape),
                Project = figure.Project,
                Module = figure.Module,
                Option = figure.Option,
                Diagram = figure.Diagram,
                Archive = figure.Archive
            };

            string[] lines = shape.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            string currentDBType = null;

            foreach (string line in lines)
            {
                string trimmedLine = line.Trim();

                if (IsDBTypeLine(trimmedLine))
                {
                    currentDBType = trimmedLine.Split(':')[0];
                }
                else if (!string.IsNullOrWhiteSpace(currentDBType))
                {
                    AddDB(worksheet, currentFigure, currentDBType, trimmedLine, ref row);
                }
            }
        }

        private bool IsDBTypeLine(string line)
        {
            return line.Contains("STORE PROCEDURE:", StringComparison.OrdinalIgnoreCase) ||
                   line.Contains("QUERY SELECT:", StringComparison.OrdinalIgnoreCase) ||
                   line.Contains("QUERY UPDATE:", StringComparison.OrdinalIgnoreCase) ||
                   line.Contains("QUERY INSERT:", StringComparison.OrdinalIgnoreCase) ||
                   line.Contains("QUERY DELETE:", StringComparison.OrdinalIgnoreCase);
        }

        private void AddDB(IXLWorksheet worksheet, Figure figure, string dbType, string dbDetail, ref int row)
        {
            worksheet.Cell(row, 1).Value = figure.Project;
            worksheet.Cell(row, 2).Value = figure.Module;
            worksheet.Cell(row, 3).Value = figure.Option;
            worksheet.Cell(row, 4).Value = figure.Diagram;
            worksheet.Cell(row, 5).Value = figure.Archive;
            worksheet.Cell(row, 6).Value = figure.Function;
            worksheet.Cell(row, 7).Value = dbType.ToUpper();
            worksheet.Cell(row, 8).Value = dbDetail;
            row++;
        }

        private string GetVisioFileName(Document visioDoc)
        {
            return System.IO.Path.GetFileNameWithoutExtension(visioDoc.FullName);
        }

        private string RemoveDiacritics(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            string normalized = input.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (char c in normalized)
            {
                UnicodeCategory category = CharUnicodeInfo.GetUnicodeCategory(c);
                if (category != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }

        private string GetProject(string visioFileName)
        {
            string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(visioFileName);
            var parts = fileNameWithoutExtension.Split('-');

            if (parts.Length < 4)
            {
                return string.Empty;
            }

            return parts[3].Trim();
        }

        private string GetModule(string visioFileName)
        {
            string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(visioFileName);
            var parts = fileNameWithoutExtension.Split('-');

            if (parts.Length < 5)
            {
                return string.Empty;
            }

            return parts[4].Trim();
        }

        private string GetOption(string visioFileName)
        {
            string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(visioFileName);
            var parts = fileNameWithoutExtension.Split('-');

            if (parts.Length < 6)
            {
                return string.Empty;
            }

            return parts[5].Trim();
        }

        private string GetDiagramName(Page page)
        {
            try
            {
                string diagramName = page.Name?.Trim();

                if (string.IsNullOrEmpty(diagramName))
                {
                    Console.WriteLine($"Advertencia: La página con ID {page.ID} no tiene un nombre asignado.");
                    return "Sin Nombre";
                }

                Console.WriteLine($"Nombre de la hoja procesada: {diagramName}");
                return diagramName;
            }
            catch
            {
                Console.WriteLine($"Error al obtener el nombre de la hoja");
                return "Error al Obtener Nombre";
            }
        }

        private bool ShapeFilter(Shape shape)
        {
            string[] excludedShapes = {
                "CFF Container", "Swimlane List", "Swimlane (vertical)",
                "Calle (vertical)", "Phase List", "Separator (vertical)",
                "Conector dinámico", "Dynamic connector", "Círculo", "Can"
            };

            foreach (string excludedShape in excludedShapes)
            {
                if (shape.Name.Contains(excludedShape))
                {
                    return true;
                }
            }

            return false;
        }

        private string GetName(Shape shape)
        {
            string name = shape.NameU;
            int EndName = name.IndexOf('.');
            return EndName > -1 ? name.Substring(0, EndName).Trim() : name.Trim();
        }

        private string GetFunction(Shape shape)
        {
            try
            {
                string function = shape.CellsU["Prop.Function"].ResultStr[0];
                return !string.IsNullOrEmpty(function) ? function : "Función no disponible";
            }
            catch
            {
                Console.WriteLine($"Error al obtener la función de la figura {shape.Name}");
                return "Función no disponible";
            }
        }

        private string GetService(Shape shape)
        {
            bool isRelevantFigure = shape.NameU.Contains("Process") || shape.NameU.Contains("Proceso") ||
                                    shape.NameU.Contains("Start/End") || shape.NameU.Contains("Inicio o finalización") ||
                                    shape.Text.Contains("SOAP SERVICE") || shape.Text.Contains("REST SERVICE") ||
                                    shape.Text.Contains("WEB SERVICE") || shape.Text.Contains("WCF SERVICE") ||
                                    shape.Text.Contains("URL") || shape.Text.Contains("SERVICIO WINDOWS") ||
                                    shape.Text.Contains("SERVICIO DE WINDOWS") || shape.Text.Contains("UTILIDAD") ||
                                    shape.Text.Contains("MÉTODO SELECCIONADO") || shape.Text.Contains("POD") ||
                                    shape.Text.Contains("SERVICIO AS400") || shape.Text.Contains("SVC") ||
                                    shape.Text.Contains("COMUNICACIÓN SISTEMAS CENTRALES") || shape.NameU.Contains("RequestA")
                                    || shape.Text.StartsWith("UTILIDAD") || shape.Text.StartsWith("OPERACIÓN AS400")
                                    || shape.Text.StartsWith("OPERACIÓN") || shape.Text.StartsWith("ACCIÓN")
                                    || shape.Text.StartsWith("TCP SERVICE");

            if (isRelevantFigure)
            {
                string[] validServiceTypes = {
            "REST SERVICE", "WEB SERVICE", "SOAP SERVICE", "WCF SERVICE", "URL",
            "SERVICIO WINDOWS", "SERVICIO DE WINDOWS", "UTILIDAD", "MÉTODO SELECCIONADO",
            "POD", "SERVICIO AS400", "SVC", "COMUNICACIÓN SISTEMAS CENTRALES", "OPERACIÓN AS400", "OPERACIÓN", "ACCIÓN", "TCP SERVICE"
        };

                try
                {
                    string rawContent = shape.Text;
                    var lines = rawContent.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                    foreach (var line in lines)
                    {
                        int colonIndex = line.IndexOf(':');
                        if (colonIndex > -1)
                        {
                            string serviceType = line.Substring(0, colonIndex).Trim();

                            if (Array.Exists(validServiceTypes, name => name.Equals(serviceType, StringComparison.OrdinalIgnoreCase)))
                            {
                                return serviceType;
                            }
                        }
                    }

                    return string.Empty;
                }
                catch
                {
                    Console.WriteLine($"Error al obtener el tipo de servicio de la figura {shape.NameU}");
                    return string.Empty;
                }
            }

            return string.Empty;
        }

        private string GetElement(Shape shape)
        {
            string[] validCases = {
        "REST SERVICE", "WEB SERVICE", "SOAP SERVICE", "WCF SERVICE", "URL",
        "SERVICIO WINDOWS", "SERVICIO DE WINDOWS", "UTILIDAD", "MÉTODO SELECCIONADO",
        "POD", "SERVICIO AS400", "SVC", "COMUNICACIÓN SISTEMAS CENTRALES", "OPERACIÓN AS400", "OPERACIÓN", "ACCIÓN", "TCP SERVICE"
    };

            string content = string.Empty;

            try
            {
                string[] lines = shape.Text.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < lines.Length; i++)
                {
                    string trimmedLine = lines[i].Trim();

                    foreach (var service in validCases)
                    {
                        if (trimmedLine.StartsWith(service, StringComparison.OrdinalIgnoreCase))
                        {
                            if (trimmedLine.Contains(":"))
                            {
                                int colonIndex = trimmedLine.IndexOf(":");
                                string afterColon = trimmedLine.Substring(colonIndex + 1).Trim();

                                if (string.IsNullOrEmpty(afterColon) && i + 1 < lines.Length)
                                {
                                    content = lines[i + 1].Trim();
                                }
                                else
                                {
                                    content = afterColon;
                                }
                            }
                            break;
                        }
                    }
                }
            }
            catch
            {
                Console.WriteLine($"Error al obtener el contenido de la figura {shape.NameU}");
                content = "Contenido no disponible";
            }

            return content;
        }

        private string GetMethod(Shape shape)
        {
            string[] MethodKeywords = { "MÉTODO:" };

            try
            {
                string rawContent = shape.Text;
                var lines = rawContent.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();

                    foreach (var keyword in MethodKeywords)
                    {
                        if (line.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) != -1)
                        {
                            if (i + 1 < lines.Length)
                            {
                                string method = lines[i + 1].Trim();

                                if (method.Equals("Pendiente", StringComparison.OrdinalIgnoreCase))
                                {
                                    return string.Empty;
                                }

                                return method;
                            }
                            else
                            {
                                return string.Empty;
                            }
                        }
                    }
                }

                return string.Empty;
            }
            catch
            {
                Console.WriteLine($"Error al obtener el método/operación de la figura {shape.NameU}");
                return "Contenido no disponible";
            }
        }

        private string DetectFigureType(Shape shape)
        {
            string shapeText = shape.Text;
            string shapeName = shape.Name;

            string firstLine = GetFirstLine(shapeText);

            if (firstLine.Equals("MÉTODO:", StringComparison.OrdinalIgnoreCase))
            {
                return "Metodo";
            }
            if (firstLine.Contains("PROGRAMA", StringComparison.OrdinalIgnoreCase))
            {
                return "Programa";
            }
            else if (firstLine.Contains("GESTOR:", StringComparison.OrdinalIgnoreCase))
            {
                return "Gestor";
            }
            else if (firstLine.Contains("RUTA DE ACCESO:", StringComparison.OrdinalIgnoreCase) ||
                     firstLine.Contains("TRANSACCIÓN CICS:", StringComparison.OrdinalIgnoreCase))
            {
                return "Ruta";
            }
            else if (shapeName.Contains("BASE DE DATOS", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("COLA MQ", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("COLA 390", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("COLA AS400", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("COLA AUTORIZA", StringComparison.OrdinalIgnoreCase))
            {
                return "Cola";
            }
            else if (shapeText.Contains("CAMBIO ESTATUS DE LOTE", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("CAMBIO ESTATUS DE DETALLE", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("ESTATUS DE LOTE", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("VALIDA TABLA DE", StringComparison.OrdinalIgnoreCase))
            {
                return "Estatus";
            }
            else if (shapeText.Contains("STORE PROCEDURE", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("QUERY SELECT", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("QUERY UPDATE", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("QUERY INSERT", StringComparison.OrdinalIgnoreCase) ||
                     shapeText.Contains("QUERY DELETE", StringComparison.OrdinalIgnoreCase))
            {
                return "Consumo";
            }
            else if ((shapeName.Contains("START/END", StringComparison.OrdinalIgnoreCase) ||
                      shapeName.Contains("PROCESS", StringComparison.OrdinalIgnoreCase) ||
                      shapeName.Contains("PROCESO", StringComparison.OrdinalIgnoreCase) ||
                      shapeName.Contains("REQUESTA", StringComparison.OrdinalIgnoreCase) ||
                      shapeName.Contains("REQUESTB", StringComparison.OrdinalIgnoreCase) ||
                      shapeName.Contains("REQUESTC", StringComparison.OrdinalIgnoreCase) ||
                      shapeName.Contains("INICIO O FINALIZACIÓN", StringComparison.OrdinalIgnoreCase)) &&
                     (shapeText.Contains("SOAP SERVICE", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("REST SERVICE", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("WEB SERVICE", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("WCF SERVICE", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("URL", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("SERVICIO WINDOWS", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("SERVICIO DE WINDOWS", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("UTILIDAD", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("POD", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("SVC", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("SERVICIO AS400", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("COMUNICACIÓN SISTEMAS CENTRALES", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("MÉTODO SELECCIONADO", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("MÉTODO ASIGNADO", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("MÉTODO RECIBIDO", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("OPERACIÓN AS400", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("OPERACIÓN", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("ACCIÓN", StringComparison.OrdinalIgnoreCase) ||
                      shapeText.Contains("TCP SERVICE", StringComparison.OrdinalIgnoreCase)))
            {
                return "Servicio";
            }

            return "No Reconocido";
        }

        private string GetFirstLine(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return string.Empty;
            }

            string[] lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return lines.Length > 0 ? lines[0].Trim() : string.Empty;
        }

    }
}