﻿using System.Net.Mail;

namespace API_PortalDocumentacion.Tools
{
    public class EmailSender
    {
        public void EmailSend(string destinatario, string asunto, string cuerpo, IConfiguration _configuration)
        {
            try
            {

                using (SmtpClient smtpClient = new(_configuration.GetValue<string>("EmailSenderSettings:SmtpClient")))
                {
                    smtpClient.Port = _configuration.GetValue<int>("EmailSenderSettings:Port"); // Puerto SMTP estándar
                    //smtpClient.EnableSsl = true;

                    // Crear el mensaje de correo electrónico
                    using (MailMessage mailMessage = new())
                    {
                        mailMessage.From = new MailAddress(_configuration.GetValue<string>("EmailSenderSettings:EmailSender"));
                        mailMessage.To.Add(destinatario);
                        mailMessage.Subject = asunto;
                        mailMessage.Body = cuerpo;
                        mailMessage.IsBodyHtml = true;

                        smtpClient.Send(mailMessage);
                    }
                }
                Console.WriteLine("Correo electrónico enviado exitosamente.}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al enviar el correo electrónico: {ex.Message}");
            }
        }
    }
}
