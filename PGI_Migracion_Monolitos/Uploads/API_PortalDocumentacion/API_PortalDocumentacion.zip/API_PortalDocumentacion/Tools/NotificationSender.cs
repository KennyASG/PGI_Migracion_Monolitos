﻿using API_PortalDocumentacion.Models.Portal;
namespace API_PortalDocumentacion.Tools
{
    public class NotificationSender
    {
        //Declaration of variables
        public DbPortalDocumentacionContext _dbContext;

        //Class constructor
        public NotificationSender(DbPortalDocumentacionContext dbContext)
        {
            this._dbContext = dbContext;
        }
        public string CreateNotification(Notification notificationData) 
        {
            if (notificationData == null) {
                return "ERROR";
            }

            //Crear el título y el cuerpo de la notificación, según los datos recibidos
            //Llave: Destination_type - Notification_status
            //Valor título de notificación
            Dictionary<string, string> titulos = new()
            {
                { "1-1", "Tienes un diagrama pendiente de revisión" },
                { "3-2", "Tu diagrama ha sido aceptado" },
                { "3-3", "Tu diagrama ha sido rechazado" }
            };

            //Llave: Destination_type - Notification_status
            //Valor: cuerpo de la notificación
            Dictionary<string, string> mensajes = new()
            {
                { "1-1", "{nombre}, te ha enviado para revisión un diagrama de {diagrama}" },
                { "3-2", "El diagrama de {diagrama} ha sido aceptado por el administrador." },
                { "3-3", "El diagrama de {diagrama} ha sido rechazado. Por favor revisa los comentarios de tu administrador para realizar las correcciones solicitadas." }
            };

            //Obtener el nombre de la persona
            var sender = _dbContext.Users.FirstOrDefault(u => u.Corporate == notificationData.SenderCorporate);
            var receiver = _dbContext.Users.FirstOrDefault(u => u.Corporate == notificationData.ReceiverCorporate); 

            string senderName = "";
            if (sender != null) senderName = sender.Names + " " + sender.Surnames;
            string receiverName = "";
            if (receiver != null) receiverName = receiver.Names + " " + receiver.Surnames;

            string titulo = titulos[notificationData.DestinationType + "-" + notificationData.NotificationStatus];
            string mensaje = mensajes[notificationData.DestinationType + "-" + notificationData.NotificationStatus];

            //Obtener datos del diagrama
            var diagram = _dbContext.Diagrams.FirstOrDefault(d => d.DiagramId == notificationData.DiagramId);
            var option = _dbContext.Options.FirstOrDefault(o => o.OptionId == diagram.OptionId);
            var module = _dbContext.Modules.FirstOrDefault(m => m.ModuleId == diagram.ModuleId);
            var project = _dbContext.Projects.FirstOrDefault(p => p.ProjectId == module.ProjectId);
            //Formar string del proyecto - módulo - opción - diagrama
            string diagrama = "";
            if(project != null)
            {
                diagrama += project.Project1;
            }
            if (module != null)
            {
                diagrama += " - " + module.ModuleName;
            }
            if (option != null)
            {
                diagrama += " - " + option.OptionName;
            }
            if (diagram != null)
            {
                diagrama += " - " + diagram.Diagram1;
            }

            //Insertar el nombre del documentador en el mensaje (si aplica)
            mensaje = mensaje.Replace("{nombre}", senderName);

            //Insertar el nombre del diagrama en el mensaje
            mensaje = mensaje.Replace("{diagrama}", diagrama);

            try
            {
                //Crear la notificación
                Notification newNotification = new()
                {
                    SenderCorporate = notificationData.SenderCorporate,
                    ReceiverCorporate = notificationData.ReceiverCorporate,
                    DestinationType = notificationData.DestinationType,
                    CreationDate = DateTime.Now,
                    IsUnread = true,
                    Title = titulo,
                    Body = mensaje,
                    Comment = notificationData.Comment,
                    DiagramId = notificationData.DiagramId,
                    NotificationStatus = notificationData.NotificationStatus,
                    Active = true,
                    RelatedNotificationDate = notificationData.RelatedNotificationDate ?? null
                };

                //Guardar la notificación en la base de datos
                _dbContext.Notifications.Add(newNotification);
                _dbContext.SaveChanges();

                return "Éxito";
            }
            catch
            {
                return "ERROR";
            }
        }
    }
}
