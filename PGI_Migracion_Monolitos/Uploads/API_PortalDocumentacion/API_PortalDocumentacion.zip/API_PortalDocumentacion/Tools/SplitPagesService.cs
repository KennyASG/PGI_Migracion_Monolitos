using System.Globalization;
using System.IO.Compression;
using System.IO.Packaging;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using XAct;

namespace VisioWebTools
{
    public class SplitPagesService
    {
        public static string MakeSafeFileName(string unsafeFileName)
        {
            char[] invalidChars = Path.GetInvalidFileNameChars();
            foreach (char c in invalidChars)
            {
                unsafeFileName = unsafeFileName.Replace(c.ToString(), "_");
            }
            return unsafeFileName;
        }

        public static HashSet<string> GetRelatedPages(string pageId, List<PageInfo> infos)
        {
            var result = new HashSet<string>();
            var queue = new Queue<string>();
            queue.Enqueue(pageId);

            while (queue.Count > 0)
            {
                var id = queue.Dequeue();
                var info = infos.FirstOrDefault(i => i.PageId == id);
                if (info != null)
                {
                    result.Add(id);
                    if (!string.IsNullOrEmpty(info.BackPage))
                    {
                        queue.Enqueue(info.BackPage);
                    }
                }
            }

            return result;
        }

        private static string RemoveDiacritics(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            string normalized = input.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (char c in normalized)
            {
                UnicodeCategory category = CharUnicodeInfo.GetUnicodeCategory(c);
                if (category != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }


        public static byte[] SplitPagesMainframe(string[] visioFiles)
        {
          

            using (var output = new MemoryStream())
            {
                using (var zip = new ZipArchive(output, ZipArchiveMode.Create))
                {
                    foreach (var file in visioFiles)
                    {

                       // MemoryStream stream = new MemoryStream();
                        Stream stream = File.OpenRead(file);


                        var info = GetPageInfos(stream);

                        foreach (var pageInfo in info.PageInfos.Where(p => !p.Background))
                        {
                            using (var pageStream = new MemoryStream())
                            {
                                stream.Position = 0;
                                stream.CopyTo(pageStream);

                                var pagesToKeep = GetRelatedPages(pageInfo.PageId, info.PageInfos);
                                RemovePagesExcept(pageStream, pagesToKeep, info);

                                var fileName = RemoveDiacritics(MakeSafeFileName(pageInfo.PageName).ToUpper());


                                // Agregar el archivo .vsdx al archivo ZIP
                                ZipArchiveEntry entryVsdx;

                                if (fileName.ToUpper().Contains("PROC"))
                                {
                                    entryVsdx = zip.CreateEntry($"JCL/Procesos/{fileName.ToUpper()}.vsdx");
                                }
                                else if (fileName.ToUpper().Contains("DISP"))
                                {
                                    entryVsdx = zip.CreateEntry($"JCL/Disparadores/{fileName.ToUpper()}.vsdx");
                                }
                                else
                                {
                                    entryVsdx = zip.CreateEntry($"TWS/{fileName.ToUpper()}.vsdx");
                                }
                                using (var entryStreamVsdx = entryVsdx.Open())
                                {
                                    pageStream.Position = 0;
                                    pageStream.WriteTo(entryStreamVsdx);
                                }

                                var svgPath = ConvertToSvgUsingVisio(fileName, pageStream);
                                if (svgPath != null && File.Exists(svgPath))
                                {
                                    ZipArchiveEntry entrySvg;

                                    if (fileName.ToUpper().Contains("PROC"))
                                    {
                                        entrySvg = zip.CreateEntry($"JCL/Procesos/{fileName.ToUpper()}.svg");
                                    }
                                    else if (fileName.ToUpper().Contains("DISP"))
                                    {
                                        entrySvg = zip.CreateEntry($"JCL/Disparadores/{fileName.ToUpper()}.svg");
                                    }
                                    else
                                    {
                                        entrySvg = zip.CreateEntry($"TWS/{fileName.ToUpper()}.svg");
                                    }
                                    using (var entryStreamSvg =  entrySvg.Open())
                                    {
                                        var svgBytes = File.ReadAllBytes(svgPath);
                                        entryStreamSvg.Write(svgBytes, 0, svgBytes.Length);
                                    }
                                    
                                    // Eliminar el archivo SVG temporal despu�s de agregarlo al ZIP
                                    File.Delete(svgPath);
                                }
                            }
                        }//fin page
                        Thread.Sleep(1000);
                        stream.Close();
                    }
                }
                output.Flush();
                return output.ToArray();
            }
        }

        private static string GetOption(string visioFileName)
        {
            string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(visioFileName);
            var parts = fileNameWithoutExtension.Split('-');

            if (parts.Length < 6)
            {
                return string.Empty;
            }

            return parts[5].Trim();
        }

        public static byte[] SplitPagesBroker(string[] visioFiles)
        {
            using (var output = new MemoryStream())
            {
                using (var zip = new ZipArchive(output, ZipArchiveMode.Create))
                {
                    foreach (var file in visioFiles)
                    {
                        string option = GetOption(file);
                        string module = GetModule(file);
                        Stream stream = File.OpenRead(file);
                        var info = GetPageInfos(stream);
                        foreach (var pageInfo in info.PageInfos.Where(p => !p.Background))
                        {
                            using (var pageStream = new MemoryStream())
                            {
                                stream.Position = 0;
                                stream.CopyTo(pageStream);
                                var pagesToKeep = GetRelatedPages(pageInfo.PageId, info.PageInfos);
                                RemovePagesExcept(pageStream, pagesToKeep, info);
                                var fileName = !option.IsNullOrEmpty() ? option.ToUpper() + "-" + (MakeSafeFileName(pageInfo.PageName).ToUpper()) : (MakeSafeFileName(pageInfo.PageName).ToUpper());
                                // Agregar el archivo .vsdx al archivo ZIP
                                var entryVsdx = zip.CreateEntry($"{module}/{fileName}.vsdx");
                                using (var entryStreamVsdx = entryVsdx.Open())
                                {
                                    pageStream.Position = 0;
                                    pageStream.WriteTo(entryStreamVsdx);
                                }
                                var svgPath = ConvertToSvgUsingVisio(fileName, pageStream);
                                if (svgPath != null && File.Exists(svgPath))
                                {
                                    var entrySvg = zip.CreateEntry($"{module}/{fileName}.svg");
                                    using (var entryStreamSvg = entrySvg.Open())
                                    {
                                        var svgBytes = File.ReadAllBytes(svgPath);
                                        entryStreamSvg.Write(svgBytes, 0, svgBytes.Length);
                                    }
                                    // Eliminar el archivo SVG temporal despu�s de agregarlo al ZIP
                                    File.Delete(svgPath);
                                }
                            }
                        }//fin page
                        Thread.Sleep(1000);
                        stream.Close();
                    }
                }
                output.Flush();
                return output.ToArray();
            }
        }

        private static string GetModule(string visioFileName)
        {
            string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(visioFileName);
            var parts = fileNameWithoutExtension.Split('-');

            if (parts.Length < 5)
            {
                return string.Empty;
            }

            return parts[4].Trim();
        }
        public static byte[] SplitPages(Stream stream)
        {
            using (var output = new MemoryStream())
            {
                using (var zip = new ZipArchive(output, ZipArchiveMode.Create))
                {
                    var info = GetPageInfos(stream);

                    foreach (var pageInfo in info.PageInfos.Where(p => !p.Background))
                    {
                        using (var pageStream = new MemoryStream())
                        {
                            stream.Position = 0;
                            stream.CopyTo(pageStream);

                            var pagesToKeep = GetRelatedPages(pageInfo.PageId, info.PageInfos);
                            RemovePagesExcept(pageStream, pagesToKeep, info);



                            var fileName = RemoveDiacritics(MakeSafeFileName(pageInfo.PageName).ToUpper());
                                


                            // Agregar el archivo .vsdx al archivo ZIP
                            var entryVsdx = zip.CreateEntry($"{fileName}.vsdx");
                            using (var entryStreamVsdx = entryVsdx.Open())
                            {
                                pageStream.Position = 0;
                                pageStream.WriteTo(entryStreamVsdx);
                            }

                            var svgPath = ConvertToSvgUsingVisio(fileName, pageStream);
                            if (svgPath != null && File.Exists(svgPath))
                            {
                                var entrySvg = zip.CreateEntry($"{fileName}.svg");
                                using (var entryStreamSvg = entrySvg.Open())
                                {
                                    var svgBytes = File.ReadAllBytes(svgPath);
                                    entryStreamSvg.Write(svgBytes, 0, svgBytes.Length);
                                }

                                // Eliminar el archivo SVG temporal despu�s de agregarlo al ZIP
                                File.Delete(svgPath);
                            }
                        }
                    }
                }
                output.Flush();
                return output.ToArray();
            }
        }


        // Funci�n para convertir una p�gina de Visio a SVG usando Microsoft Visio Interop
        private static string ConvertToSvgUsingVisio(string fileName, MemoryStream visioStream)
        {
            var tempVsdxPath = Path.Combine(Path.GetTempPath(), $"{fileName}.vsdx");
            var tempSvgPath = Path.Combine(Path.GetTempPath(), $"{fileName}.svg");

            Microsoft.Office.Interop.Visio.Application visioApp = null;
            Microsoft.Office.Interop.Visio.Document visioDoc = null;

            try
            {
                // Guardar el contenido del MemoryStream a un archivo temporal .vsdx
                File.WriteAllBytes(tempVsdxPath, visioStream.ToArray());

                // Iniciar Visio y abrir el archivo .vsdx
                visioApp = new Microsoft.Office.Interop.Visio.Application();
                visioDoc = visioApp.Documents.Open(tempVsdxPath);

                // Seleccionar la primera p�gina del documento (o la que desees)
                var page = visioDoc.Pages[1];

                // Exportar la p�gina a SVG
                page.Export(tempSvgPath);

                return tempSvgPath;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error converting page to SVG: {ex.Message}");
                return null;
            }
            finally
            {
                // Cerrar el documento y la aplicaci�n de Visio
                visioDoc?.Close();
                visioApp?.Quit();

                // Limpiar el archivo temporal .vsdx
                if (File.Exists(tempVsdxPath))
                {
                    File.Delete(tempVsdxPath);
                }
            }
        }


        public static void RemovePagesExcept(Stream stream, HashSet<string> pagesToKeep, DocumentInfo info)
        {
            using (Package package = Package.Open(stream, FileMode.Open, FileAccess.ReadWrite))
            {
                var documentRel = package.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/document").First();
                Uri docUri = PackUriHelper.ResolvePartUri(new Uri("/", UriKind.Relative), documentRel.TargetUri);
                var documentPart = package.GetPart(docUri);

                var pagesRel = documentPart.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/pages").First();
                Uri pagesUri = PackUriHelper.ResolvePartUri(documentPart.Uri, pagesRel.TargetUri);
                var pagesPart = package.GetPart(pagesUri);

                var pagesStream = pagesPart.GetStream(FileMode.Open, FileAccess.ReadWrite);
                var xmlPages = XDocument.Load(pagesStream);

                var pageRels = pagesPart.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/page").ToList();

                var mediaToRemoveUrls = new HashSet<Uri>();
                for (var i = pageRels.Count - 1; i >= 0; --i)
                {
                    var pageRel = pageRels.ElementAt(i);
                    Uri pageUri = PackUriHelper.ResolvePartUri(pagesPart.Uri, pageRel.TargetUri);

                    var xmlPage = xmlPages.XPathSelectElement($"/v:Pages/v:Page[v:Rel/@r:id='{pageRel.Id}']", VisioParser.NamespaceManager);
                    var pageId = xmlPage.Attribute("ID").Value;
                    if (!pagesToKeep.Contains(pageId))
                    {
                        xmlPage.Remove();
                        package.DeletePart(pageUri);
                        pagesPart.DeleteRelationship(pageRel.Id);
                        var pageInfo = info.PageInfos.Find(x => x.PageId == pageId);
                        mediaToRemoveUrls.UnionWith(pageInfo.UsedMedia);
                    }
                }

                var mediaToKeepUrls = new HashSet<Uri>();
                mediaToKeepUrls.UnionWith(info.UsedMedia);
                foreach (var pageIdToKeep in pagesToKeep)
                {
                    var pageInfo = info.PageInfos.Find(x => x.PageId == pageIdToKeep);
                    mediaToKeepUrls.UnionWith(pageInfo.UsedMedia);
                }

                foreach (var mediaToRemoveUrl in mediaToRemoveUrls)
                {
                    if (!mediaToKeepUrls.Contains(mediaToRemoveUrl))
                        package.DeletePart(mediaToRemoveUrl);
                }

                pagesStream.SetLength(0);
                using (var writer = new XmlTextWriter(pagesStream, new UTF8Encoding(false)))
                {
                    xmlPages.Save(writer);
                }

                package.Flush();
            }
        }

        public class PageInfo
        {
            public string PageId { get; set; }
            public string PageName { get; set; }
            public bool Background { get; set; }
            public string BackPage { get; set; }

            public HashSet<Uri> UsedMedia { get; set; }
        }

        public class DocumentInfo
        {
            public HashSet<Uri> UsedMedia { get; set; }
            public List<PageInfo> PageInfos { get; set; }
        }

        public static DocumentInfo GetPageInfos(Stream stream)
        {
            var result = new DocumentInfo
            {
                UsedMedia = new HashSet<Uri>(),
                PageInfos = new List<PageInfo>()
            };

            using (Package package = Package.Open(stream))
            {
                var documentRel = package.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/document").First();
                Uri docUri = PackUriHelper.ResolvePartUri(new Uri("/", UriKind.Relative), documentRel.TargetUri);
                var documentPart = package.GetPart(docUri);

                var pagesRel = documentPart.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/pages").First();
                Uri pagesUri = PackUriHelper.ResolvePartUri(documentPart.Uri, pagesRel.TargetUri);
                var pagesPart = package.GetPart(pagesUri);
                var xmlPages = VisioParser.GetXMLFromPart(pagesPart);

                var pageRels = pagesPart.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/page").ToList();
                foreach (var pageRel in pageRels)
                {
                    var xmlPage = xmlPages.XPathSelectElement($"/v:Pages/v:Page[v:Rel/@r:id='{pageRel.Id}']", VisioParser.NamespaceManager);
                    var pageInfo = new PageInfo
                    {
                        PageId = xmlPage.Attribute("ID").Value,
                        PageName = xmlPage.Attribute("Name").Value,
                        Background = xmlPage.Attribute("Background")?.Value == "1",
                        BackPage = xmlPage.Attribute("BackPage")?.Value,
                        UsedMedia = new HashSet<Uri>()
                    };

                    Uri pageUri = PackUriHelper.ResolvePartUri(pagesPart.Uri, pageRel.TargetUri);
                    var pagePart = package.GetPart(pageUri);

                    var imageRels = pagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image").ToList();
                    foreach (var imageRel in imageRels)
                    {
                        var mediaUri = PackUriHelper.ResolvePartUri(pagePart.Uri, imageRel.TargetUri);
                        pageInfo.UsedMedia.Add(mediaUri);
                    }

                    var oleObjectRels = pagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/oleObject").ToList();
                    foreach (var oleObjectRel in oleObjectRels)
                    {
                        var mediaUri = PackUriHelper.ResolvePartUri(pagePart.Uri, oleObjectRel.TargetUri);
                        pageInfo.UsedMedia.Add(mediaUri);
                    }

                    result.PageInfos.Add(pageInfo);
                }

                result.UsedMedia = GetMastersUsedMedia(package, documentPart);

                return result;
            }
        }

        private static HashSet<Uri> GetMastersUsedMedia(Package package, PackagePart documentPart)
        {
            var usedMedia = new HashSet<Uri>();
            var mastersRel = documentPart.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/masters").FirstOrDefault();
            if (mastersRel != null)
            {
                Uri mastersUri = PackUriHelper.ResolvePartUri(documentPart.Uri, mastersRel.TargetUri);
                var mastersPart = package.GetPart(mastersUri);
                var xmlMasters = VisioParser.GetXMLFromPart(mastersPart);

                var masterRels = mastersPart.GetRelationshipsByType("http://schemas.microsoft.com/visio/2010/relationships/master").ToList();
                foreach (var masterRel in masterRels)
                {
                    var xmlMaster = xmlMasters.XPathSelectElement($"/v:Masters/v:Master[v:Rel/@r:id='{masterRel.Id}']", VisioParser.NamespaceManager);
                    Uri masterUri = PackUriHelper.ResolvePartUri(mastersPart.Uri, masterRel.TargetUri);
                    var masterPart = package.GetPart(masterUri);

                    var imageRels = masterPart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image").ToList();
                    foreach (var imageRel in imageRels)
                    {
                        var mediaUri = PackUriHelper.ResolvePartUri(masterPart.Uri, imageRel.TargetUri);
                        usedMedia.Add(mediaUri);
                    }
                }
            }
            return usedMedia;
        }
    }

}