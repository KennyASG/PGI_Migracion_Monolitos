﻿using API_PortalDocumentacion.Models.Portal;
using API_PortalDocumentacion.Models.Portal.Dtos;
using System.IO.Compression;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace API_PortalDocumentacion.Tools
{
    public class ExtractData
    {
        private readonly HashSet<string> allowedShapes = new HashSet<string>
        {
            "URL", "REST SERVICE", "WCF SERVICE", "WEB SERVICE", "ARCHIVO VSAM", "DATABASE", "POD", "URL ENDPOINT", "URL EXTERNA",
            "PROGRAMA COBOL", "PROGRAMA AUTORIZA", "PROTOCOLO", "OPERACIÓN SDK", "TAREA", "SOAP SERVICE", "RUTA DE ACCESO",
            "TRANSACCIÓN CICS", "COLA MQ", "OPERACIÓN AS400", "SERVICIO WINDOWS", "COM+", "DLL", "VALIDACIÓN",
            "CAMBIO ESTATUS DE DETALLE", "CAMBIO ESTATUS DE LOTE", "CAMBIO ESTATUS DE OPERACIÓN", "DEMONIO", "JCL", "TWS",
            "PROGRAMA", "PROCESOS", "MAN1", "DMY1", "ARCHIVO-VSAM", "ARCHIVO-PLANO", "FTP", "SUCESOR", "PREDECESOR", "CPU","QUERY INSERT",
            "QUERY SELECT","MVC", "SOCKET" , "FINIX" , "QUERY UPDATE","MICROSERVICIO","SERVICIO AS400","COLA AS400","NUGET"
        };

        private readonly HashSet<string> excludedShapes = new HashSet<string>
        {
            "CFF CONTAINER", "CALLE (VERTICAL)", "CAN", "CIRCLE", "CONECTOR DINÁMICO", "CÍRCULO", "DECISION", "DECISIÓN", "DESCRIPCIÓN",
            "DIAMOND", "DYNAMIC CONNECTOR", "INICIO O FINALIZACIÓN", "NORMAL", "ON-PAGE REFERENCE", "PHASE LIST", "PROGRAMA-ALERTA",
            "REF. A OTRA PÁGINA", "REF. EN PÁGINA", "REFERENCIA DE PÁGINA", "REFERENCIA EN PÁGINA", "ROMBO", "SEPARATOR (VERTICAL)",
            "SHEET", "START/END", "SWIMLANE (VERTICAL)", "SWIMLANE LIST", "INICIO/FIN", "UTILERÍA", "PÁGINA SIGUIENTE", "CONECTOR",
            "ACTIVIDAD", "MENSAJE DE ERROR", "TIMEOUT", "DECISIÓN", "CASE", "DECISIÓN LÓGICA", "PROGRAMA-ALERTA", "DESCRIPCIÓN",
            "FUNCIONALIDADES-COMPROMETIDAS", "FORMULARIO","CONTENEDOR CFF","LISTA DE CALLES","LISTA DE FASES","SEPARADOR (VERTICAL)","INICIO / FIN","ERROR"
        };

        private string NormalizeShapeName(string shapeName)
        {
            return Regex.Replace(shapeName, @"\.\d+$", "").Trim().ToUpperInvariant();
        }
        private Dictionary<string, string> masterShapes = new Dictionary<string, string>();
        private List<ShapeData> ProcessDBShape(string rawElementText, string system)
        {
            var extractedShapes = new List<ShapeData>();

            if (string.IsNullOrEmpty(rawElementText))
                return extractedShapes;

            string currentDBType = "N/A";
            var lines = rawElementText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string line in lines)
            {
                string trimmedLine = line.Trim();

                if (IsDBTypeLine(trimmedLine))
                {
                    currentDBType = trimmedLine.Split(':')[0].Trim();
                }
                else if (!string.IsNullOrWhiteSpace(currentDBType) && !string.IsNullOrWhiteSpace(trimmedLine))
                {
                    extractedShapes.Add(new ShapeData
                    {
                        ElementType = currentDBType,
                        Element = trimmedLine,
                        System = system ?? "N/A",
                        Description = "N/A",
                        Communication = "N/A",
                        Method = "N/A"
                    });
                }
            }

            return extractedShapes;
        }
        private bool IsDBTypeLine(string line)
        {
            return line.StartsWith("STORED PROCEDURE:", StringComparison.OrdinalIgnoreCase) ||
                   line.StartsWith("QUERY SELECT:", StringComparison.OrdinalIgnoreCase) ||
                   line.StartsWith("QUERY UPDATE:", StringComparison.OrdinalIgnoreCase) ||
                   line.StartsWith("QUERY INSERT:", StringComparison.OrdinalIgnoreCase) ||
                   line.StartsWith("QUERY DELETE:", StringComparison.OrdinalIgnoreCase);
        }
        private List<ShapeData> ProcessValidacionHorario(string rawText, string system)
        {
            var shapes = new List<ShapeData>();

            if (string.IsNullOrWhiteSpace(rawText))
                return shapes;

            var lines = rawText.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                               .Select(l => l.Trim())
                               .Where(l => !string.IsNullOrEmpty(l))
                               .ToList();
            bool startAdding = false;
            foreach (var line in lines)
            {
                if (line.Equals("ID DE MENÚ:", StringComparison.OrdinalIgnoreCase))
                {
                    startAdding = true;
                    continue;
                }

                if (startAdding)
                {
                    shapes.Add(new ShapeData
                    {
                        ElementType = "VALIDACIÓN DE HORARIO",
                        Element = line,
                        System = system ?? "N/A",
                        Description = "N/A",
                        Communication = "N/A",
                        Method = "N/A"
                    });
                }
            }

            return shapes;
        }


        private List<ShapeData> ProcessFileShape(string rawElementText, string system, string originalType)
        {
            var extractedShapes = new List<ShapeData>();
            if (string.IsNullOrEmpty(rawElementText)) return extractedShapes;

            string elementType;
            if (originalType == "ARCHIVO-VSAM" || originalType == "ARCHIVO VSAM")
            {
                elementType = "VSAM";
            }
            else if (originalType == "ARCHIVO-PLANO")
            {
                elementType = "FTP";
            }
            else
            {
                return extractedShapes;
            }

            var lines = rawElementText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var line in lines)
            {
                if (line.Trim().Equals("VSAM:", StringComparison.OrdinalIgnoreCase) ||
                    line.Trim().Equals("FTP:", StringComparison.OrdinalIgnoreCase) ||
                    line.Trim().Equals("Input:", StringComparison.OrdinalIgnoreCase) ||
                    line.Trim().Equals("Output:", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }


                extractedShapes.Add(new ShapeData
                {
                    ElementType = elementType,
                    Element = line.Trim(),
                    System = system ?? "N/A",
                    Description = "N/A",
                    Communication = "N/A",
                    Method = "N/A"
                });
            }

            return extractedShapes;
        }
        private string ProcessRouteAccess(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return "N/A";

            string origen = "N/A", destino = "N/A", operacion = "N/A";

            string[] lines = rawText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var line in lines)
            {
                string trimmedLine = line.Trim();

                if (trimmedLine.StartsWith("Origen:", StringComparison.OrdinalIgnoreCase))
                {
                    origen = $"Origen: {trimmedLine[7..].Trim()}";
                }
                else if (trimmedLine.StartsWith("Destino:", StringComparison.OrdinalIgnoreCase))
                {
                    destino = trimmedLine.Substring(8).Trim();
                }
                else if (trimmedLine.StartsWith("Operación:", StringComparison.OrdinalIgnoreCase))
                {
                    operacion = trimmedLine.Substring(10).Trim();
                }
            }

            List<string> parts = new List<string>();

            if (!string.IsNullOrEmpty(origen)) parts.Add($"Origen: {origen}");
            if (!string.IsNullOrEmpty(destino)) parts.Add($"Destino: {destino}");
            if (!string.IsNullOrEmpty(operacion)) parts.Add($"Operación: {operacion}");

            return parts.Count > 0 ? string.Join(" | ", parts) : "N/A";
        }

        private (string element, string method, string description) ProcessDLL(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return ("N/A", "N/A", "N/A");

            string dll = "N/A";
            string archivo = "N/A";
            string componente = "N/A";
            string metodo = "N/A";
            string descripcion = "N/A";

            string[] lines = rawText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lines.Length - 1; i++)
            {
                string trimmedLine = lines[i].Trim();
                string nextLine = lines[i + 1].Trim();

                if (trimmedLine.Equals("DLL:", StringComparison.OrdinalIgnoreCase))
                {
                    dll = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("ARCHIVO:", StringComparison.OrdinalIgnoreCase))
                {
                    archivo = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("COMPONENTE:", StringComparison.OrdinalIgnoreCase))
                {
                    componente = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("MÉTODO:", StringComparison.OrdinalIgnoreCase))
                {
                    metodo = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("DESCRIPCIÓN:", StringComparison.OrdinalIgnoreCase))
                {
                    descripcion = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
            }

            string element = string.Join(" | ", new[]
            {
            dll != "N/A" ? $"DLL: {dll}" : null,
            archivo != "N/A" ? $"ARCHIVO: {archivo}" : null,
            componente != "N/A" ? $"COMPONENTE: {componente}" : null
            }.Where(x => x != null));

            element = string.IsNullOrEmpty(element) ? "N/A" : element;

            return (element, metodo, descripcion);
        }


        private (string element, string method, string description, string communication) ProcessCOMPlus(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return ("N/A", "N/A", "N/A", "N/A");

            string paquete = "N/A";
            string componente = "N/A";
            string metodo = "N/A";
            string descripcion = "N/A";
            string comunicacion = "N/A";

            string[] lines = rawText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lines.Length - 1; i++)
            {
                string trimmedLine = lines[i].Trim();
                string nextLine = lines[i + 1].Trim();

                if (trimmedLine.Equals("PAQUETE:", StringComparison.OrdinalIgnoreCase))
                {
                    paquete = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("COMPONENTE:", StringComparison.OrdinalIgnoreCase))
                {
                    componente = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("MÉTODO:", StringComparison.OrdinalIgnoreCase))
                {
                    metodo = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("DESCRIPCIÓN:", StringComparison.OrdinalIgnoreCase))
                {
                    descripcion = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("COMUNICACIÓN:", StringComparison.OrdinalIgnoreCase))
                {
                    comunicacion = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
            }

            string element = string.Join(" | ", new[]
            {
                paquete != "N/A" ? $"PAQUETE: {paquete}" : null,
                componente != "N/A" ? $"COMPONENTE: {componente}" : null
            }.Where(x => x != null));

            element = string.IsNullOrEmpty(element) ? "N/A" : element;

            return (element, metodo, descripcion, comunicacion);
        }

        private (string element, string method, string description, string communication) ProcessNuget(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return ("N/A", "N/A", "N/A", "N/A");

            string paquete = "N/A";
            string clase = "N/A";
            string metodo = "N/A";
            string descripcion = "N/A";
            string comunicacion = "N/A";

            string[] lines = rawText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lines.Length - 1; i++)
            {
                string trimmedLine = lines[i].Trim();
                string nextLine = lines[i + 1].Trim();

                if (trimmedLine.Equals("PAQUETE:", StringComparison.OrdinalIgnoreCase))
                {
                    paquete = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("CLASE:", StringComparison.OrdinalIgnoreCase))
                {
                    clase = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("MÉTODO:", StringComparison.OrdinalIgnoreCase))
                {
                    metodo = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("DESCRIPCIÓN:", StringComparison.OrdinalIgnoreCase))
                {
                    descripcion = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
                else if (trimmedLine.Equals("COMUNICACIÓN:", StringComparison.OrdinalIgnoreCase))
                {
                    comunicacion = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                }
            }

            string element = string.Join(" | ", new[]
            {
                paquete != "N/A" ? $"PAQUETE: {paquete}" : null,
                clase != "N/A" ? $"CLASE: {clase}" : null
            }.Where(x => x != null));

            element = string.IsNullOrEmpty(element) ? "N/A" : element;

            return (element, metodo, descripcion, comunicacion);
        }

        private string ProcessFTP(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return "N/A";

            string server = "N/A";
            string ipFileServer = "N/A";
            string carpetaRemota = "N/A";
            string comando = "N/A";
            string archivoPlano = "N/A";

            string[] lines = rawText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lines.Length - 1; i++)
            {
                string trimmedLine = lines[i].Trim();
                string nextLine = lines[i + 1].Trim();

                if (trimmedLine.Equals("SERVER:", StringComparison.OrdinalIgnoreCase))
                    server = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                else if (trimmedLine.Equals("IP FILE SERVER:", StringComparison.OrdinalIgnoreCase))
                    ipFileServer = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                else if (trimmedLine.Equals("CARPETA REMOTA:", StringComparison.OrdinalIgnoreCase))
                    carpetaRemota = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                else if (trimmedLine.Equals("COMANDO:", StringComparison.OrdinalIgnoreCase))
                    comando = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
                else if (trimmedLine.Equals("ARCHIVO PLANO:", StringComparison.OrdinalIgnoreCase))
                    archivoPlano = string.IsNullOrEmpty(nextLine) ? "N/A" : nextLine;
            }

            string element = string.Join(" | ", new[]
            {
                server != "N/A" ? $"SERVER: {server}" : null,
                ipFileServer != "N/A" ? $"IP FILE SERVER: {ipFileServer}" : null,
                carpetaRemota != "N/A" ? $"CARPETA REMOTA: {carpetaRemota}" : null,
                comando != "N/A" ? $"COMANDO: {comando}" : null,
                archivoPlano != "N/A" ? $"ARCHIVO PLANO: {archivoPlano}" : null
            }.Where(x => x != null));

            return string.IsNullOrEmpty(element) ? "N/A" : element;
        }


        private string ProcessFinix(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return "N/A";

            string ip = "N/A";
            string puerto = "N/A";

            var lines = rawText.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var line in lines)
            {
                string trimmedLine = line.Trim();

                if (trimmedLine.StartsWith("IP:", StringComparison.OrdinalIgnoreCase))
                    ip = trimmedLine.Length > 3 ? $"IP: {trimmedLine.Substring(3).Trim()}" : "N/A";
                else if (trimmedLine.StartsWith("PUERTO:", StringComparison.OrdinalIgnoreCase))
                    puerto = trimmedLine.Length > 7 ? $"PUERTO: {trimmedLine.Substring(7).Trim()}" : "N/A";
            }

            string element = string.Join(" | ", new[] { ip != "N/A" ? ip : null, puerto != "N/A" ? puerto : null }
                .Where(x => x != null));

            return string.IsNullOrEmpty(element) ? "N/A" : element;
        }


        private (string element, string description) ProcessSocket(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return ("N/A", "N/A");

            string socket = "N/A", trama = "N/A", iso = "N/A", description = "N/A";

            string[] lines = rawText.Split(new[] { '\n', '\r', '\u2028' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lines.Length - 1; i++)
            {
                string trimmedLine = lines[i].Trim();
                string nextValue = lines[i + 1].Trim();

                if (trimmedLine.Equals("SOCKET:", StringComparison.OrdinalIgnoreCase))
                    socket = string.IsNullOrEmpty(nextValue) ? "N/A" : nextValue;
                else if (trimmedLine.Equals("TRAMA:", StringComparison.OrdinalIgnoreCase))
                    trama = string.IsNullOrEmpty(nextValue) ? "N/A" : nextValue;
                else if (trimmedLine.Equals("ISO:", StringComparison.OrdinalIgnoreCase))
                    iso = string.IsNullOrEmpty(nextValue) ? "N/A" : nextValue;
                else if (trimmedLine.Equals("DESCRIPCIÓN:", StringComparison.OrdinalIgnoreCase))
                    description = string.IsNullOrEmpty(nextValue) ? "N/A" : nextValue;
            }

            string element = string.Join(" | ", new[]
            {
                socket != "N/A" ? $"SOCKET: {socket}" : null,
                trama != "N/A" ? $"TRAMA: {trama}" : null,
                iso != "N/A" ? $"ISO: {iso}" : null
            }.Where(x => x != null));

            return (string.IsNullOrEmpty(element) ? "N/A" : element, description);
        }



        private readonly Dictionary<string, string> shapePatterns = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "URL", @"^URL:\s*(?<element>[^\n]*)" },
            { "TAREA", @"^TAREA:\s*(?<element>[^\n]*)" },
            { "REST SERVICE", @"^REST SERVICE:\s*(?<element>[^\n]*)" },
            { "WCF SERVICE", @"^WCF SERVICE:\s*(?<element>[^\n]*)" },
            { "WEB SERVICE", @"^WEB SERVICE:\s*(?<element>[^\n]*)" },
            { "SERVICIO WINDOWS", @"^SERVICIO WINDOWS:\s*(?<element>[^\n]*)" },
            { "URL EXTERNA", @"^URL EXTERNA:\s*(?<element>[^\n]*)" },
            { "POD", @"^POD:\s*(?<element>[^\n]*)" },
            { "URL ENDPOINT", @"^URL ENDPOINT:\s*(?<element>[^\n]*)" },
            { "PROGRAMA COBOL", @"^PROGRAMA COBOL:\s*(?<element>[^\n]*)" },
            { "ARCHIVO VSAM", @"^ARCHIVO VSAM:\s*(?<element>[^\n]*)" },
            { "COLA MQ", @"^COLA MQ:\s*(?<element>[^\n]*)" },
            { "OPERACIÓN SDK", @"^OPERACIÓN SDK:\s*(?<element>[^\n]*)" },
            { "SOAP SERVICE", @"^SOAP SERVICE:\s*(?<element>[^\n]*)" },
            { "OPERACIÓN AS400", @"^OPERACIÓN AS400:\s*(?<element>[^\n]*)" },
            { "TRANSACCIÓN CICS", @"^TRANSACCIÓN CICS:\s*(?<element>[^\n]*)" },
            { "PROGRAMA AUTORIZA", @"^PROGRAMA AUTORIZA:\s*(?<element>[^\n]*)" },
            { "PROTOCOLO", @"^PROTOCOLO:\s*(?<element>[^\n]*)" },
            { "TWS", @"^\s*(?<element>\S+)(?:\s+\S{2,}.*)?$" },
            { "JCL", @"^\s*(?<element>\S+)(?:\s+\S{2,}.*)?$" },
            { "SUCESOR", @"^\s*(?<element>\S+)(?:\s+\S{2,}.*)?$" },
            { "PREDECESOR", @"^\s*(?<element>\S+)(?:\s+\S{2,}.*)?$" },
            { "PROGRAMA", @"^\s*(?<element>\S+)(?:\s+\S{2,}.*)?$" },
            { "PROCESOS", @"^(?<element>\S+)(?:\s*\n)?" },
            { "CPU", @"^\S+\s*\n(?<element>\S+)" },
            { "MAN1", @"^\S+\s*\n(?<element>\S+)" },
            { "DMY1", @"^\S+\s*\n(?<element>\S+)" },
            { "CAMBIO ESTATUS DE DETALLE", @"^CAMBIO ESTATUS DE DETALLE:\s*(?<element>[^\n]+)" },
            { "CAMBIO ESTATUS DE LOTE", @"TABLA:\s*(?<element>[^\n\r]*)" },
            { "CAMBIO ESTATUS DE OPERACIÓN", @"^CAMBIO ESTATUS DE OPERACIÓN:\s*(?<element>[^\n]+)" },
            { "VALIDACIÓN", @"TABLA:\s*(?<element>[^\n\r]*)" },
            { "DEMONIO", @"^PROGRAMA \(Demonio \d+\):\s*(?<element>[^\n\r]*)" +
              @"(?:\n+DESCRIPCIÓN:\s*(?<description>[^\n\r]*))?" +
              @"(?:\n+MÉTODO:\s*(?<method>[^\n\r]*))?" },
            { "MVC", @"^MVC:\s*(?<element>[^\n]*)" },
            { "FINIX", @"(?:\n|^)IP:\s*(?<ip>[^\n\r]*)?" +
           @"(?:\n|^)PUERTO:\s*(?<puerto>[^\n\r]*)?" },
            { "SOCKET", @"(?:\n|^)SOCKET:\s*(?<socket>[^\n\r]*)?" +
            @"(?:\n|^)TRAMA:\s*(?<trama>[^\n\r]*)?" +
            @"(?:\n|^)ISO:\s*(?<iso>[^\n\r]*)?" },
            { "MICROSERVICIO", @"^MICROSERVICIO:\s*(?<element>[^\n]*)" },
            { "SERVICIO AS400", @"^SERVICIO AS400:\s*(?<element>[^\n]*)" },
            { "COLA AS400", @"^COLA AS400:\s*(?<element>[^\n]*)" }
        };

        private void LoadMasterShapes(ZipArchive zip)
        {
            var masterXmlEntry = zip.Entries.FirstOrDefault(entry => entry.FullName.EndsWith("masters.xml", StringComparison.OrdinalIgnoreCase));
            if (masterXmlEntry == null)
            {
                throw new Exception("No se encontró el archivo 'masters.xml' en el archivo Visio.");
            }

            using (var entryStream = masterXmlEntry.Open())
            {
                var xdoc = XDocument.Load(entryStream);
                foreach (var master in xdoc.Descendants().Where(d => d.Name.LocalName == "Master"))
                {
                    var id = master.Attribute("ID")?.Value;
                    var name = master.Attribute("Name")?.Value;

                    if (!string.IsNullOrEmpty(id) && !string.IsNullOrEmpty(name))
                    {
                        masterShapes[id] = name.Trim().ToUpperInvariant();
                    }
                }
            }
        }
        private (string element, string description, string communication, string method, bool hasLexicalError)
            ExtractTextSections(string rawText, string elementType)
        {
            if (string.IsNullOrEmpty(rawText))
                return ("N/A", "N/A", "N/A", "N/A", false);

            if (elementType == "RUTA DE ACCESO")
                return (ProcessRouteAccess(rawText), "N/A", "N/A", "N/A", false);

            string basePattern = shapePatterns.ContainsKey(elementType) ? shapePatterns[elementType] : @"^(?<element>[^\n\r]*)";

            string fullPattern = basePattern +
                @"(?:\n+MÉTODO:\s*(?<method>[^\n\r]*))?" +
                @"(?:\n+DESCRIPCIÓN:\s*(?<description>[^\n\r]*))?" +
                @"(?:\n+COMUNICACIÓN:\s*(?<communication>[^\n\r]*))?";

            var match = Regex.Match(rawText.Trim(), fullPattern, RegexOptions.Singleline);

            if (!match.Success)
                return (rawText.Trim(), "N/A", "N/A", "N/A", false);

            string element = match.Groups["element"].Success && !string.IsNullOrWhiteSpace(match.Groups["element"].Value)
                ? match.Groups["element"].Value.Trim()
                : "N/A";

            string method = match.Groups["method"].Success && !string.IsNullOrWhiteSpace(match.Groups["method"].Value)
                ? match.Groups["method"].Value.Trim()
                : "N/A";

            string description = match.Groups["description"].Success && !string.IsNullOrWhiteSpace(match.Groups["description"].Value)
                ? match.Groups["description"].Value.Trim()
                : "N/A";

            string communication = match.Groups["communication"].Success && !string.IsNullOrWhiteSpace(match.Groups["communication"].Value)
                ? match.Groups["communication"].Value.Trim()
                : "N/A";

            bool hasLexicalError = Regex.IsMatch(rawText, @"(?<=\S)[ \t]+\n+(MÉTODO:|DESCRIPCIÓN:|COMUNICACIÓN:)", RegexOptions.Multiline);

            return (element, description, communication, method, hasLexicalError);
        }

        private string ExtractFunctionValue(XElement shape)
        {
            var section = shape.Descendants().FirstOrDefault(d => d.Name.LocalName == "Section" && d.Attribute("N")?.Value == "Property");
            if (section != null)
            {
                var functionRow = section.Descendants().FirstOrDefault(d => d.Name.LocalName == "Row" && d.Attribute("N")?.Value == "Function");
                if (functionRow != null)
                {
                    var functionCell = functionRow.Descendants().FirstOrDefault(d => d.Name.LocalName == "Cell" && d.Attribute("N")?.Value == "Value");
                    return functionCell?.Attribute("V")?.Value;
                }
            }
            return null;
        }

        public VisioExtractionResult ProcessVisioFile(string filePath, int diagramId)
        {
            var shapesData = new List<ShapeData>();
            var unrecognizedShapes = new List<ShapeData>();

            try
            {
                using (var zip = ZipFile.OpenRead(filePath))
                {
                    LoadMasterShapes(zip);

                    ZipArchiveEntry? visioXmlEntry = null;
                    for (int i = 1; i <= 50; i++)
                    {
                        visioXmlEntry = zip.Entries.FirstOrDefault(entry => entry.FullName.EndsWith($"page{i}.xml", StringComparison.OrdinalIgnoreCase));
                        if (visioXmlEntry != null)
                            break;
                    }

                    if (visioXmlEntry == null)
                        throw new Exception("No se encontró ninguna página válida en el archivo Visio.");

                    using (var entryStream = visioXmlEntry.Open())
                    {
                        var xdoc = XDocument.Load(entryStream);
                        var shapes = xdoc.Descendants().Where(d => d.Name.LocalName == "Shape");

                        foreach (var shape in shapes)
                        {
                            var masterId = shape.Attribute("Master")?.Value;
                            if (string.IsNullOrEmpty(masterId) || !masterShapes.ContainsKey(masterId)) continue;

                            string elementType = NormalizeShapeName(masterShapes[masterId]);
                            string rawElementText = shape.Descendants().FirstOrDefault(d => d.Name.LocalName == "Text")?.Value ?? "";
                            string system = (ExtractFunctionValue(shape) ?? "N/A").Trim();

                            string patternToUse = shapePatterns.ContainsKey(elementType) ? shapePatterns[elementType] : @"^(?<element>[^\n]*)";

                            var (element, description, communication, method, hasLexicalError) = ExtractTextSections(rawElementText, elementType);

                            if (elementType == "TWS" && system.Equals("JOB NAME", StringComparison.OrdinalIgnoreCase))
                            {
                                element = ExtractTextSections(rawElementText, "CPU").element;
                            }

                            if (elementType == "RUTA DE ACCESO")
                            {
                                element = ProcessRouteAccess(rawElementText);
                            }

                            if (elementType == "DLL")
                            {
                                (element, method, description) = ProcessDLL(rawElementText);
                            }

                            if (elementType == "COM+")
                            {
                                (element, method, description, communication) = ProcessCOMPlus(rawElementText);
                            }

                            if (elementType == "NUGET")
                            {
                                (element, method, description, communication) = ProcessNuget(rawElementText);
                            }

                            if (elementType == "FTP")
                            {
                                element = ProcessFTP(rawElementText);
                            }

                            if (elementType == "FINIX")
                            {
                                element = ProcessFinix(rawElementText);
                            }

                            if (elementType == "SOCKET")
                            {
                                (element, description) = ProcessSocket(rawElementText);
                            }

                            if (elementType == "CAMBIO ESTATUS DE DETALLE" || elementType == "CAMBIO ESTATUS DE LOTE" || elementType == "CAMBIO ESTATUS DE OPERACIÓN")
                            {
                                elementType = "QUERY UPDATE";
                            }
                            if (elementType == "VALIDACIÓN")
                            {
                                elementType = "QUERY SELECT";
                            }

                            if (elementType == "DATABASE")
                            {
                                var dbShapes = ProcessDBShape(rawElementText, system);
                                shapesData.AddRange(dbShapes);
                                continue;
                            }

                            if (elementType == "ARCHIVO-VSAM" || elementType == "ARCHIVO VSAM" || elementType == "ARCHIVO-PLANO")
                            {
                                var fileShapes = ProcessFileShape(rawElementText, system, elementType);
                                shapesData.AddRange(fileShapes);
                                continue;
                            }
                            if (elementType == "VALIDACIÓN DE HORARIO")
                            {
                                var horarioShapes = ProcessValidacionHorario(rawElementText, system);
                                shapesData.AddRange(horarioShapes);
                                continue;
                            }


                            if (excludedShapes.Contains(elementType))
                            {
                                continue;
                            }

                            ShapeData shapeData = new ShapeData
                            {
                                ElementType = elementType,
                                Element = element,
                                System = system ?? "N/A",
                                Description = description,
                                Communication = communication,
                                Method = method
                            };

                            bool hasNewLine = element.Contains("\n") || element.Contains("\r");

                            if (hasNewLine)
                            {
                                unrecognizedShapes.Add(shapeData);
                                continue;
                            }
                            if (allowedShapes.Contains(elementType))
                            {
                                shapesData.Add(shapeData);
                            }
                            else
                            {
                                unrecognizedShapes.Add(shapeData);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al procesar el archivo Visio", ex);
            }

            return new VisioExtractionResult
            {
                DiagramId = diagramId,
                ShapesList = shapesData,
                UnrecognizedShapes = unrecognizedShapes
            };
        }

    }
}
